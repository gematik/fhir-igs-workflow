# GEM ERP PR Medication - TIFlow - Kernfunktionalitäten v0.9.0

TIFlow - Kernfunktionalitäten

Version 0.9.0 - ci-build 

* [**Table of Contents**](toc.md)
* [**FHIR-Artefakte**](artifacts.md)
* **GEM ERP PR Medication**

## Resource Profile: GEM ERP PR Medication 

| | |
| :--- | :--- |
| *Official URL*:https://gematik.de/fhir/erp/StructureDefinition/GEM_ERP_PR_Medication | *Version*:0.9.0 |
| Draft as of 2025-09-25 | *Computable Name*:GEM_ERP_PR_Medication |

 
Medikament zur Ausgabe des Rezepts 

**Usages:**

* Use this Profile: [GEM ERP PR CloseOperation Input](StructureDefinition-GEM-ERP-PR-PAR-Close-Operation-Input.md) and [GEM ERP PR DispenseOperation Input](StructureDefinition-GEM-ERP-PR-PAR-Dispense-Operation-Input.md)
* Refer to this Profile: [GEM ERP PR MedicationDispense](StructureDefinition-GEM-ERP-PR-MedicationDispense.md)
* Examples for this Profile: [Medication/ExampleUnitMedication](Medication-ExampleUnitMedication.md), [Medication/Medication-Kombipackung](Medication-Medication-Kombipackung.md), [Medication/Medication-Rezeptur-FD](Medication-Medication-Rezeptur-FD.md), [Medication/Medication-Rezeptur](Medication-Medication-Rezeptur.md)... Show 4 more, [Medication/Medication-Without-Strength-Code](Medication-Medication-Without-Strength-Code.md), [Medication/Medication-Without-Strength-Numerator](Medication-Medication-Without-Strength-Numerator.md), [Medication/SimpleMedication](Medication-SimpleMedication.md) and [Medication/SumatripanMedication](Medication-SumatripanMedication.md)

You can also check for [usages in the FHIR IG Statistics](https://packages2.fhir.org/xig/de.gematik.tiflow.core|current/StructureDefinition/GEM-ERP-PR-Medication)

### Formal Views of Profile Content

 [Description of Profiles, Differentials, Snapshots and how the different presentations work](http://build.fhir.org/ig/FHIR/ig-guidance/readingIgs.html#structure-definitions). 

 

Other representations of profile: [CSV](StructureDefinition-GEM-ERP-PR-Medication.csv), [Excel](StructureDefinition-GEM-ERP-PR-Medication.xlsx), [Schematron](StructureDefinition-GEM-ERP-PR-Medication.sch) 



## Resource Content

```json
{
  "resourceType" : "StructureDefinition",
  "id" : "GEM-ERP-PR-Medication",
  "url" : "https://gematik.de/fhir/erp/StructureDefinition/GEM_ERP_PR_Medication",
  "version" : "0.9.0",
  "name" : "GEM_ERP_PR_Medication",
  "title" : "GEM ERP PR Medication",
  "status" : "draft",
  "date" : "2025-09-25",
  "publisher" : "gematik GmbH",
  "contact" : [{
    "name" : "gematik GmbH",
    "telecom" : [{
      "system" : "url",
      "value" : "https://gematik.de"
    },
    {
      "system" : "email",
      "value" : "erp-umsetzung@gematik.de"
    }]
  }],
  "description" : "Medikament zur Ausgabe des Rezepts",
  "jurisdiction" : [{
    "coding" : [{
      "system" : "urn:iso:std:iso:3166",
      "code" : "DE",
      "display" : "Germany"
    }]
  }],
  "fhirVersion" : "4.0.1",
  "mapping" : [{
    "identity" : "script10.6",
    "uri" : "http://ncpdp.org/SCRIPT10_6",
    "name" : "Mapping to NCPDP SCRIPT 10.6"
  },
  {
    "identity" : "rim",
    "uri" : "http://hl7.org/v3",
    "name" : "RIM Mapping"
  },
  {
    "identity" : "w5",
    "uri" : "http://hl7.org/fhir/fivews",
    "name" : "FiveWs Pattern Mapping"
  },
  {
    "identity" : "v2",
    "uri" : "http://hl7.org/v2",
    "name" : "HL7 v2 Mapping"
  }],
  "kind" : "resource",
  "abstract" : false,
  "type" : "Medication",
  "baseDefinition" : "https://gematik.de/fhir/epa-medication/StructureDefinition/epa-medication",
  "derivation" : "constraint",
  "differential" : {
    "element" : [{
      "id" : "Medication",
      "path" : "Medication"
    },
    {
      "id" : "Medication.meta",
      "path" : "Medication.meta",
      "min" : 1
    },
    {
      "id" : "Medication.meta.profile",
      "path" : "Medication.meta.profile",
      "slicing" : {
        "discriminator" : [{
          "type" : "value",
          "path" : "$this"
        }],
        "description" : "Slicing für meta profile",
        "ordered" : false,
        "rules" : "closed"
      },
      "min" : 1,
      "max" : "1",
      "mustSupport" : true
    },
    {
      "id" : "Medication.meta.profile:workflowProfile",
      "path" : "Medication.meta.profile",
      "sliceName" : "workflowProfile",
      "min" : 1,
      "max" : "1",
      "fixedCanonical" : "https://gematik.de/fhir/erp/StructureDefinition/GEM_ERP_PR_Medication|1.6",
      "mustSupport" : true
    },
    {
      "id" : "Medication.contained",
      "path" : "Medication.contained",
      "short" : "Enthaltene Medications",
      "definition" : "Dieses Feld kann weitere Medication Ressourcen enthalten, die hier gelistet werden. Dies tritt z.B. bei Rezepturen auf."
    },
    {
      "id" : "Medication.extension:isVaccine",
      "path" : "Medication.extension",
      "sliceName" : "isVaccine",
      "mustSupport" : true
    },
    {
      "id" : "Medication.extension:drugCategory",
      "path" : "Medication.extension",
      "sliceName" : "drugCategory",
      "mustSupport" : true
    },
    {
      "id" : "Medication.extension:normSizeCode",
      "path" : "Medication.extension",
      "sliceName" : "normSizeCode",
      "mustSupport" : true
    },
    {
      "id" : "Medication.extension:packaging",
      "path" : "Medication.extension",
      "sliceName" : "packaging",
      "mustSupport" : true
    },
    {
      "id" : "Medication.extension:manufacturingInstructions",
      "path" : "Medication.extension",
      "sliceName" : "manufacturingInstructions",
      "mustSupport" : true
    },
    {
      "id" : "Medication.identifier",
      "path" : "Medication.identifier",
      "short" : "Business-Identifier der Medication",
      "definition" : "Dieses Feld bietet die Möglichkeit, für eine Medikation Business Identifier zu belegen.",
      "comment" : "Gegenüber dem E-Rezept-Fachdienst wird dieser Wert nicht ausgewertet."
    },
    {
      "id" : "Medication.code",
      "path" : "Medication.code",
      "short" : "Code der Medikation",
      "definition" : "Ein Code (oder eine Gruppe von Codes), der dieses Medikament identifiziert, oder eine textuelle Beschreibung, falls kein Code verfügbar ist."
    },
    {
      "id" : "Medication.form",
      "path" : "Medication.form",
      "short" : "Darreichungsform",
      "definition" : "Beschreibt die Darreichungsform des Arzneimittels."
    },
    {
      "id" : "Medication.amount",
      "path" : "Medication.amount",
      "short" : "Menge des Arzneimittels in einer Packung",
      "definition" : "Angabe der Packungsgröße, bzw. der Gesamtmenge der Packung"
    },
    {
      "id" : "Medication.amount.numerator.extension:packagingSize",
      "path" : "Medication.amount.numerator.extension",
      "sliceName" : "packagingSize",
      "mustSupport" : true
    },
    {
      "id" : "Medication.amount.numerator.extension:totalQuantity",
      "path" : "Medication.amount.numerator.extension",
      "sliceName" : "totalQuantity",
      "mustSupport" : true
    },
    {
      "id" : "Medication.ingredient",
      "path" : "Medication.ingredient",
      "short" : "Wirkstoffe",
      "definition" : "Hier können Bestandteile, die Wirkstoffe oder keine Wirkstoffe sind, erfasst werden."
    },
    {
      "id" : "Medication.ingredient.extension:darreichungsform",
      "path" : "Medication.ingredient.extension",
      "sliceName" : "darreichungsform",
      "short" : "Darreichungsform",
      "definition" : "Angabe der Darreichungsform eines Wirkstoffes als string",
      "mustSupport" : true
    },
    {
      "id" : "Medication.ingredient.item[x]:itemCodeableConcept",
      "path" : "Medication.ingredient.item[x]",
      "sliceName" : "itemCodeableConcept",
      "short" : "Wirkstoff kodiert",
      "definition" : "An dieser Stelle können die Informationen des Wirkstoffs in einer kodierten Art und weise angegeben werden.",
      "type" : [{
        "code" : "CodeableConcept"
      }]
    },
    {
      "id" : "Medication.ingredient.item[x]:itemReference",
      "path" : "Medication.ingredient.item[x]",
      "sliceName" : "itemReference",
      "short" : "Wirkstoff Referenz",
      "definition" : "An dieser Stelle können Referenzen zu verlinkten Medikationen angegeben werden.",
      "comment" : "Wird in diesem Profil ausschließlich dafür genutzt, um für Rezepturen und Kombipackungen die Einzelbestandteile unter `.contained` anzugeben",
      "type" : [{
        "code" : "Reference",
        "targetProfile" : ["https://gematik.de/fhir/epa-medication/StructureDefinition/epa-medication-pharmaceutical-product",
        "https://gematik.de/fhir/epa-medication/StructureDefinition/epa-medication-pzn-ingredient"],
        "aggregation" : ["contained"]
      }]
    },
    {
      "id" : "Medication.ingredient.strength",
      "path" : "Medication.ingredient.strength",
      "short" : "Wirkstärke",
      "definition" : "Angabe zur Wirkstärke des Wirkstoffs"
    },
    {
      "id" : "Medication.ingredient.strength.extension:amountText",
      "path" : "Medication.ingredient.strength.extension",
      "sliceName" : "amountText",
      "short" : "Angabe der Menge",
      "definition" : "Freitextmenge des Wirkstoffs für klassische lateinische Notationen wie 'ad 100,0' oder 'quantum satis', einschließlich der Einheit.",
      "mustSupport" : true
    },
    {
      "id" : "Medication.batch",
      "path" : "Medication.batch",
      "short" : "Chargeninformationen",
      "definition" : "Informationen, die nur für Packungen gelten (nicht für Produkte)."
    },
    {
      "id" : "Medication.batch.lotNumber",
      "path" : "Medication.batch.lotNumber",
      "short" : "Chargennummer",
      "definition" : "Die zugewiesene Chargennummer einer Charge des angegebenen Produkts."
    },
    {
      "id" : "Medication.batch.expirationDate",
      "path" : "Medication.batch.expirationDate",
      "short" : "Verfallsdatum",
      "definition" : "Wann diese spezielle Charge des Produkts abläuft"
    }]
  }
}

```
