# FdV-Anforderungen: Channels-Query - TIFlow - Kernfunktionalitäten v0.9.0

TIFlow - Kernfunktionalitäten

Version 0.9.0 - ci-build 

* [**Table of Contents**](toc.md)
* [**Query API**](menu-schnittstellen-query-api.md)
* [**Query API: Channels**](query-api-channels.md)
* **FdV-Anforderungen: Channels-Query**

## FdV-Anforderungen: Channels-Query

Diese Seite beschreibt Anforderungen an das E-Rezept-FdV zur Nutzung der `Channels`-Query-Endpunkte.

Die Funktionalität zu Push Notification für FdVs ist anwendungsübergreifend in [gemF_PushNotification] beschrieben. In diesem Kapitel werden die zusätzlichen E-Rezept spezifischen Anforderungen beschrieben.

Das E-Rezept-FdV MUSS, wenn es den Anwendungsfall "Push Notifications" umsetzt, für die Registrierung und Verwaltung der Channels für die FdV-Instanzen des Versicherten am E-Rezept-Fachdienst die Operationen gemäß [OpenAPI_FD] verwenden.

