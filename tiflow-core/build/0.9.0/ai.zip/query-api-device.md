# Query API: Device - TIFlow - Kernfunktionalitäten v0.9.0

TIFlow - Kernfunktionalitäten

Version 0.9.0 - ci-build 

* [**Table of Contents**](toc.md)
* [**Query API**](menu-schnittstellen-query-api.md)
* **Query API: Device**

## Query API: Device

# Query API: Device

Diese Seite beschreibt die moduluebergreifende Device-Query-Schnittstelle.

### Nachricht

Die Device-Query wird ueber HTTP `GET` auf `/Device` aufgerufen.

### Anforderungen an Schnittstelle

* [Server Anforderungen zur Device-Query](./query-api-device-req-fd.md): Anforderungen an den E-Rezept-Fachdienst zur Bereitstellung der Schnittstelle.
* [Client-Anforderungen zur Device-Query](./query-api-device-client-requirements.md): Anforderungen an den Client des E-Rezept-Fachdienstes zur Nutzung der Schnittstelle.

### API Beschreibung

* [Erweiterter Health-Check](https://github.com/gematik/api-erp/blob/master/docs/erp_ps_probing.adoc#erweiterter-health-check)

### Hinweis

* Die Ressource `Device` dient der statischen Selbstauskunft des E-Rezept-Fachdienstes.
* Der Endpunkt wird zur Bereitstellung von Produkttypinformationen genutzt.

