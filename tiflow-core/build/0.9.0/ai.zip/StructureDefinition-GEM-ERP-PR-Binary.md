# GEM ERP PR Binary - TIFlow - Kernfunktionalitäten v0.9.0

TIFlow - Kernfunktionalitäten

Version 0.9.0 - ci-build 

* [**Table of Contents**](toc.md)
* [**FHIR-Artefakte**](artifacts.md)
* **GEM ERP PR Binary**

## Resource Profile: GEM ERP PR Binary 

| | |
| :--- | :--- |
| *Official URL*:https://gematik.de/fhir/erp/StructureDefinition/GEM_ERP_PR_Binary | *Version*:0.9.0 |
| Draft as of 2025-09-25 | *Computable Name*:GEM_ERP_PR_Binary |

 
PKCS7 signiertes Bundle im enveloping style 

**Usages:**

* Use this Profile: [GEM ERP PR Bundle OP Accept](StructureDefinition-GEM-ERP-PR-Bundle-OP-Accept.md)
* Refer to this Profile: [GEM ERP PR Task](StructureDefinition-GEM-ERP-PR-Task.md)

You can also check for [usages in the FHIR IG Statistics](https://packages2.fhir.org/xig/de.gematik.tiflow.core|current/StructureDefinition/GEM-ERP-PR-Binary)

### Formal Views of Profile Content

 [Description of Profiles, Differentials, Snapshots and how the different presentations work](http://build.fhir.org/ig/FHIR/ig-guidance/readingIgs.html#structure-definitions). 

 

Other representations of profile: [CSV](StructureDefinition-GEM-ERP-PR-Binary.csv), [Excel](StructureDefinition-GEM-ERP-PR-Binary.xlsx), [Schematron](StructureDefinition-GEM-ERP-PR-Binary.sch) 



## Resource Content

```json
{
  "resourceType" : "StructureDefinition",
  "id" : "GEM-ERP-PR-Binary",
  "url" : "https://gematik.de/fhir/erp/StructureDefinition/GEM_ERP_PR_Binary",
  "version" : "0.9.0",
  "name" : "GEM_ERP_PR_Binary",
  "title" : "GEM ERP PR Binary",
  "status" : "draft",
  "date" : "2025-09-25",
  "publisher" : "gematik GmbH",
  "contact" : [{
    "name" : "gematik GmbH",
    "telecom" : [{
      "system" : "url",
      "value" : "https://gematik.de"
    },
    {
      "system" : "email",
      "value" : "erp-umsetzung@gematik.de"
    }]
  }],
  "description" : "PKCS7 signiertes Bundle im enveloping style",
  "jurisdiction" : [{
    "coding" : [{
      "system" : "urn:iso:std:iso:3166",
      "code" : "DE",
      "display" : "Germany"
    }]
  }],
  "fhirVersion" : "4.0.1",
  "mapping" : [{
    "identity" : "rim",
    "uri" : "http://hl7.org/v3",
    "name" : "RIM Mapping"
  }],
  "kind" : "resource",
  "abstract" : false,
  "type" : "Binary",
  "baseDefinition" : "http://hl7.org/fhir/StructureDefinition/Binary",
  "derivation" : "constraint",
  "differential" : {
    "element" : [{
      "id" : "Binary",
      "path" : "Binary"
    },
    {
      "id" : "Binary.meta",
      "path" : "Binary.meta",
      "min" : 1,
      "mustSupport" : true
    },
    {
      "id" : "Binary.meta.profile",
      "path" : "Binary.meta.profile",
      "slicing" : {
        "discriminator" : [{
          "type" : "value",
          "path" : "$this"
        }],
        "description" : "Slicing für meta profile",
        "ordered" : false,
        "rules" : "closed"
      },
      "min" : 1,
      "max" : "1",
      "mustSupport" : true
    },
    {
      "id" : "Binary.meta.profile:workflowProfile",
      "path" : "Binary.meta.profile",
      "sliceName" : "workflowProfile",
      "min" : 1,
      "max" : "1",
      "fixedCanonical" : "https://gematik.de/fhir/erp/StructureDefinition/GEM_ERP_PR_Binary|1.6",
      "mustSupport" : true
    },
    {
      "id" : "Binary.contentType",
      "path" : "Binary.contentType",
      "fixedCode" : "application/pkcs7-mime"
    },
    {
      "id" : "Binary.data",
      "path" : "Binary.data",
      "min" : 1
    }]
  }
}

```
