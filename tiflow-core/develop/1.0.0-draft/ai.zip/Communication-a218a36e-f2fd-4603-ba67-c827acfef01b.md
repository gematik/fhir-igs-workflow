# Zuweisung des Patienten an die Apotheke - TIFlow - Kernfunktionalitäten v1.0.0-draft

TIFlow - Kernfunktionalitäten

Version 1.0.0-draft - ci-build 

* [**Table of Contents**](toc.md)
* [**FHIR-Artefakte**](artifacts.md)
* **Zuweisung des Patienten an die Apotheke**

## Example Communication: Zuweisung des Patienten an die Apotheke



## Resource Content

```json
{
  "resourceType" : "Communication",
  "id" : "a218a36e-f2fd-4603-ba67-c827acfef01b",
  "meta" : {
    "profile" : ["https://gematik.de/fhir/erp/StructureDefinition/GEM_ERP_PR_Communication_DispReq|1.6"],
    "tag" : [{
      "display" : "Dispense Request from Patient to Pharmacy"
    },
    {
      "display" : "Communication message sent by patient to pharmacy to request the dispensation of medicine by providing the AccessCode"
    }]
  },
  "extension" : [{
    "url" : "https://gematik.de/fhir/erp/StructureDefinition/GEM_ERP_EX_PrescriptionType",
    "valueCoding" : {
      "system" : "https://gematik.de/fhir/erp/CodeSystem/GEM_ERP_CS_FlowType",
      "code" : "160",
      "display" : "Flowtype für Apothekenpflichtige Arzneimittel"
    }
  }],
  "basedOn" : [{
    "reference" : "Task/160.000.033.491.280.78/$accept?ac=777bea0e13cc9c42ceec14aec3ddee2263325dc2c6c699db115f58fe423607ea"
  }],
  "status" : "unknown",
  "sent" : "2026-07-01T15:29:00.434+00:00",
  "recipient" : [{
    "identifier" : {
      "system" : "https://gematik.de/fhir/sid/telematik-id",
      "value" : "3-SMC-B-Testkarte-883110000123465"
    }
  }],
  "sender" : {
    "identifier" : {
      "system" : "http://fhir.de/sid/gkv/kvid-10",
      "value" : "X234567890"
    }
  },
  "payload" : [{
    "contentString" : "{ \"version\": \"1\", \"supplyOptionsType\": \"delivery\", \"name\": \"Dr. Maximilian von Muster\", \"address\": [ \"wohnhaft bei Emilia Fischer\", \"Bundesallee 312\", \"123. OG\", \"12345 Berlin\" ], \"hint\": \"Bitte im Morsecode klingeln: -.-.\", \"phone\": \"004916094858168\" }"
  }]
}

```
