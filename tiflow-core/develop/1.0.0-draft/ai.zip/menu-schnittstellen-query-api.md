# Query API - TIFlow - Kernfunktionalitäten v1.0.0-draft

TIFlow - Kernfunktionalitäten

Version 1.0.0-draft - ci-build 

* [**Table of Contents**](toc.md)
* **Query API**

## Query API

Die folgenden Query APIs stellt der TI-Flow-Fachdienst den Clientsystemen zur Verfügung, um FHIR-Daten gezielt abrufen zu können.

* [Query API: Device](./query-api-device.md)
* [Query API: AuditEvent](./query-api-auditevent.md)
* [Query API: Task](./query-api-task.md)
* [Query API: MedicationDispense](./query-api-medicationdispense.md)
* [Query API: Communication](./query-api-communication.md)
* [Query API: Consent](./query-api-consent.md)
* [Query API: Subscription](./query-api-subscription.md)
* [Query API: Push Notification - pushers](./query-api-pushers.md)
* [Query API: Push Notification - channels](./query-api-channels.md)

