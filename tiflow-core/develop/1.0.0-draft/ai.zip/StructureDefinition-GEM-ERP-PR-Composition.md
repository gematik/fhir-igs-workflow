# GEM ERP PR Composition - TIFlow - Kernfunktionalitäten v1.0.0-draft

TIFlow - Kernfunktionalitäten

Version 1.0.0-draft - ci-build 

* [**Table of Contents**](toc.md)
* [**FHIR-Artefakte**](artifacts.md)
* **GEM ERP PR Composition**

## Resource Profile: GEM ERP PR Composition 

| | |
| :--- | :--- |
| *Official URL*:https://gematik.de/fhir/erp/StructureDefinition/GEM_ERP_PR_Composition | *Version*:1.0.0-draft |
| Draft as of 2025-09-25 | *Computable Name*:GEM_ERP_PR_Composition |

 
Quittung für die Einlösung eines E-Rezepts 

**Usages:**

* Use this Profile: [GEM ERP PR Bundle](StructureDefinition-GEM-ERP-PR-Bundle.md)

You can also check for [usages in the FHIR IG Statistics](https://packages2.fhir.org/xig/de.gematik.tiflow.core|current/StructureDefinition/GEM-ERP-PR-Composition)

### Formal Views of Profile Content

 [Description of Profiles, Differentials, Snapshots and how the different presentations work](http://build.fhir.org/ig/FHIR/ig-guidance/readingIgs.html#structure-definitions). 

 

Other representations of profile: [CSV](StructureDefinition-GEM-ERP-PR-Composition.csv), [Excel](StructureDefinition-GEM-ERP-PR-Composition.xlsx), [Schematron](StructureDefinition-GEM-ERP-PR-Composition.sch) 



## Resource Content

```json
{
  "resourceType" : "StructureDefinition",
  "id" : "GEM-ERP-PR-Composition",
  "url" : "https://gematik.de/fhir/erp/StructureDefinition/GEM_ERP_PR_Composition",
  "version" : "1.0.0-draft",
  "name" : "GEM_ERP_PR_Composition",
  "title" : "GEM ERP PR Composition",
  "status" : "draft",
  "date" : "2025-09-25",
  "publisher" : "gematik GmbH",
  "contact" : [{
    "name" : "gematik GmbH",
    "telecom" : [{
      "system" : "url",
      "value" : "https://gematik.de"
    },
    {
      "system" : "email",
      "value" : "erp-umsetzung@gematik.de"
    }]
  }],
  "description" : "Quittung für die Einlösung eines E-Rezepts",
  "jurisdiction" : [{
    "coding" : [{
      "system" : "urn:iso:std:iso:3166",
      "code" : "DE",
      "display" : "Germany"
    }]
  }],
  "fhirVersion" : "4.0.1",
  "mapping" : [{
    "identity" : "workflow",
    "uri" : "http://hl7.org/fhir/workflow",
    "name" : "Workflow Pattern"
  },
  {
    "identity" : "rim",
    "uri" : "http://hl7.org/v3",
    "name" : "RIM Mapping"
  },
  {
    "identity" : "cda",
    "uri" : "http://hl7.org/v3/cda",
    "name" : "CDA (R2)"
  },
  {
    "identity" : "fhirdocumentreference",
    "uri" : "http://hl7.org/fhir/documentreference",
    "name" : "FHIR DocumentReference"
  },
  {
    "identity" : "w5",
    "uri" : "http://hl7.org/fhir/fivews",
    "name" : "FiveWs Pattern Mapping"
  }],
  "kind" : "resource",
  "abstract" : false,
  "type" : "Composition",
  "baseDefinition" : "http://hl7.org/fhir/StructureDefinition/Composition",
  "derivation" : "constraint",
  "differential" : {
    "element" : [{
      "id" : "Composition.meta",
      "path" : "Composition.meta",
      "min" : 1,
      "mustSupport" : true
    },
    {
      "id" : "Composition.meta.profile",
      "path" : "Composition.meta.profile",
      "slicing" : {
        "discriminator" : [{
          "type" : "value",
          "path" : "$this"
        }],
        "description" : "Slicing für meta profile",
        "ordered" : false,
        "rules" : "closed"
      },
      "min" : 1,
      "max" : "1",
      "mustSupport" : true
    },
    {
      "id" : "Composition.meta.profile:workflowProfile",
      "path" : "Composition.meta.profile",
      "sliceName" : "workflowProfile",
      "min" : 1,
      "max" : "1",
      "fixedCanonical" : "https://gematik.de/fhir/erp/StructureDefinition/GEM_ERP_PR_Composition|1.6",
      "mustSupport" : true
    },
    {
      "id" : "Composition.extension",
      "path" : "Composition.extension",
      "slicing" : {
        "discriminator" : [{
          "type" : "value",
          "path" : "url"
        }],
        "description" : "Erweiterungen für die Composition, die durch url unterschieden werden sollen",
        "rules" : "closed"
      },
      "min" : 1
    },
    {
      "id" : "Composition.extension:Beneficiary",
      "path" : "Composition.extension",
      "sliceName" : "Beneficiary",
      "short" : "Die ID des Begünstigten des E-Rezept-Belegs (z. B. TelematikID der Apotheke)",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "Extension",
        "profile" : ["https://gematik.de/fhir/erp/StructureDefinition/GEM_ERP_EX_Beneficiary"]
      }]
    },
    {
      "id" : "Composition.status",
      "path" : "Composition.status",
      "short" : "Status = \"final\"",
      "fixedCode" : "final",
      "mustSupport" : true
    },
    {
      "id" : "Composition.type",
      "path" : "Composition.type",
      "short" : "Document Type = \"Receipt\"",
      "mustSupport" : true
    },
    {
      "id" : "Composition.type.coding",
      "path" : "Composition.type.coding",
      "min" : 1,
      "max" : "1",
      "binding" : {
        "strength" : "required",
        "valueSet" : "https://gematik.de/fhir/erp/CodeSystem/GEM_ERP_VS_DocumentType"
      }
    },
    {
      "id" : "Composition.type.coding.system",
      "path" : "Composition.type.coding.system",
      "min" : 1,
      "fixedUri" : "https://gematik.de/fhir/erp/CodeSystem/GEM_ERP_CS_DocumentType"
    },
    {
      "id" : "Composition.type.coding.code",
      "path" : "Composition.type.coding.code",
      "min" : 1,
      "fixedCode" : "3"
    },
    {
      "id" : "Composition.type.coding.display",
      "path" : "Composition.type.coding.display",
      "fixedString" : "Receipt"
    },
    {
      "id" : "Composition.date",
      "path" : "Composition.date",
      "mustSupport" : true
    },
    {
      "id" : "Composition.author",
      "path" : "Composition.author",
      "short" : "Referenz zur Überprüfung des Dienstes (Gerät)",
      "type" : [{
        "code" : "Reference",
        "targetProfile" : ["https://gematik.de/fhir/erp/StructureDefinition/GEM_ERP_PR_Device"],
        "aggregation" : ["referenced", "bundled"]
      }],
      "mustSupport" : true
    },
    {
      "id" : "Composition.title",
      "path" : "Composition.title",
      "short" : "Document title = \"Quittung\"",
      "fixedString" : "Quittung",
      "mustSupport" : true
    },
    {
      "id" : "Composition.event",
      "path" : "Composition.event",
      "min" : 1,
      "max" : "1"
    },
    {
      "id" : "Composition.event.period",
      "path" : "Composition.event.period",
      "min" : 1,
      "mustSupport" : true
    },
    {
      "id" : "Composition.event.period.start",
      "path" : "Composition.event.period.start",
      "short" : "Startzeit der Ausgabe",
      "definition" : "Zeitpunkt der Einreichung des Rezepts bei der abgebenden Leistungserbringerorganisation",
      "min" : 1,
      "mustSupport" : true
    },
    {
      "id" : "Composition.event.period.end",
      "path" : "Composition.event.period.end",
      "short" : "Das Ende der Ausgabe",
      "definition" : "Zeitpunkt, an dem die Abgabe abgeschlossen ist, d. h. wenn der Server die Quittung erstellt.",
      "min" : 1
    },
    {
      "id" : "Composition.event.detail",
      "path" : "Composition.event.detail",
      "mustSupport" : true
    },
    {
      "id" : "Composition.event.detail.reference",
      "path" : "Composition.event.detail.reference",
      "min" : 1,
      "mustSupport" : true
    }]
  }
}

```
