# Antwort-Nachricht der Apotheke an den Patienten - TIFlow - Kernfunktionalitäten v1.0.0-draft

TIFlow - Kernfunktionalitäten

Version 1.0.0-draft - ci-build 

* [**Table of Contents**](toc.md)
* [**FHIR-Artefakte**](artifacts.md)
* **Antwort-Nachricht der Apotheke an den Patienten**

## Example Communication: Antwort-Nachricht der Apotheke an den Patienten



## Resource Content

```json
{
  "resourceType" : "Communication",
  "id" : "7977a4ab-97a9-4d95-afb3-6c4c1e2ac596",
  "meta" : {
    "profile" : ["https://gematik.de/fhir/erp/StructureDefinition/GEM_ERP_PR_Communication_Reply|1.6"],
    "tag" : [{
      "display" : "Reply from Pharmacy to Patient"
    },
    {
      "display" : "Communication message sent by pharmacy to patient in response to a previous Task-related message"
    }]
  },
  "basedOn" : [{
    "reference" : "Task/160.000.033.491.280.78"
  }],
  "status" : "unknown",
  "sent" : "2026-07-01T15:29:00.434+00:00",
  "recipient" : [{
    "identifier" : {
      "system" : "http://fhir.de/sid/gkv/kvid-10",
      "value" : "X234567890"
    }
  }],
  "sender" : {
    "identifier" : {
      "system" : "https://gematik.de/fhir/sid/telematik-id",
      "value" : "3-SMC-B-Testkarte-883110000123465"
    }
  },
  "payload" : [{
    "extension" : [{
      "url" : "https://gematik.de/fhir/erp/StructureDefinition/GEM_ERP_EX_AvailabilityState",
      "valueCoding" : {
        "system" : "https://gematik.de/fhir/erp/CodeSystem/GEM_ERP_CS_AvailabilityStatus",
        "code" : "20"
      }
    },
    {
      "extension" : [{
        "url" : "delivery",
        "valueBoolean" : true
      },
      {
        "url" : "onPremise",
        "valueBoolean" : true
      },
      {
        "url" : "shipment",
        "valueBoolean" : false
      }],
      "url" : "https://gematik.de/fhir/erp/StructureDefinition/GEM_ERP_EX_SupplyOptionsType"
    }],
    "contentString" : "Eisern"
  }]
}

```
