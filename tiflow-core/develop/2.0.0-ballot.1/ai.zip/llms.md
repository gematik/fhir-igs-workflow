# de.gematik.tiflow.core#2.0.0-ballot.1: TIFlow - Kernfunktionalitäten

## Pages

* [Implementation Guide TI-Flow Core](index.md)
* [Apache License](license.md)
* [Operation $activate (Task aktivieren)](op-activate.md)
* [Server-Anforderungen: Subscription](query-api-subscription-req-fd.md)
* [Query API: Channels](query-api-channels.md)
* [AVS-Anforderungen: Communication-Query](query-api-communication-req-avs.md)
* [Operation $reject (Task zurückweisen)](op-reject.md)
* [KTR-Anforderungen: Communication-Query](query-api-communication-req-ktr.md)
* [Server-Anforderungen: Communication-Query](query-api-communication-req-fd.md)
* [Query API: Consent](query-api-consent.md)
* [PVS-Anforderungen $abort](op-abort-req-pvs.md)
* [Server-Anforderungen: Pushers-Query](query-api-pushers-req-fd.md)
* [Health Check](health-check.md)
* [Server-Anforderungen $close](op-close-req-fd.md)
* [Notifications für Clientsysteme](menu-technische-umsetzung-subscription.md)
* [Query API: MedicationDispense](query-api-medicationdispense.md)
* [FdV-Anforderungen: AuditEvent-Query](query-api-auditevent-req-fdv.md)
* [KTR-Anforderungen: Subscription](query-api-subscription-req-ktr.md)
* [Server-Anforderungen $abort](op-abort-req-fd.md)
* [KTR-Anforderungen $close](op-close-req-ktr.md)
* [Server-Anforderungen: Consent-Query](query-api-consent-req-fd.md)
* [Generelle Prinzipien](menu-schnittstellen-generelle-prinzipien.md)
* [AVS-Anforderungen $accept](op-accept-req-avs.md)
* [Fehlercodes](error-codes.md)
* [Operation $abort (Task abbrechen)](op-abort.md)
* [FHIR-Artefakte](artifacts.md)
* [Additional API: Subscription](query-api-subscription.md)
* [Kommunikation zu Diensten der TI](kommunikation-dienste-ti.md)
* [Server-Anforderungen: Channels-Query](query-api-channels-req-fd.md)
* [Server-Anforderungen: Task-Query](query-api-task-req-fd.md)
* [Client-Anforderungen $create](op-create-req-pvs.md)
* [AVS-Anforderungen: Subscription](query-api-subscription-req-avs.md)
* [Server-Anforderungen $accept](op-accept-req-fd.md)
* [AVS-Anforderungen $abort](op-abort-req-avs.md)
* [FdV-Anforderungen: Task-Query](query-api-task-req-fdv.md)
* [KTR-Anforderungen $reject](op-reject-req-ktr.md)
* [FdV-Anforderungen: Channels-Query](query-api-channels-req-fdv.md)
* [FHIR-Ressource validieren](fhir-validate.md)
* [Query API](menu-schnittstellen-query-api.md)
* [Query API: AuditEvent](query-api-auditevent.md)
* [Server-Anforderungen $create](op-create-req-fd.md)
* [Fehlerbehandlung Clientsysteme](fehlerbehandlung-client.md)
* [Server-Anforderungen $activate](op-activate-req-fd.md)
* [Löschfristen](ttl.md)
* [Query API: Task](query-api-task.md)
* [Zertifikatsprüfung](pki-zertifikatspruefung.md)
* [Server-Anforderungen: MedicationDispense-Query](query-api-medicationdispense-req-fd.md)
* [AVS-Anforderungen: Task-Query](query-api-task-req-avs.md)
* [Operation API](menu-schnittstellen-operation-api.md)
* [FdV-Anforderungen: Communication-Query](query-api-communication-req-fdv.md)
* [AVS-Anforderungen $reject](op-reject-req-avs.md)
* [Technische Umsetzung - Systemüberblick](menu-technische-umsetzung-systemueberblick.md)
* [Client-Anforderungen $activate](op-activate-req-pvs.md)
* [ePA MedicationService](menu-technische-umsetzung-epa-ms.md)
* [Server-Anforderungen $reject](op-reject-req-fd.md)
* [Server-Anforderungen: Device-Query](query-api-device-req-fd.md)
* [FdV-Anforderungen: MedicationDispense-Query](query-api-medicationdispense-req-fdv.md)
* [Query API: Communication](query-api-communication.md)
* [FdV-Anforderungen: Device-Query](query-api-device-req-fdv.md)
* [Mapping alter Anforderungen auf FHIR-IG Anforderungen](requirement-mapping-old-to-new.md)
* [Client-Anforderungen: Consent-Query](query-api-consent-req-fdv.md)
* [Zugriffsprotokollierung](audit-service.md)
* [Server-Anforderungen: AuditEvent-Query](query-api-auditevent-req-fd.md)
* [Operation $accept (Task akzeptieren)](op-accept.md)
* [AVS-Anforderungen $close](op-close-req-avs.md)
* [Push Notification senden](menu-technische-umsetzung-push.md)
* [Operation $create (Task erzeugen)](op-create.md)
* [FdV-Anforderungen: Pushers-Query](query-api-pushers-req-fdv.md)
* [Additional API](menu-schnittstellen-additional-api.md)
* [Datamatrix Code](datamatrix-code-client.md)
* [Anforderungen zur Fehlerbehandlung](error-codes-req-fd.md)
* [FdV-Anforderungen $abort](op-abort-req-fdv.md)
* [KTR-Anforderungen: Task-Query](query-api-task-req-ktr.md)
* [Operation $close (Task schließen)](op-close.md)
* [Query API: Pushers](query-api-pushers.md)
* [Query API: Device](query-api-device.md)
* [KTR-Anforderungen $accept](op-accept-req-ktr.md)
* [Handhabung der Rückgabe von mehreren FHIR-Objekten](menu-technische-umsetzung-paging.md)
* [Datenschutz und Sicherheit](menu-schnittstellen-datenschutz-und-sicherheit.md)

## Resources

### CodeSystems

* [CodeSystem des Verfügbarkeitsstatus](CodeSystem-GEM-ERP-CS-AvailabilityStatus.md)
* [CodeSystem der Dokumententypen](CodeSystem-GEM-ERP-CS-DocumentType.md)
* [TI Environments CodeSystem](CodeSystem-ti-environment-codes.md)
* [TIFHIR Configuration CS](CodeSystem-ti-fhir-configuration-cs.md)
* [CodeSystem der Flowtypes in TIFlow Anwendungen](CodeSystem-ti-flowtypes-codes.md)
* [TIFLOW Operation Outcome Details CS](CodeSystem-tiflow-operation-outcome-details-cs.md)

### ValueSets

* [ValueSet der Verfügbarkeitsstatus-Codes](ValueSet-GEM-ERP-VS-AvailabilityStatus.md)
* [ValueSet der Dokumenttyp-Codes](ValueSet-GEM-ERP-VS-DocumentType.md)
* [TI Environments ValueSet](ValueSet-ti-environment-vs.md)
* [TI FHIR Configuration ValueSet](ValueSet-ti-fhir-configuration-vs.md)
* [ValueSet der Flowtypes in TIFlow Anwendungen](ValueSet-ti-flowtypes-vs.md)
* [TIFLOW Operation Outcome Details VS](ValueSet-tiflow-operation-outcome-details-vs.md)

### Logicals

* [TI Feature Definition](StructureDefinition-ti-feature-definition.md)
* [Feature: WF160 - Flowtype für Apothekenpflichtige Arzneimittel](StructureDefinition-ti-flow-feature-wf160.md)
* [Feature: WF169 - Flowtype für Apothekenpflichtige Arzneimittel mit Steuerung durch den Leistungserbringer](StructureDefinition-ti-flow-feature-wf169.md)

### Complex-type Profiles

* [GEM_ERP_PR_Signature](StructureDefinition-GEM-ERP-PR-Signature.md)
* [TI Flow AccessCode](StructureDefinition-tiflow-access-code.md)
* [TI Flow Secret](StructureDefinition-tiflow-secret.md)

### Resource Profiles

* [GEM ERP PR Binary](StructureDefinition-GEM-ERP-PR-Binary.md)
* [GEM ERP PR Device](StructureDefinition-GEM-ERP-PR-Device.md)
* [GEM ERP PR Digest](StructureDefinition-GEM-ERP-PR-Digest.md)
* [TI Audit Event Rest](StructureDefinition-audit-event-rest.md)
* [Capability Statement Profil für den TI-Flow-Fachdienst](StructureDefinition-ti-flow-capability-statement.md)
* [Task für TIFlow Anwendungen](StructureDefinition-ti-task.md)
* [Bundle der $accept Operation](StructureDefinition-tiflow-op-accept-bundle.md)
* [TIFlow OperationOutcome](StructureDefinition-tiflow-operation-outcome.md)
* [TIFlow Receipt Bundle](StructureDefinition-tiflow-receipt-bundle.md)
* [GEM ERP PR Composition](StructureDefinition-tiflow-receipt-composition.md)

### Extensions

* [TI Environment](StructureDefinition-ti-environment.md)
* [TI Feature](StructureDefinition-ti-feature.md)
* [TI FHIR Configuration](StructureDefinition-ti-fhir-configuration.md)
* [TI Flow Type](StructureDefinition-ti-flowtype.md)
* [TI Flow AcceptDate](StructureDefinition-tiflow-accept-date.md)
* [TIFlow Beneficiary](StructureDefinition-tiflow-beneficiary.md)
* [TI Flow ExpiryDate](StructureDefinition-tiflow-expiry-date.md)

### CapabilityStatements

* [CapabilityStatement für den TI-Flow-Fachdienst](CapabilityStatement-ti-flow-fachdienst-server.md)

### ConceptMaps

* [Telemetry Data Status Codes Concept Map](ConceptMap-TIFLOW-CM-TelemetryDataStatusCodes.md)

### ImplementationGuides

* [TIFlow - Kernfunktionalitäten](index.md)

### SearchParameters

* [TaskAcceptDateSP](SearchParameter-TaskAcceptDateSP.md)
* [TaskExpiryDateSP](SearchParameter-TaskExpiryDateSP.md)

### Examples

* [ExampleCapabilityStatementServerPU (CapabilityStatement)](CapabilityStatement-ExampleCapabilityStatementServerPU.md)
