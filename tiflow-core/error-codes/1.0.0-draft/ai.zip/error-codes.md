# Fehlercodes - TIFlow - Kernfunktionalitäten v1.0.0-draft

TIFlow - Kernfunktionalitäten

Version 1.0.0-draft - ci-build 

* [**Table of Contents**](toc.md)
* **Fehlercodes**

## Fehlercodes

Der TI-Flow-Fachdienst stellt eine http-Schnittstelle für den Aufruf durch Clientsysteme bereit. Das Ergebnis der Operation wird in der Verwendung von Http-Status-Codes [HTTP-STATUS-CODES] mitgeteilt. Die folgende Tabelle listet die vom TI-Flow-Fachdienst genutzten Http-Status-Codes auf.

Der TI-Flow-Fachdienst MUSS beim Aufruf einer Operation im Http-Response-Header einen HTTP-Status-Codes gemäß [RFC7231] zurückgeben.
# HTTP Status Codes – TI-Flow-Fachdienst

| | | | |
| :--- | :--- | :--- | :--- |
| 200 | Operation erfolgreich beendet, in der Rückgabe ist ggfs. das Ergebnis der Operation enthalten | `GET /Task``GET /Task/<id>``GET /AuditEvent/``GET /Communication``GET /MedicationDispense``POST /Task/<id>/$activate``POST /Task/<id>/$accept``POST /Task/<id>/$dispense``POST /Task/<id>/$close``POST /Task/<id>/$eu-close``POST /$get-eu-prescriptions``GET /$read-eu-access-permission``PATCH /Task/<id>``GET /notifications/opt-in``GET /notifications/opt-out``GET /pushers``POST /pushers/set``GET /channels``GET /channels/{pushkey}``POST /channels/{pushkey}`GET, etc. für alle übrigen Operationen | Die Operation wurde erfolgreich bearbeitet. In der Rückgabe sind die erzeugten bzw. gelesenen Daten enthalten. |
| 201 | Neues Objekt wurde erfolgreich angelegt, in der Rückgabe ist das Objekt enthalten | `POST /Task/$create``POST /Task/<id>/$dispense``POST /$grant-eu-access-permission``POST /Communication` | Der TI-Flow-Fachdienst hat die Ressource in der angeforderten Operation erzeugt. |
| 204 | Die Operation liefert keinen Rückgabewert | `POST /Task/<id>/$abort``POST /Task/<id>/$reject``DELETE /Communication/<id>``DELETE /$revoke-eu-access-permission` | Das Löschen eines E-Rezepts löscht alle personenbezogenen und medizinischen Daten, daher gibt es keine Daten in der Rückgabe. Das Zurückweisen eines Rezepts bedeutet die Nicht-Bearbeitung durch eine Apotheke, daher sind hier keine Rückgabedaten erforderlich. |
| 400 | Bad Request, der Operationsaufruf enthält ungültige Daten | `POST /Task/$create``POST /Task/<id>/$activate``POST /Task/<id>/$accept``POST /Task/<id>/$dispense``POST /Task/<id>/$reject``POST /Task/<id>/$close``POST /Task/<id>/$abort``POST /Task/<id>/$eu-close``POST /$get-eu-prescriptions``POST /$grant-eu-access-permission``DELETE /$revoke-eu-access-permission``GET /$read-eu-access-permission``PATCH /Task/<id>``POST /Communication``GET /notifications/opt-in``GET /pushers``POST /pushers/set``GET /channels``GET /channels/{pushkey}``POST /channels/{pushkey}`GET, POST, etc. für alle übrigen Operationen | In der aufgerufenen Operation werden vom Client Daten für die Verarbeitung erwartet. Entsprechen sie nicht dem erwarteten FHIR-Profil oder sind sie ungültig (bspw. Signatur), werden sie vom TI-Flow-Fachdienst zurückgewiesen. |
| 401 | Der Nutzer konnte nicht authentifiziert werden | `GET /Task``GET /Task/<id>``GET /AuditEvent/``GET /Communication``GET /MedicationDispense``POST /Task/$create``POST /Task/<id>/$activate``POST /Task/<id>/$accept``POST /Task/<id>/$dispense``POST /Task/<id>/$reject``POST /Task/<id>/$close``POST /Task/<id>/$abort``POST /Task/<id>/$eu-close``POST /$get-eu-prescriptions``POST /$grant-eu-access-permission``DELETE /$revoke-eu-access-permission``GET /$read-eu-access-permission``PATCH /Task/<id>``POST /Communication``GET /pushers``POST /pushers/set``GET /channels``GET /channels/{pushkey}``POST /channels/{pushkey}` | Der Aufruf enthält keine oder abgelaufene oder ungültige Authentifizierungsinformationen im HTTP-Request-Header “Authorization”. |
| 403 | Der Nutzer ist nicht berechtigt, die aufgerufene Operation anzufordern | `GET /Task``GET /Task/<id>``GET /AuditEvent/``GET /Communication``GET /MedicationDispense``POST /Task/$create``POST /Task/<id>/$activate``POST /Task/<id>/$accept``POST /Task/<id>/$dispense``POST /Task/<id>/$reject``POST /Task/<id>/$close``POST /Task/<id>/$abort``POST /Task/<id>/$eu-close``POST /$get-eu-prescriptions``POST /$grant-eu-access-permission``DELETE /$revoke-eu-access-permission``GET /$read-eu-access-permission``PATCH /Task/<id>``POST /Communication``GET /pushers``POST /pushers/set``GET /channels``GET /channels/{pushkey}``POST /channels/{pushkey}` | Gemäß Rollenprüfung in jedem Operationsaufruf sind nur bestimmte Operationen je aufrufendem Nutzer zulässig. |
| 404 | Die adressierte Ressource wurde nicht gefunden | `GET /Task/<id>``POST /Task/<id>/$activate``POST /Task/<id>/$accept``POST /Task/<id>/$dispense``POST /Task/<id>/$reject``POST /Task/<id>/$close``POST /Task/<id>/$abort``POST /Task/<id>/$eu-close``PATCH /Task/<id>``GET /AuditEvent/<id>``GET /Communication/<id>``GET /notifications/opt-out` | Die über die`<id>`adressierte Ressource existiert nicht, d.h. wurde auch nicht zwischenzeitlich gelöscht (siehe Code 410). |
| 405 | Die Anfrage ist gültig, jedoch in Kombination mit anderen Aufrufparametern nicht gültig | `GET /Task``GET /Task/<id>``GET /AuditEvent/``GET /Communication``GET /MedicationDispense``POST /Task/$create``POST /Task/<id>/$activate``POST /Task/<id>/$accept``POST /Task/<id>/$dispense``POST /Task/<id>/$reject``POST /Task/<id>/$close``POST /Task/<id>/$abort``POST /Task/<id>/$eu-close``POST /$get-eu-prescriptions``POST /$grant-eu-access-permission``DELETE /$revoke-eu-access-permission``GET /$read-eu-access-permission``PATCH /Task/<id>``POST /Communication` | In der Operation wird eine unzulässige Kombination aus HTTP-Operation auf eine bestimmte Ressource ggfs. in Verbindung mit einer FHIR-Operation aufgerufen, z.B.`POST /AuditEvent`,`POST /Task/$activate`,`POST /Task/<id>/$create`,`PUT /<Ressource>/`,`HEAD /<Ressource>`,`DELETE /<Ressource/>`,`PATCH /<Ressource>` |
| 408 | Request Timeout – die Anfrage konnte innerhalb der erwarteten Zeit nicht beantwortet werden | `GET /Task``GET /Task/<id>``GET /AuditEvent/``GET /Communication``GET /MedicationDispense``POST /Task/$create``POST /Task/<id>/$activate``POST /Task/<id>/$accept``POST /Task/<id>/$dispense``POST /Task/<id>/$reject``POST /Task/<id>/$close``POST /Task/<id>/$abort``POST /Task/<id>/$eu-close``POST /$get-eu-prescriptions``POST /$grant-eu-access-permission``DELETE /$revoke-eu-access-permission``GET /$read-eu-access-permission``PATCH /Task/<id>``POST /Communication``GET /pushers``POST /pushers/set``GET /channels``GET /channels/{pushkey}``POST /channels/{pushkey}` | Der TI-Flow-Fachdienst ist überlastet und kann die Anfrage innerhalb der Wartezeit des Clients (PVS, AVS, FdV) nicht beantworten. |
| 409 | Konflikt im Aufruf verschiedener Nutzer um das gleiche Objekt | `POST /Task/<id>/$accept``POST /Task/<id>/$dispense``POST /Task/<id>/$abort` | Der Task des E-Rezepts hat einen Status, für den der gewünschte Zugriff unzulässig ist. Bspw.: Das E-Rezept befindet sich bereits in Belieferung durch einen Apotheker. Daher kann es vom Verordnenden und Versicherten nicht gelöscht werden ($abort) und von keinem anderen Apotheker heruntergeladen werden ($accept). |
| 410 | Das aufgerufene Objekt wurde zwischenzeitlich gelöscht | `GET /Task/<id>``POST /Task/<id>/$accept``POST /Task/<id>/$dispense``POST /Task/<id>/$abort` | Der Client (PVS, AVS, FdV) versucht ein E-Rezept zu lesen, das zwischenzeitlich gelöscht wurde. |
| 429 | Der Client hat zu viele Aufrufe innerhalb einer festgelegten Zeitspanne getätigt | `GET /Task``GET /Task/<id>``GET /AuditEvent/``GET /Communication``GET /MedicationDispense``POST /Task/$create``POST /Task/<id>/$activate``POST /Task/<id>/$accept``POST /Task/<id>/$reject``POST /Task/<id>/$close``POST /Task/<id>/$abort``POST /Task/<id>/$eu-close``POST /$get-eu-prescriptions``POST /$grant-eu-access-permission``PATCH /Task/<id>``POST /Communication``GET /pushers``POST /pushers/set``GET /channels``GET /channels/{pushkey}``POST /channels/{pushkey}` | Der Client (PVS, AVS, FdV) hat innerhalb des konfigurierten Zeitabschnitts zu viele Requests geschickt. |
| 500 | Interner Serverfehler | `GET /Task``GET /Task/<id>``GET /AuditEvent/``GET /Communication``GET /MedicationDispense``POST /Task/$create``POST /Task/<id>/$activate``POST /Task/<id>/$accept``POST /Task/<id>/$dispense``POST /Task/<id>/$reject``POST /Task/<id>/$close``POST /Task/<id>/$abort``POST /Communication`GET, POST, etc. für alle übrigen Operationen | In allen Operationen, die aufgrund eines internen Fehlers nicht bearbeitet werden können. Die Rückgabe liefert keine weiteren Informationen. |

**Tabelle: **Übersicht HTTP-Statuscodes TI-Flow-Fachdienst

Der TI-Flow-Fachdienst MUSS im Fehlerfall (http-Statuscodes >= 400) Hinweise zur Fehlerursache
* im der inneren http-Response-Body als FHIR-Ressource OperationOutcome
* falls keine innere VAU-Response existiert, in einem "äußeren" http-Response-Body in einer JSON-Struktur mit `"x-request-id", (http-)"status", "error"-Text, "message"-Details`
an den Client zurückgeben, ohne Implementierungsdetails (z.B. kein Stacktrace) preiszugeben und dabei sicherstellen, dass personenbezogene oder medizinische Daten, falls für die qualifizierte Fehlerbeschreibung notwendig, ausschließlich in der VAU-verschlüsselten inneren http-Response übertragen werden.
Die Fehlermeldung beinhaltet bei fachlichen Fehlern einen VAU-verschlüsselten inneren http-Response. In diesem inneren Response werden ggf. ausschliesslich personenbezogene oder medizinische Daten an den aufrufenden Client übermittelt, welche bereits im VAU-verschlüsselten inneren http-Request, welcher zum Fehler führte, enthalten waren. Das kann bspw. bei Fehlern bei der Prüfung der FHIR Konformität von Datensätzen auftreten.

Die Details des OperationOutcomes werden in den Anforderungen mit einer Tabelle wie unten beschrieben:

* HTTP-Code: Severity
  * HTTP-Status-Code: OperationOutcome.issue.severity
* HTTP-Code: Code
  * HTTP-Status-Code: OperationOutcome.issue.code
* HTTP-Code: Details Code
  * HTTP-Status-Code: OperationOutcome.issue.details.coding.code
* HTTP-Code: Details Text
  * HTTP-Status-Code: OperationOutcome.issue.details.coding.display / OperationOutcome.issue.details.text

Bei nicht FHIR-Fehlern werden ein HTTP Status Code und ein Fehlercode im Media Type *application/json* nach folgendem Schema zurückgegeben:

```

{
    "errorCode": "beispielFehlerCode"
}

```

Die Details werden in den Anforderungen mit einer Tabelle wie unten beschrieben dargestellt:

* HTTP-Code: Error Code
  * HTTP-Status-Code: beispielFehlerCode

Treten Fehler beim VAU-Transport (bspw. innerer http-Request kann nicht entschlüsselt werden) auf, beinhaltet die Fehlermeldung keinen inneren http-Response.

