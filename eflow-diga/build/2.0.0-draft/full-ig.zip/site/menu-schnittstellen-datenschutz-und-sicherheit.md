# Datenschutz und Sicherheit - Verordnungen fuer Digitale Gesundheitsanwendungen (DiGA) v2.0.0-draft

Verordnungen fuer Digitale Gesundheitsanwendungen (DiGA)

Version 2.0.0-draft - ci-build 

* [**Table of Contents**](toc.md)
* **Datenschutz und Sicherheit**

## Datenschutz und Sicherheit

Mit dem DiGA-Workflow erhalten zwei neue Akteure Zugriff auf den E-Rezept-Fachdienst: Kostenträger und Psychotherapeuten. Der Zugang der Kostenträger erfolgt über das zentrale Netz der TI, der Zugang der Psychotherapeuten über ihre bestehende TI-Anbindung.

Der Schutzbedarf einer DiGA-Verordnung ist mit dem von Arzneimittelverordnungen vergleichbar. Der Freischaltcode ist Teil der Abgabeinformation und unterliegt somit dem gleichen Schutzbedarf. Der Zugriff wird für den Versicherten protokolliert.

Das Einlösen erfolgt vorzugsweise über ein E-Rezept-FdV. Alternativ können Versicherte einen Patientenausdruck per Post an den Kostenträger senden oder falls angeboten, den Patientenausdruck über die Service-App der Krankenkasse einscannen.

