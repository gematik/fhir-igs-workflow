# Anforderungen an den verordnende Primärsystem für die $activate-Operation - Verordnungen fuer Digitale Gesundheitsanwendungen (DiGA) v2.0.0-draft

Verordnungen fuer Digitale Gesundheitsanwendungen (DiGA)

Version 2.0.0-draft - ci-build 

* [**Table of Contents**](toc.md)
* [**Operation API**](operation-api.md)
* [**Operation: $activate**](op-activate.md)
* **Anforderungen an den verordnende Primärsystem für die $activate-Operation**

## Anforderungen an den verordnende Primärsystem für die $activate-Operation

lskdhfladshf

AFOs Server

