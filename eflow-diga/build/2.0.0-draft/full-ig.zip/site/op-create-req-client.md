
<!-- Quelle: A_26373 - PS verordnende LEI: keine elektronische Verordnung einer DiGA zu Lasten BG/UK -->
<requirement conformance="SHALL NOT" key="IG-TIFlow-DiGA-NEU" title="PS verordnende LEI: keine elektronische Verordnung einer DiGA zu Lasten BG/UK" version="0">
  <meta lockversion="false"/>
  <actor name="CS_E-Rezept_KTR">
    <testProcedure id="Herstellererklärung"/>
  </actor>
  Das PS der verordnenden LEI DARF bei der Verordnung einer DiGA zu Lasten einer Berufsgenossenschaft oder Unfallkasse NICHT die elektronische Verordnung nutzen.
</requirement>
