# Additional APIs - Verordnungen fuer Digitale Gesundheitsanwendungen (DiGA) v2.0.0-draft

Verordnungen fuer Digitale Gesundheitsanwendungen (DiGA)

Version 2.0.0-draft - ci-build 

* [**Table of Contents**](toc.md)
* **Additional APIs**

## Additional APIs

Diese Seite beschreibt zusätzliche APIs für den DiGA-Workflow. Derzeit sind keine weiteren APIs über die Query und Operation API hinaus definiert.

