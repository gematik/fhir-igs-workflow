# Release Notes - Verordnungen für Digitale Gesundheitsanwendungen (DiGA) v2.0.0-draft

Verordnungen für Digitale Gesundheitsanwendungen (DiGA)

Version 2.0.0-draft - ci-build 

* [**Table of Contents**](toc.md)
* **Release Notes**

## Release Notes

Release Notes

* 2.0.0-draft: Initiale Struktur des DiGA-IG.

