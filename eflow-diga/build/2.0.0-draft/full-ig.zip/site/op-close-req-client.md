<!-- Quelle: A_26004 - PS Kostenträger: Quittung abrufen - Flowtype 162 - MedicationDispense erstellen -->
<requirement conformance="SHALL" key="IG-TIFlow-DiGA-NEU" title="PS Kostenträger: Quittung abrufen - Flowtype 162 - MedicationDispense erstellen" version="0">
  <meta lockversion="false"/>
  <actor name="CS_E-Rezept_KTR">
    <testProcedure id="Konformitätsbestätigung"/>
  </actor>
  Das Clientsystem des Kostenträgers MUSS im Anwendungsfall "Quittung abrufen" eine FHIR-Ressource mit dem Profil GEM_ERP_PR_MedicationDispense_DiGA erstellen.
</requirement>

