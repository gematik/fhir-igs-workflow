# Apache Licence - Verordnungen fuer Digitale Gesundheitsanwendungen (DiGA) v2.0.0-draft

Verordnungen fuer Digitale Gesundheitsanwendungen (DiGA)

Version 2.0.0-draft - ci-build 

* [**Table of Contents**](toc.md)
* **Apache Licence**

## Apache Licence

Apache Licence

Die Lizenzinformationen fuer diesen IG entsprechen der Apache License 2.0.

