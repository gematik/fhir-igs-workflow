# de.gematik.eflow-diga#2.0.0-draft: Verordnungen für Digitale Gesundheitsanwendungen (DiGA)

## Pages

* [Implementation Guide elektronische Verordnung von DiGAs](index.md)
* [API FHIR-VZD](api-add-fhirvzd.md)
* [Systemüberblick](menu-technische-umsetzung-systemueberblick.md)
* [Anforderungen an das E-Rezept-FdV für Communication API](query-api-communication-req-fdv.md)
* [Anforderungen an das Clientsystem des Kostenträgers für Communication API](query-api-communication-req-ktr.md)
* [Additional APIs](menu-schnittstellen-additional-api.md)
* [Datenschutz und Informationssicherheit](menu-datenschutz-und-sicherheit.md)
* [Anforderungen an den E-Rezept-Fachdienst für die $activate-Operation](op-activate-req-server.md)
* [Query API](query-api.md)
* [Query API: Communication](query-api-communication.md)
* [Operation: $create](op-create.md)
* [Query API: Task](query-api-task.md)
* [Operation: $reject](op-reject.md)
* [Anforderungen an den E-Rezept-Fachdienst für die $close-Operation](op-close-req-server.md)
* [FHIR-Artefakte](artifacts.md)
* [Generelle Prinzipien](menu-schnittstellen-generelle-prinzipien.md)
* [Verarbeitungsregeln](menu-technische-umsetzung-verarbeitungsregeln.md)
* [Anforderungen an den verordnende Primärsystem für die $create-Operation](op-create-req-client.md)
* [Operation API](operation-api.md)
* [Operation: $close](op-close.md)
* [Technische Anwendungsfälle](menu-technische-umsetzung-anwendungsfaelle.md)
* [Operation: $accept](op-accept.md)
* [Release Notes](release-notes.md)
* [Referenzen](referenced.md)
* [Operation: $activate](op-activate.md)
* [Anforderungen an das Clientsystem des Kostenträgers für die $close-Operation](op-close-req-client.md)
* [Elektronische Verordnung von DiGAs](menu-fachlichkeit-diga.md)
* [Apache Licence](license.md)
* [Query API: MedicationDispense](query-api-medicationdispense.md)
* [Steckbriefe](spec-sheet.md)
* [Downloads](downloads.md)

## Resources

### Logicals

* [Logical DiGA Medication Dispense](StructureDefinition-GEM-ERP-LOG-MedicationDispense-DiGA.md)

### Resource Profiles

* [GEM ERP PR Communication DiGA](StructureDefinition-GEM-ERP-PR-Communication-DiGA.md)
* [GEM ERP PR MedicationDispense DiGA](StructureDefinition-GEM-ERP-PR-MedicationDispense-DiGA.md)
* [GEM ERP PR CloseOperation Input](StructureDefinition-GEM-ERP-PR-PAR-CloseOperation-Input.md)

### Extensions

* [GEM ERP EX DeepLink](StructureDefinition-GEM-ERP-EX-DeepLink.md)
* [GEM ERP EX RedeemCode](StructureDefinition-GEM-ERP-EX-RedeemCode.md)

### ImplementationGuides

* [Verordnungen für Digitale Gesundheitsanwendungen (DiGA)](index.md)

### Examples

* [140f716f-f649-44fe-9a4e-157eb3c8adf3 (Communication)](Communication-140f716f-f649-44fe-9a4e-157eb3c8adf3.md)
* [2be1c6ac-5d10-47f6-84ee-8318b2c22c76 (Communication)](Communication-2be1c6ac-5d10-47f6-84ee-8318b2c22c76.md)
* [Example-MedicationDispense-DiGA-DeepLink (MedicationDispense)](MedicationDispense-Example-MedicationDispense-DiGA-DeepLink.md)
* [Example-MedicationDispense-DiGA-Name-And-PZN (MedicationDispense)](MedicationDispense-Example-MedicationDispense-DiGA-Name-And-PZN.md)
* [Example-MedicationDispense-DiGA-NoRedeemCode (MedicationDispense)](MedicationDispense-Example-MedicationDispense-DiGA-NoRedeemCode.md)
* [ExampleCloseInputParametersDiGA (Parameters)](Parameters-ExampleCloseInputParametersDiGA.md)
