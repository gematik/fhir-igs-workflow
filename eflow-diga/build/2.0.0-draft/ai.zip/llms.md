# de.gematik.eflow-diga#2.0.0-draft: Verordnungen für Digitale Gesundheitsanwendungen (DiGA)

## Pages

* [Implementation Guide elektronische Verordnung von DiGAs](index.md)
* [Anforderungen an den verordnende Primärsystem für die $activate-Operation](op-activate-req-pvs.md)
* [Anforderungen an den verordnende Primärsystem für die $abort-Operation](op-abort-req-pvs.md)
* [Operation API](operation-api.md)
* [KTR-Anforderungen: Communication-Query](query-api-communication-req-ktr.md)
* [Anforderungen an den E-Rezept-Fachdienst für die $close-Operation](op-close-req-fd.md)
* [Anforderungen an den E-Rezept-Fachdienst für die $accept-Operation](op-accept-req-fd.md)
* [Generelle Prinzipien](menu-schnittstellen-generelle-prinzipien.md)
* [Operation: $abort](op-abort.md)
* [Query API: MedicationDispense](query-api-medicationdispense.md)
* [Operation: $accept](op-accept.md)
* [Anforderungen an den E-Rezept-Fachdienst für die $activate-Operation](op-activate-req-fd.md)
* [Anforderungen an den E-Rezept-Fachdienst für die $create-Operation](op-create-req-fd.md)
* [Anforderungen an den E-Rezept-Fachdienst für die $reject-Operation](op-reject-req-fd.md)
* [Release Notes](release-notes.md)
* [Referenzen](referenced.md)
* [FHIR-Artefakte](artifacts.md)
* [API FHIR-VZD](api-add-fhirvzd.md)
* [Query API](query-api.md)
* [Query API: Communication](query-api-communication.md)
* [Anforderungen an das Clientsystem des Kostenträger für die $reject-Operation](op-reject-req-ktr.md)
* [Downloads](downloads.md)
* [Operation: $activate](op-activate.md)
* [Verarbeitungsregeln](menu-technische-umsetzung-verarbeitungsregeln.md)
* [FD-Anforderungen: Communication-Query](query-api-communication-req-fd.md)
* [Apache Licence](license.md)
* [FdV-Anforderungen: Communication-Query](query-api-communication-req-fdv.md)
* [Operation: $reject](op-reject.md)
* [Operation: $create](op-create.md)
* [Anforderungen an das Clientsystem des Kostenträger für die $close-Operation](op-close-req-ktr.md)
* [Systemüberblick](menu-technische-umsetzung-systemueberblick.md)
* [Operation: $close](op-close.md)
* [Elektronische Verordnung von DiGAs](menu-fachlichkeit-diga.md)
* [Additional APIs](menu-schnittstellen-additional-api.md)
* [Technische Anwendungsfälle](menu-technische-umsetzung-anwendungsfaelle.md)
* [Steckbriefe](spec-sheet.md)
* [Anforderungen an das Clientsystem des Kostenträger für die $accept-Operation](op-accept-req-ktr.md)
* [Anforderungen an den verordnende Primärsystem für die $create-Operation](op-create-req-pvs.md)
* [Query API: Task](query-api-task.md)
* [Datenschutz und Informationssicherheit](menu-datenschutz-und-sicherheit.md)
* [Anforderungen an den E-Rezept-Fachdienst für die $abort-Operation](op-abort-req-fd.md)

## Resources

### Logicals

* [Logical DiGA Medication Dispense](StructureDefinition-GEM-ERP-LOG-MedicationDispense-DiGA.md)

### Resource Profiles

* [GEM ERP PR Communication DiGA](StructureDefinition-GEM-ERP-PR-Communication-DiGA.md)
* [GEM ERP PR MedicationDispense DiGA](StructureDefinition-GEM-ERP-PR-MedicationDispense-DiGA.md)
* [GEM ERP PR CloseOperation Input](StructureDefinition-GEM-ERP-PR-PAR-CloseOperation-Input.md)

### Extensions

* [GEM ERP EX DeepLink](StructureDefinition-GEM-ERP-EX-DeepLink.md)
* [GEM ERP EX RedeemCode](StructureDefinition-GEM-ERP-EX-RedeemCode.md)

### ImplementationGuides

* [Verordnungen für Digitale Gesundheitsanwendungen (DiGA)](index.md)

### Examples

* [140f716f-f649-44fe-9a4e-157eb3c8adf3 (Communication)](Communication-140f716f-f649-44fe-9a4e-157eb3c8adf3.md)
* [2be1c6ac-5d10-47f6-84ee-8318b2c22c76 (Communication)](Communication-2be1c6ac-5d10-47f6-84ee-8318b2c22c76.md)
* [Example-MedicationDispense-DiGA-DeepLink (MedicationDispense)](MedicationDispense-Example-MedicationDispense-DiGA-DeepLink.md)
* [Example-MedicationDispense-DiGA-Name-And-PZN (MedicationDispense)](MedicationDispense-Example-MedicationDispense-DiGA-Name-And-PZN.md)
* [Example-MedicationDispense-DiGA-NoRedeemCode (MedicationDispense)](MedicationDispense-Example-MedicationDispense-DiGA-NoRedeemCode.md)
* [ExampleCloseInputParametersDiGA (Parameters)](Parameters-ExampleCloseInputParametersDiGA.md)
