# Steckbriefe - Verordnungen fuer Digitale Gesundheitsanwendungen (DiGA) v2.0.0-draft

Verordnungen fuer Digitale Gesundheitsanwendungen (DiGA)

Version 2.0.0-draft - ci-build 

* [**Table of Contents**](toc.md)
* **Steckbriefe**

## Steckbriefe

Steckbriefe

Steckbriefe für Produkt- und Anbietertypen werden in einer späteren Version bereitgestellt.

