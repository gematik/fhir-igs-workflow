# Referenzen - Verordnungen für Digitale Gesundheitsanwendungen (DiGA) v2.0.0-draft

Verordnungen für Digitale Gesundheitsanwendungen (DiGA)

Version 2.0.0-draft - ci-build 

* [**Table of Contents**](toc.md)
* **Referenzen**

## Referenzen

Referenzen

* Feature-Spezifikation DiGA: gemF_eRp_DiGA_2.0.0_CC
* Basis-Workflow: gemSysL_eRp
* E-Rezept-Fachdienst: gemSpec_FD_eRp
* DiGA Verzeichnis (BfArM): https://diga.bfarm.de/de
* eVDGA FHIR Profile: https://simplifier.net/evdga

