# Query API: Task - E-Rezept fuer Digitale Gesundheitsanwendungen (DiGA) v2.0.0-draft

E-Rezept fuer Digitale Gesundheitsanwendungen (DiGA)

Version 2.0.0-draft - ci-build 

* [**Table of Contents**](toc.md)
* [**Query API**](query-api.md)
* **Query API: Task**

## Query API: Task

Query API: Task

Die Query API für Task beschreibt den lesenden Zugriff auf Tasks. Der Versicherte ruft die Liste aller seiner Verordnungen inklusive DiGA-Verordnungen ab. Der Versicherte kann mit Referenz auf eine Task-ID eine einzelne Verordnung abrufen.

## GET /Task (Suche)

* Der Aufruf basiert auf dem GET /Task Aufruf des Basis-Workflow für E-Rezepte.

## GET /Task/ (Details)

* Der Aufruf basiert auf dem GET /Task/ Aufruf des Basis-Workflow für E-Rezepte.

