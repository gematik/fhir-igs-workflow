# Implementation Guide E-Rezept-Fachdienst - TIFlow - Abrechnungsinformationen v0.9.0

TIFlow - Abrechnungsinformationen

Version 0.9.0 - ci-build 

* [**Table of Contents**](toc.md)
* **Implementation Guide E-Rezept-Fachdienst**

## Implementation Guide E-Rezept-Fachdienst

| | |
| :--- | :--- |
| *Official URL*:https://gematik.de/fhir/tiflow/chargeitem/ImplementationGuide/de.gematik.tiflow.chargeitem | *Version*:0.9.0 |
| Draft as of 2026-03-23 | *Computable Name*:gemIG_TIFlow_chargeitem |

Dieser Implementation Guide beschreibt die Bereitstellung der Abrechnungsinformationen für den Kostenträger. Er ergänzt die workflowspezifischen Anforderungen des E-Rezept-Fachdienstes und beschreibt die relevanten Use Cases.

### Zweck und Geltungsbereich

* Verwaltung von Abrechnungsinformationen von E-Rezepten für PKV-Versicherte
* Bereitstellen von Abrechnungsinformationen von E-Rezepten durch das AVS

### Nicht im Scope

* Arzneimittelspezifische Workflows zur Belieferung von E-Rezepten
* Nicht apothekenpflichtige Verordnungen
* Abrechnung ausserhalb des E-Rezept-Fachdienstes

### Anforderungen zur Umsetzung des IGs

Der E-Rezept-Fachdienst und dessen Clients MÜSSEN zur Umsetzung der Verwaltung von Abrechnungsinformationen zu Arzneimitteln den Implementation Guide "Abrechnungsinformationen zu E-Rezepten für PKV-Versicherte" umsetzen.

Der E-Rezept-Fachdienst und dessen Clients MÜSSEN zur Umsetzung des Implementation Guides "Abrechnungsinformationen zu E-Rezepten für PKV-Versicherte" alle Anforderungen und FHIR-Artefakte umsetzen, die in diesem IG definiert sind, sowie Anforderungen und Artefakte aus [gemIG_TIFlow_core], die in diesem IG referenziert werden.
### Wie dieser IG zu lesen ist

Die Kapitel folgen der Struktur Fachlichkeit, Technische Umsetzung und Schnittstellen. Szenarien und Anwendungsfälle verweisen auf die zugehörigen technischen Kapitel und Profile.

### Abhängigkeiten







### Kontakt und Feedback

Für Fragen und Feedback wenden Sie sich bitte an [erp-umsetzung@gematik.de](mailto:erp-umsetzung@gematik.de).

### Rechtliche Hinweise

Copyright ©2026+ gematik GmbH

HL7®, HEALTH LEVEL SEVEN®, FHIR® und das FHIR®-Logo sind Marken von Health Level Seven International.

