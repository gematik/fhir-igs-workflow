# ChargeItem searchset response for ERP-CHRG - TIFlow - Abrechnungsinformationen v1.0.0-draft

TIFlow - Abrechnungsinformationen

Version 1.0.0-draft - ci-build 

* [**Table of Contents**](toc.md)
* [**FHIR-Artefakte**](artifacts.md)
* **ChargeItem searchset response for ERP-CHRG**

## Example Bundle: ChargeItem searchset response for ERP-CHRG



## Resource Content

```json
{
  "resourceType" : "Bundle",
  "id" : "ExampleERPCHRGChargeItemSearchset",
  "type" : "searchset",
  "total" : 1,
  "link" : [{
    "relation" : "self",
    "url" : "https://erp-ref.example.org/ChargeItem?_count=1"
  }],
  "entry" : [{
    "fullUrl" : "https://erp-ref.example.org/ChargeItem/ChargeItem-GET-Completed",
    "resource" : {
      "resourceType" : "ChargeItem",
      "id" : "ChargeItem-GET-Completed",
      "meta" : {
        "profile" : ["https://gematik.de/fhir/erpchrg/StructureDefinition/GEM_ERPCHRG_PR_ChargeItem|1.1"]
      },
      "extension" : [{
        "extension" : [{
          "url" : "insuranceProvider",
          "valueBoolean" : false
        },
        {
          "url" : "subsidy",
          "valueBoolean" : false
        },
        {
          "url" : "taxOffice",
          "valueBoolean" : false
        }],
        "url" : "https://gematik.de/fhir/erpchrg/StructureDefinition/GEM_ERPCHRG_EX_MarkingFlag"
      }],
      "identifier" : [{
        "system" : "https://gematik.de/fhir/erp/NamingSystem/GEM_ERP_NS_PrescriptionId",
        "value" : "200.000.000.000.000.01"
      },
      {
        "system" : "https://gematik.de/fhir/erp/NamingSystem/GEM_ERP_NS_AccessCode",
        "value" : "777bea0e13cc9c42ceec14aec3ddee2263325dc2c6c699db115f58fe423607ea"
      }],
      "status" : "billable",
      "code" : {
        "coding" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/data-absent-reason",
          "code" : "not-applicable"
        }]
      },
      "subject" : {
        "identifier" : {
          "system" : "http://fhir.de/sid/gkv/kvid-10",
          "value" : "P987654321"
        }
      },
      "enterer" : {
        "identifier" : {
          "system" : "https://gematik.de/fhir/sid/telematik-id",
          "value" : "3-2-APO-XanthippeVeilchenblau01"
        }
      },
      "enteredDate" : "2025-10-01T15:29:00.434+00:00",
      "supportingInformation" : [{
        "reference" : "Bundle/72bd741c-7ad8-41d8-97c3-9aabbdd0f5b4",
        "display" : "http://fhir.abda.de/eRezeptAbgabedaten/StructureDefinition/DAV-PKV-PR-ERP-AbgabedatenBundle"
      },
      {
        "reference" : "Bundle/200.000.000.000.000.01",
        "display" : "https://gematik.de/fhir/erp/StructureDefinition/GEM_ERP_PR_Bundle"
      },
      {
        "reference" : "Bundle/0428d416-149e-48a4-977c-394887b3d85c",
        "display" : "https://fhir.kbv.de/StructureDefinition/KBV_PR_ERP_Bundle"
      }]
    },
    "search" : {
      "mode" : "match"
    }
  }]
}

```
