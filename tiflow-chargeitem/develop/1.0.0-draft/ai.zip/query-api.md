# Query API - TIFlow - Abrechnungsinformationen v1.0.0-draft

TIFlow - Abrechnungsinformationen

Version 1.0.0-draft - ci-build 

* [**Table of Contents**](toc.md)
* **Query API**

## Query API

Diese Seite bietet einen Einstieg in die Query‑API‑Seiten der einzelnen FHIR‑Ressourcen.

### Ressourcen

* [ChargeItem](./query-api-chargeitem.md)
* [Consent](./query-api-consent.md)
* [Communication](./query-api-communication.md)

