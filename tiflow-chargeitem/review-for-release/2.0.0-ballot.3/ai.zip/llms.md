# de.gematik.tiflow.chargeitem#2.0.0-ballot.3: Implementation Guide TIFlow - Abrechnungsinformationen

## Pages

* [Implementation Guide TI-Flow-Fachdienst](index.md)
* [FD-Anforderungen: Communication-Query](query-api-communication-req-fd.md)
* [Systemüberblick](menu-technische-umsetzung-systemueberblick.md)
* [AVS-Anforderungen: Communication-Query](query-api-communication-req-avs.md)
* [FD-Anforderungen: Consent-Query](query-api-consent-req-fd.md)
* [Verarbeitungsregeln für den TI-Flow-Fachdienst](menu-technische-umsetzung-verarbeitungsregeln.md)
* [Abrechnungsinformationen des E-Rezepts für PKV-Versicherte](menu-fachlichkeit-szenario-pkv.md)
* [Query API: Communication](query-api-communication.md)
* [Datenschutz und Sicherheit](menu-technische-umsetzung-datenschutz-und-sicherheit.md)
* [FD-Anforderungen: ChargeItem-Query](query-api-chargeitem-req-fd.md)
* [Query API](query-api.md)
* [FdV-Anforderungen: Communication-Query](query-api-communication-req-fdv.md)
* [Löschfristen](ttl.md)
* [FHIR-Artefakte](artifacts.md)
* [Query API: Consent](query-api-consent.md)
* [Query API: ChargeItem](query-api-chargeitem.md)
* [Release Notes](release-notes.md)
* [FdV-Anforderungen: Consent-Query](query-api-consent-req-fdv.md)
* [Zugriffsprotokollierung mit AuditEvent](menu-technische-umsetzung-audit-service.md)
* [FdV-Anforderungen: ChargeItem-Query](query-api-chargeitem-req-fdv.md)
* [AVS-Anforderungen: ChargeItem-Query](query-api-chargeitem-req-avs.md)
* [Downloads](downloads.md)
* [Apache Licence](license.md)
* [Referenzen](referenced.md)
* [Technische Anwendungsfälle](menu-technische-umsetzung-anwendungsfaelle.md)

## Resources

### CodeSystems

* [CodeSystem of types for a consent](CodeSystem-GEM-ERPCHRG-CS-ConsentType.md)
* [TIFLOW ChargeItem Operation Outcome Details CS](CodeSystem-tiflow-chargeitem-operation-outcome-details-cs.md)

### ValueSets

* [ValueSet of Consent Codes](ValueSet-GEM-ERPCHRG-VS-ConsentType.md)
* [TIFLOW ChargeItem Operation Outcome Details VS](ValueSet-tiflow-chargeitem-operation-outcome-details-vs.md)

### Resource Profiles

* [GEM_ERPCHRG_PR_ChargeItem](StructureDefinition-GEM-ERPCHRG-PR-ChargeItem.md)
* [Reply on change Request on ChargeItem from pharmacy to Patient](StructureDefinition-GEM-ERPCHRG-PR-Communication-ChargChangeReply.md)
* [Request for Modification on ChargeItem](StructureDefinition-GEM-ERPCHRG-PR-Communication-ChargChangeReq.md)
* [GEM_ERPCHRG_PR_Consent](StructureDefinition-GEM-ERPCHRG-PR-Consent.md)
* [GEM ERPCHRG PR PAR Patch ChargeItem Input Parameter](StructureDefinition-GEM-ERPCHRG-PR-PAR-Patch-ChargeItem-Input.md)

### Extensions

* [GEM_ERPCHRG_EX_MarkingFlag](StructureDefinition-GEM-ERPCHRG-EX-MarkingFlag.md)

### CapabilityStatements

* [ERPCHRG CapabilityStatement für den E-Rezept-Fachdienst](CapabilityStatement-ti-flow-fachdienst-server-erpchrg.md)

### ImplementationGuides

* [Implementation Guide TIFlow - Abrechnungsinformationen](index.md)

### Examples

* [0428d416-149e-48a4-977c-394887b3d85c (Bundle)](Bundle-0428d416-149e-48a4-977c-394887b3d85c.md)
* [200.000.000.000.000.01 (Bundle)](Bundle-200.000.000.000.000.01.md)
* [72bd741c-7ad8-41d8-97c3-9aabbdd0f5b4 (Bundle)](Bundle-72bd741c-7ad8-41d8-97c3-9aabbdd0f5b4.md)
* [ExampleERPCHRGChargeItemSearchset (Bundle)](Bundle-ExampleERPCHRGChargeItemSearchset.md)
* [ExampleERPCHRGCommunicationSearchset (Bundle)](Bundle-ExampleERPCHRGCommunicationSearchset.md)
* [ExampleERPCHRGConsentSearchset (Bundle)](Bundle-ExampleERPCHRGConsentSearchset.md)
* [ChargeItem-GET-Completed (ChargeItem)](ChargeItem-ChargeItem-GET-Completed.md)
* [ChargeItem-POST-Binary (ChargeItem)](ChargeItem-ChargeItem-POST-Binary.md)
* [a51520ec-0899-404f-bb97-fe7d461f90a8 (ChargeItem)](ChargeItem-a51520ec-0899-404f-bb97-fe7d461f90a8.md)
* [3bbc2209-9c23-4553-986e-a5c9f69a39fb-1 (Communication)](Communication-3bbc2209-9c23-4553-986e-a5c9f69a39fb-1.md)
* [3bbc2209-9c23-4553-986e-a5c9f69a39fb (Communication)](Communication-3bbc2209-9c23-4553-986e-a5c9f69a39fb.md)
* [b4cf7f71-3ade-40ab-97a9-929f95af29f2-1 (Communication)](Communication-b4cf7f71-3ade-40ab-97a9-929f95af29f2-1.md)
* [b4cf7f71-3ade-40ab-97a9-929f95af29f2 (Communication)](Communication-b4cf7f71-3ade-40ab-97a9-929f95af29f2.md)
* [0dcc5d4c-bf24-4c06-b02e-be5bc24587e2 (Consent)](Consent-0dcc5d4c-bf24-4c06-b02e-be5bc24587e2.md)
* [ChargeItemConsent-Request (Consent)](Consent-ChargeItemConsent-Request.md)
* [ChargeItem-PATCH-Input (Parameters)](Parameters-ChargeItem-PATCH-Input.md)
* [Example-Parameters-Patch-ChargeItem-1 (Parameters)](Parameters-Example-Parameters-Patch-ChargeItem-1.md)
* [Example-Parameters-Patch-ChargeItem-2 (Parameters)](Parameters-Example-Parameters-Patch-ChargeItem-2.md)
