# Communication message sent by patient to pharmacy to request the change of an existing ChargeItem by providing the AccessCode - Implementation Guide TIFlow - Abrechnungsinformationen v2.0.0-ballot.3

Implementation Guide

TIFlow - Abrechnungsinformationen

Version 2.0.0-ballot.3 - ballot 

* [**Table of Contents**](toc.md)
* [**FHIR-Artefakte**](artifacts.md)
* **Communication message sent by patient to pharmacy to request the change of an existing ChargeItem by providing the AccessCode**

## Example Communication: Communication message sent by patient to pharmacy to request the change of an existing ChargeItem by providing the AccessCode



## Resource Content

```json
{
  "resourceType" : "Communication",
  "id" : "b4cf7f71-3ade-40ab-97a9-929f95af29f2-1",
  "meta" : {
    "profile" : ["https://gematik.de/fhir/erpchrg/StructureDefinition/GEM_ERPCHRG_PR_Communication_ChargChangeReq"],
    "tag" : [{
      "display" : "Communication message sent by patient to pharmacy to request the change of an existing ChargeItem by providing the AccessCode"
    }]
  },
  "basedOn" : [{
    "reference" : "ChargeItem/a51520ec-0899-404f-bb97-fe7d461f90a8"
  }],
  "status" : "unknown",
  "recipient" : [{
    "identifier" : {
      "system" : "https://gematik.de/fhir/sid/telematik-id",
      "value" : "3-2-APO-XanthippeVeilchenblau01"
    }
  }],
  "sender" : {
    "identifier" : {
      "system" : "http://fhir.de/sid/gkv/kvid-10",
      "value" : "P987654321"
    }
  },
  "payload" : [{
    "contentString" : "Bitte meinen Namen in Günther ändern, Waltraud ist falsch."
  }]
}

```
