# Communication message sent by pharmacy to patient in response to a previous ChargeItem-related message - Implementation Guide TIFlow - Abrechnungsinformationen v2.0.0-ballot.3

Implementation Guide

TIFlow - Abrechnungsinformationen

Version 2.0.0-ballot.3 - ballot 

* [**Table of Contents**](toc.md)
* [**FHIR-Artefakte**](artifacts.md)
* **Communication message sent by pharmacy to patient in response to a previous ChargeItem-related message**

## Example Communication: Communication message sent by pharmacy to patient in response to a previous ChargeItem-related message



## Resource Content

```json
{
  "resourceType" : "Communication",
  "id" : "3bbc2209-9c23-4553-986e-a5c9f69a39fb-1",
  "meta" : {
    "profile" : ["https://gematik.de/fhir/erpchrg/StructureDefinition/GEM_ERPCHRG_PR_Communication_ChargChangeReply"],
    "tag" : [{
      "display" : "Communication message sent by pharmacy to patient in response to a previous ChargeItem-related message"
    }]
  },
  "basedOn" : [{
    "reference" : "ChargeItem/a51520ec-0899-404f-bb97-fe7d461f90a8"
  }],
  "status" : "unknown",
  "recipient" : [{
    "identifier" : {
      "system" : "http://fhir.de/sid/gkv/kvid-10",
      "value" : "P987654321"
    }
  }],
  "sender" : {
    "identifier" : {
      "system" : "https://gematik.de/fhir/sid/telematik-id",
      "value" : "3-2-APO-XanthippeVeilchenblau01"
    }
  },
  "payload" : [{
    "contentString" : "Erledigt."
  }]
}

```
