# ChargeItem with contained Binary to Fachdienst - Implementation Guide TIFlow - Abrechnungsinformationen v2.0.0-ballot.3

Implementation Guide

TIFlow - Abrechnungsinformationen

Version 2.0.0-ballot.3 - ballot 

* [**Table of Contents**](toc.md)
* [**FHIR-Artefakte**](artifacts.md)
* **ChargeItem with contained Binary to Fachdienst**

## Example ChargeItem: ChargeItem with contained Binary to Fachdienst



## Resource Content

```json
{
  "resourceType" : "ChargeItem",
  "id" : "ChargeItem-POST-Binary",
  "meta" : {
    "profile" : ["https://gematik.de/fhir/erpchrg/StructureDefinition/GEM_ERPCHRG_PR_ChargeItem"]
  },
  "contained" : [{
    "resourceType" : "Binary",
    "id" : "c8720f99-6641-432d-94be-d49eaa164755",
    "contentType" : "application/pkcs7-mime",
    "data" : "bWVycnkgY2hyaXN0bWFz"
  }],
  "identifier" : [{
    "system" : "https://gematik.de/fhir/erp/NamingSystem/GEM_ERP_NS_PrescriptionId",
    "value" : "200.000.000.000.000.01"
  },
  {
    "system" : "https://gematik.de/fhir/erp/NamingSystem/GEM_ERP_NS_AccessCode",
    "value" : "777bea0e13cc9c42ceec14aec3ddee2263325dc2c6c699db115f58fe423607ea"
  }],
  "status" : "billable",
  "code" : {
    "coding" : [{
      "system" : "http://terminology.hl7.org/CodeSystem/data-absent-reason",
      "code" : "not-applicable"
    }]
  },
  "subject" : {
    "identifier" : {
      "system" : "http://fhir.de/sid/gkv/kvid-10",
      "value" : "P987654321"
    }
  },
  "enterer" : {
    "identifier" : {
      "system" : "https://gematik.de/fhir/sid/telematik-id",
      "value" : "3-2-APO-XanthippeVeilchenblau01"
    }
  },
  "enteredDate" : "2028-10-01T15:29:00.434+00:00",
  "supportingInformation" : [{
    "reference" : "#c8720f99-6641-432d-94be-d49eaa164755",
    "display" : "Binary"
  }]
}

```
