# Example Close Parameters - E-Rezept für Arzneimittel v1.0.0-test

E-Rezept für Arzneimittel

Version 1.0.0-test - ci-build 

* [**Table of Contents**](toc.md)
* [**FHIR-Artefakte**](artifacts.md)
* **Example Close Parameters**

## Example Parameters: Example Close Parameters



## Resource Content

```json
{
  "resourceType" : "Parameters",
  "id" : "ExampleCloseInputParametersRezeptur",
  "meta" : {
    "profile" : ["https://gematik.de/fhir/erp/StructureDefinition/eflow-rx-close-operation-input-parameters"]
  },
  "parameter" : [{
    "name" : "rxDispensation",
    "part" : [{
      "name" : "medicationDispense",
      "resource" : {
        "resourceType" : "MedicationDispense",
        "id" : "Example-MedicationDispense-Rezeptur",
        "meta" : {
          "profile" : ["https://gematik.de/fhir/erp/StructureDefinition/GEM-ERP-PR-MedicationDispense"]
        },
        "identifier" : [{
          "system" : "https://gematik.de/fhir/erp/NamingSystem/GEM_ERP_NS_PrescriptionId",
          "value" : "160.000.033.491.280.78"
        }],
        "status" : "completed",
        "medicationReference" : {
          "reference" : "Medication/Medication-Rezeptur"
        },
        "subject" : {
          "identifier" : {
            "system" : "http://fhir.de/sid/gkv/kvid-10",
            "value" : "X123456789"
          }
        },
        "performer" : [{
          "actor" : {
            "identifier" : {
              "system" : "https://gematik.de/fhir/sid/telematik-id",
              "value" : "3-SMC-B-Testkarte-883110000095957"
            }
          }
        }],
        "whenHandedOver" : "2026-07-01"
      }
    },
    {
      "name" : "medication",
      "resource" : {
        "resourceType" : "Medication",
        "id" : "Medication-Rezeptur",
        "meta" : {
          "profile" : ["https://gematik.de/fhir/erp/StructureDefinition/GEM-ERP-PR-Medication"]
        },
        "contained" : [{
          "resourceType" : "Medication",
          "id" : "MedicationHydrocortison",
          "meta" : {
            "profile" : ["https://gematik.de/fhir/epa-medication/StructureDefinition/epa-medication-pzn-ingredient"]
          },
          "extension" : [{
            "url" : "https://gematik.de/fhir/epa-medication/StructureDefinition/epa-medication-type-extension",
            "valueCoding" : {
              "system" : "http://snomed.info/sct",
              "code" : "781405001",
              "display" : "Medicinal product package (product)"
            }
          }],
          "code" : {
            "coding" : [{
              "system" : "http://fhir.de/CodeSystem/ifa/pzn",
              "code" : "03424249",
              "display" : "Hydrocortison 1% Creme"
            }]
          },
          "batch" : {
            "lotNumber" : "56498416854"
          }
        },
        {
          "resourceType" : "Medication",
          "id" : "MedicationDexpanthenol",
          "meta" : {
            "profile" : ["https://gematik.de/fhir/epa-medication/StructureDefinition/epa-medication-pzn-ingredient"]
          },
          "extension" : [{
            "url" : "https://gematik.de/fhir/epa-medication/StructureDefinition/epa-medication-type-extension",
            "valueCoding" : {
              "system" : "http://snomed.info/sct",
              "code" : "781405001",
              "display" : "Medicinal product package (product)"
            }
          }],
          "code" : {
            "coding" : [{
              "system" : "http://fhir.de/CodeSystem/ifa/pzn",
              "code" : "16667195",
              "display" : "Dexpanthenol 5% Creme"
            }]
          },
          "batch" : {
            "lotNumber" : "0132456"
          }
        }],
        "extension" : [{
          "url" : "https://gematik.de/fhir/epa-medication/StructureDefinition/drug-category-extension",
          "valueCoding" : {
            "system" : "https://gematik.de/fhir/epa-medication/CodeSystem/epa-drug-category-cs",
            "code" : "00"
          }
        },
        {
          "url" : "https://gematik.de/fhir/epa-medication/StructureDefinition/epa-medication-type-extension",
          "valueCoding" : {
            "system" : "http://snomed.info/sct",
            "code" : "1208954007",
            "display" : "Extemporaneous preparation (product)"
          }
        },
        {
          "url" : "https://gematik.de/fhir/epa-medication/StructureDefinition/medication-id-vaccine-extension",
          "valueBoolean" : false
        }],
        "code" : {
          "text" : "Hydrocortison-Dexpanthenol-Salbe"
        },
        "form" : {
          "coding" : [{
            "system" : "https://fhir.kbv.de/CodeSystem/KBV_CS_SFHIR_KBV_DARREICHUNGSFORM",
            "code" : "SAL"
          }]
        },
        "amount" : {
          "numerator" : {
            "extension" : [{
              "url" : "https://gematik.de/fhir/epa-medication/StructureDefinition/medication-total-quantity-formulation-extension",
              "valueString" : "100"
            }],
            "value" : 20,
            "unit" : "ml"
          },
          "denominator" : {
            "value" : 1
          }
        },
        "ingredient" : [{
          "itemReference" : {
            "reference" : "#MedicationHydrocortison"
          },
          "isActive" : true,
          "strength" : {
            "numerator" : {
              "value" : 50,
              "system" : "http://unitsofmeasure.org",
              "code" : "g"
            },
            "denominator" : {
              "value" : 100,
              "system" : "http://unitsofmeasure.org",
              "code" : "g"
            }
          }
        },
        {
          "itemReference" : {
            "reference" : "#MedicationDexpanthenol"
          },
          "isActive" : true,
          "strength" : {
            "numerator" : {
              "value" : 50,
              "system" : "http://unitsofmeasure.org",
              "code" : "g"
            },
            "denominator" : {
              "value" : 100,
              "system" : "http://unitsofmeasure.org",
              "code" : "g"
            }
          }
        }]
      }
    }]
  }]
}

```
