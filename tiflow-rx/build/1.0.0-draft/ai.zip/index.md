# Implementation Guide E-Rezept-Fachdienst - E-Rezept für Arzneimittel v1.0.0-draft

E-Rezept für Arzneimittel

Version 1.0.0-draft - ci-build 

* [**Table of Contents**](toc.md)
* **Implementation Guide E-Rezept-Fachdienst**

## Implementation Guide E-Rezept-Fachdienst

| | |
| :--- | :--- |
| *Official URL*:https://gematik.de/fhir/erp/ImplementationGuide/de.gematik.tiflow-rx | *Version*:1.0.0-draft |
| Draft as of 2026-03-03 | *Computable Name*:gemIG_TIFlow_rx |

Dieser Implementation Guide beschreibt die Datenmodelle und Prozesse des E-Rezept-Fachdienstes für den Anwendungsfall von “Arzneimittelverordnung”. Er bildet das Fundament für die fachlichen Szenarien und die technischen Schnittstellen im E-Rezept-Workflow für dieses Szenario.

### Zweck und Geltungsbereich

* Grundlegende Workflows für E-Rezepte zur Arzneimittelversorgung: 
* **160, 200** zur Verordnung von Arzneimitteln
* **169, 209** zur Verordnung von Arzneimitteln mit Workflowsteuerung durch den Leistungserbringer
* **166** zur Verordnung von E-T-Rezepten
 
* Profile, Operationen und Validierungsregeln
* Funktionale Anforderungen

### Nicht im Scope

* Modul-übergreifende Anwendungsfälle
* Produkttyp-spezifische Implementierungsdetails außerhalb des Fachdienstes
* Beschreibung und Definition von Prozessen außerhalb des Fachdienstes

### Wie dieser IG zu lesen ist

Dieser Implementation Guide ist “von links nach rechts” zu lesen. Die Menüstruktur beginnt mit fachlichen Inhalten, welche über die technischen Anwendungsfälle dann in den Spezifikationen der Endpunkte und APIs münden. Es wird empfohlen, die Inhalte in der vorgegebenen Reihenfolge zu lesen, um ein umfassendes Verständnis der Anforderungen und Spezifikationen zu erhalten.

Für einen Überblick über die Inhalte und die Struktur dieses Implementation Guides kann die [Inhaltsübersicht](toc.md) konsultiert werden. Dort sind die verschiedenen Kapitel und Abschnitte mit ihren jeweiligen Inhalten und Anforderungen aufgeführt.

### Abhängigkeiten













### Kontakt und Feedback

Für Fragen und Feedback wenden Sie sich bitte an [erp-umsetzung@gematik.de](mailto:erp-umsetzung@gematik.de).

### Rechtliche Hinweise

Copyright ©2026+ gematik GmbH

HL7®, HEALTH LEVEL SEVEN®, FHIR® und das FHIR®-Logo sind Marken von Health Level Seven International.

