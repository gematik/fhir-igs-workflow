Die nachstehende Tabelle fasst Anforderungen dieses Implementation Guide für den _E-Rezept-Fachdienst_ zusammen.

{% include requirements.html actor="E-Rezept-Fachdienst" %}
<div><figcaption><strong>Tabelle:</strong> Anforderungen <i>E-Rezept-Fachdienst</i></figcaption></div>

<br>