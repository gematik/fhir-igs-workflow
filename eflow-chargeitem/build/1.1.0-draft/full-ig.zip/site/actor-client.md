Primärsystem E-Rezept verordnende Leitungserbringer

Die nachstehende Tabelle fasst Anforderungen dieses Implementation Guide für das _Primärsystem E-Rezept verordnende Leitungserbringer_ zusammen.

{% include requirements.html actor="PS_E-Rezept_verordnend" %}
<div><figcaption><strong>Tabelle:</strong> Anforderungen <i>Primärsystem E-Rezept verordnende Leitungserbringer</i></figcaption></div>


### Primärsystem E-Rezept abgebende Leitungserbringer

Die nachstehende Tabelle fasst Anforderungen dieses Implementation Guide für das _Primärsystem E-Rezept abgebende Leitungserbringer_ zusammen.

{% include requirements.html actor="PS_E-Rezept_abgebend" %}
<div><figcaption><strong>Tabelle:</strong> Anforderungen <i>PS_E-Rezept_abgebend</i></figcaption></div>


### E-Rezept-FdV des Versicherten

Die nachstehende Tabelle fasst Anforderungen dieses Implementation Guide für das _E-Rezept Frontend des Versicherten_ zusammen.

{% include requirements.html actor="eRp_FdV" %}
<div><figcaption><strong>Tabelle:</strong> Anforderungen <i>E-Rezept-Frontend des Versicherten</i></figcaption></div>

<br>