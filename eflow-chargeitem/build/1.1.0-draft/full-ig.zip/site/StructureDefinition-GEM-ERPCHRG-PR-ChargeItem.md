# GEM_ERPCHRG_PR_ChargeItem - Abrechnungsinformationen des E-Rezepte für PKV-Versicherte v1.1.0-draft

Abrechnungsinformationen des E-Rezepte für PKV-Versicherte

Version 1.1.0-draft - ci-build 

* [**Table of Contents**](toc.md)
* [**FHIR-Artefakte**](artifacts.md)
* **GEM_ERPCHRG_PR_ChargeItem**

## Resource Profile: GEM_ERPCHRG_PR_ChargeItem 

| | |
| :--- | :--- |
| *Official URL*:https://gematik.de/fhir/erpchrg/StructureDefinition/GEM_ERPCHRG_PR_ChargeItem | *Version*:1.1.0-draft |
| Draft as of 2025-04-10 | *Computable Name*:GEM_ERPCHRG_PR_ChargeItem |

**Usages:**

* Refer to this Profile: [Reply on change Request on ChargeItem from pharmacy to Patient](StructureDefinition-GEM-ERPCHRG-PR-Communication-ChargChangeReply.md) and [Request for Modification on ChargeItem](StructureDefinition-GEM-ERPCHRG-PR-Communication-ChargChangeReq.md)
* Examples for this Profile: [ChargeItem/ChargeItem-GET-Completed](ChargeItem-ChargeItem-GET-Completed.md) and [ChargeItem/ChargeItem-POST-Binary](ChargeItem-ChargeItem-POST-Binary.md)
* CapabilityStatements using this Profile: [ERPCHRG CapabilityStatement für den E-Rezept-Fachdienst](CapabilityStatement-erp-fachdienst-server-erpchrg.md)

You can also check for [usages in the FHIR IG Statistics](https://packages2.fhir.org/xig/de.gematik.eflow-chargeitem|current/StructureDefinition/GEM-ERPCHRG-PR-ChargeItem)

### Formal Views of Profile Content

 [Description of Profiles, Differentials, Snapshots and how the different presentations work](http://build.fhir.org/ig/FHIR/ig-guidance/readingIgs.html#structure-definitions). 

 

Other representations of profile: [CSV](StructureDefinition-GEM-ERPCHRG-PR-ChargeItem.csv), [Excel](StructureDefinition-GEM-ERPCHRG-PR-ChargeItem.xlsx), [Schematron](StructureDefinition-GEM-ERPCHRG-PR-ChargeItem.sch) 



## Resource Content

```json
{
  "resourceType" : "StructureDefinition",
  "id" : "GEM-ERPCHRG-PR-ChargeItem",
  "url" : "https://gematik.de/fhir/erpchrg/StructureDefinition/GEM_ERPCHRG_PR_ChargeItem",
  "version" : "1.1.0-draft",
  "name" : "GEM_ERPCHRG_PR_ChargeItem",
  "status" : "draft",
  "experimental" : false,
  "date" : "2025-04-10",
  "publisher" : "gematik GmbH",
  "contact" : [{
    "name" : "gematik GmbH",
    "telecom" : [{
      "system" : "url",
      "value" : "https://gematik.de"
    },
    {
      "system" : "email",
      "value" : "erp-umsetzung@gematik.de"
    }]
  }],
  "jurisdiction" : [{
    "coding" : [{
      "system" : "urn:iso:std:iso:3166",
      "code" : "DE",
      "display" : "Germany"
    }]
  }],
  "fhirVersion" : "4.0.1",
  "mapping" : [{
    "identity" : "workflow",
    "uri" : "http://hl7.org/fhir/workflow",
    "name" : "Workflow Pattern"
  },
  {
    "identity" : "v2",
    "uri" : "http://hl7.org/v2",
    "name" : "HL7 v2 Mapping"
  },
  {
    "identity" : "rim",
    "uri" : "http://hl7.org/v3",
    "name" : "RIM Mapping"
  },
  {
    "identity" : "w5",
    "uri" : "http://hl7.org/fhir/fivews",
    "name" : "FiveWs Pattern Mapping"
  }],
  "kind" : "resource",
  "abstract" : false,
  "type" : "ChargeItem",
  "baseDefinition" : "http://hl7.org/fhir/StructureDefinition/ChargeItem",
  "derivation" : "constraint",
  "differential" : {
    "element" : [{
      "id" : "ChargeItem",
      "path" : "ChargeItem"
    },
    {
      "id" : "ChargeItem.meta",
      "path" : "ChargeItem.meta",
      "min" : 1,
      "mustSupport" : true
    },
    {
      "id" : "ChargeItem.meta.profile",
      "path" : "ChargeItem.meta.profile",
      "slicing" : {
        "discriminator" : [{
          "type" : "value",
          "path" : "$this"
        }],
        "description" : "Slicing for meta profile",
        "ordered" : false,
        "rules" : "closed"
      },
      "min" : 1,
      "max" : "1",
      "mustSupport" : true
    },
    {
      "id" : "ChargeItem.meta.profile:erpchrgProfile",
      "path" : "ChargeItem.meta.profile",
      "sliceName" : "erpchrgProfile",
      "min" : 1,
      "max" : "1",
      "fixedCanonical" : "https://gematik.de/fhir/erpchrg/StructureDefinition/GEM_ERPCHRG_PR_ChargeItem|1.1",
      "mustSupport" : true
    },
    {
      "id" : "ChargeItem.extension",
      "path" : "ChargeItem.extension",
      "slicing" : {
        "discriminator" : [{
          "type" : "value",
          "path" : "url"
        }],
        "description" : "Extensions are always sliced by (at least) url",
        "rules" : "closed"
      }
    },
    {
      "id" : "ChargeItem.extension:markingFlag",
      "path" : "ChargeItem.extension",
      "sliceName" : "markingFlag",
      "short" : "Flag list whether submitted Abrechnungsinformationen for PKV, Taxes, Subsidy",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "Extension",
        "profile" : ["https://gematik.de/fhir/erpchrg/StructureDefinition/GEM_ERPCHRG_EX_MarkingFlag"]
      }],
      "mustSupport" : true
    },
    {
      "id" : "ChargeItem.identifier",
      "path" : "ChargeItem.identifier",
      "slicing" : {
        "discriminator" : [{
          "type" : "value",
          "path" : "system"
        }],
        "description" : "The task ressource contains three identifier. The first one is the identifier for the ask representing one e-prescription. The other identifier are representing the patient as owner of the prescription. One is the \"Krankenversichertennummer\" which identify each patient by his health insurance company and the other is \"Institutionskennzeichen\".",
        "rules" : "closed"
      },
      "min" : 1
    },
    {
      "id" : "ChargeItem.identifier:PrescriptionID",
      "path" : "ChargeItem.identifier",
      "sliceName" : "PrescriptionID",
      "short" : "Prescription Identifier",
      "definition" : "The prescription identifier is the main identifier for all the ePrecscription related ressources and the whole prescription workflow. This identifier is genereted by the \"E-Rezept Fachdienst\" and must not be changed manually.",
      "min" : 1,
      "max" : "1"
    },
    {
      "id" : "ChargeItem.identifier:PrescriptionID.system",
      "path" : "ChargeItem.identifier.system",
      "min" : 1,
      "fixedUri" : "https://gematik.de/fhir/erp/NamingSystem/GEM_ERP_NS_PrescriptionId"
    },
    {
      "id" : "ChargeItem.identifier:PrescriptionID.value",
      "path" : "ChargeItem.identifier.value",
      "min" : 1
    },
    {
      "id" : "ChargeItem.identifier:AccessCode",
      "path" : "ChargeItem.identifier",
      "sliceName" : "AccessCode",
      "short" : "AccessCode Identifier",
      "definition" : "Generated by the \"E-Rezept Fachdienst\". This identifier grants access to others than the patient.",
      "min" : 0,
      "max" : "1"
    },
    {
      "id" : "ChargeItem.identifier:AccessCode.system",
      "path" : "ChargeItem.identifier.system",
      "min" : 1,
      "fixedUri" : "https://gematik.de/fhir/erp/NamingSystem/GEM_ERP_NS_AccessCode"
    },
    {
      "id" : "ChargeItem.identifier:AccessCode.value",
      "path" : "ChargeItem.identifier.value",
      "min" : 1
    },
    {
      "id" : "ChargeItem.status",
      "path" : "ChargeItem.status",
      "fixedCode" : "billable"
    },
    {
      "id" : "ChargeItem.code.coding.system",
      "path" : "ChargeItem.code.coding.system",
      "fixedUri" : "http://terminology.hl7.org/CodeSystem/data-absent-reason"
    },
    {
      "id" : "ChargeItem.code.coding.code",
      "path" : "ChargeItem.code.coding.code",
      "fixedCode" : "not-applicable"
    },
    {
      "id" : "ChargeItem.subject.identifier",
      "path" : "ChargeItem.subject.identifier",
      "min" : 1,
      "type" : [{
        "code" : "Identifier",
        "profile" : ["http://fhir.de/StructureDefinition/identifier-kvid-10"]
      }]
    },
    {
      "id" : "ChargeItem.enterer",
      "path" : "ChargeItem.enterer",
      "short" : "Pharmacy that initially provided the Abgabedaten in ChargeItem"
    },
    {
      "id" : "ChargeItem.enterer.identifier",
      "path" : "ChargeItem.enterer.identifier",
      "min" : 1,
      "type" : [{
        "code" : "Identifier",
        "profile" : ["http://fhir.de/StructureDefinition/identifier-telematik-id"]
      }]
    },
    {
      "id" : "ChargeItem.supportingInformation",
      "path" : "ChargeItem.supportingInformation",
      "slicing" : {
        "discriminator" : [{
          "type" : "value",
          "path" : "display"
        }],
        "rules" : "closed"
      },
      "definition" : "holds references to the 3 relevant documents [prescription, receipt, dispensationInformation]",
      "max" : "4",
      "mustSupport" : true
    },
    {
      "id" : "ChargeItem.supportingInformation:prescriptionItemBundle",
      "path" : "ChargeItem.supportingInformation",
      "sliceName" : "prescriptionItemBundle",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "Reference",
        "targetProfile" : ["http://hl7.org/fhir/StructureDefinition/Bundle"]
      }]
    },
    {
      "id" : "ChargeItem.supportingInformation:prescriptionItemBundle.display",
      "path" : "ChargeItem.supportingInformation.display",
      "min" : 1,
      "fixedString" : "https://fhir.kbv.de/StructureDefinition/KBV_PR_ERP_Bundle"
    },
    {
      "id" : "ChargeItem.supportingInformation:dispenseItemBinary",
      "path" : "ChargeItem.supportingInformation",
      "sliceName" : "dispenseItemBinary",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "Reference",
        "targetProfile" : ["http://hl7.org/fhir/StructureDefinition/Binary"]
      }]
    },
    {
      "id" : "ChargeItem.supportingInformation:dispenseItemBinary.display",
      "path" : "ChargeItem.supportingInformation.display",
      "min" : 1,
      "fixedString" : "Binary"
    },
    {
      "id" : "ChargeItem.supportingInformation:dispenseItemBundle",
      "path" : "ChargeItem.supportingInformation",
      "sliceName" : "dispenseItemBundle",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "Reference",
        "targetProfile" : ["http://hl7.org/fhir/StructureDefinition/Bundle"]
      }]
    },
    {
      "id" : "ChargeItem.supportingInformation:dispenseItemBundle.display",
      "path" : "ChargeItem.supportingInformation.display",
      "min" : 1,
      "fixedString" : "http://fhir.abda.de/eRezeptAbgabedaten/StructureDefinition/DAV-PKV-PR-ERP-AbgabedatenBundle"
    },
    {
      "id" : "ChargeItem.supportingInformation:receiptBundle",
      "path" : "ChargeItem.supportingInformation",
      "sliceName" : "receiptBundle",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "Reference",
        "targetProfile" : ["http://hl7.org/fhir/StructureDefinition/Bundle"]
      }]
    },
    {
      "id" : "ChargeItem.supportingInformation:receiptBundle.display",
      "path" : "ChargeItem.supportingInformation.display",
      "min" : 1,
      "fixedString" : "https://gematik.de/fhir/erp/StructureDefinition/GEM_ERP_PR_Bundle"
    }]
  }
}

```
