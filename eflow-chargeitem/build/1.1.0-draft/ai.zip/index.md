# Implementation Guide E-Rezept-Fachdienst - Abrechnungsinformationen für PKV-Versicherte v1.1.0-draft

Abrechnungsinformationen für PKV-Versicherte

Version 1.1.0-draft - ci-build 

* [**Table of Contents**](toc.md)
* **Implementation Guide E-Rezept-Fachdienst**

## Implementation Guide E-Rezept-Fachdienst

| | |
| :--- | :--- |
| *Official URL*:https://gematik.de/fhir/erpchrg/ImplementationGuide/de.gematik.eflow-chargeitem | *Version*:1.1.0-draft |
| Draft as of 2026-03-04 | *Computable Name*:gemIG_eRp_ChargeItem |

### Implementation Guide E-Rezept Patientenrechnung (PKV)

Dieser Implementation Guide beschreibt die Bereitstellung der Abrechnungsinformationen für den Kostenträger. Er ergänzt die workflowspezifischen Anforderungen des E-Rezept-Fachdienstes und beschreibt die relevanten Use Cases.

#### Zweck und Geltungsbereich

* Abrechnungsinformationen für den Kostenträger

#### Nicht im Scope

* GKV-spezifische Workflows
* Nicht apothekenpflichtige Verordnungen
* Abrechnung ausserhalb des E-Rezept-Fachdienstes
* PKV-spezifische Anforderungen an Schnittstellen und Datenmodelle

#### Wie dieser IG zu lesen ist

Die Kapitel folgen der Struktur Fachlichkeit, Technische Umsetzung und Schnittstellen. Szenarien und Anwendungsfälle verweisen auf die zugehörigen technischen Kapitel und Profile.

#### Abhängigkeiten








#### Kontakt und Feedback

Für Fragen und Feedback wenden Sie sich bitte an [erp-umsetzung@gematik.de](mailto:erp-umsetzung@gematik.de).

#### Rechtliche Hinweise

Copyright ©2026+ gematik GmbH

HL7®, HEALTH LEVEL SEVEN®, FHIR® und das FHIR®-Logo sind Marken von Health Level Seven International.

