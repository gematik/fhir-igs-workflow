# Additional APIs - Abrechnungsinformationen des E-Rezepte für PKV-Versicherte v1.1.0-draft

Abrechnungsinformationen des E-Rezepte für PKV-Versicherte

Version 1.1.0-draft - ci-build 

* [**Table of Contents**](toc.md)
* **Additional APIs**

## Additional APIs

Diese Seite beschreibt zusaetzliche APIs fuer den PKV-Workflow. Derzeit sind keine weiteren APIs über die Query und Operation API hinaus definiert.

