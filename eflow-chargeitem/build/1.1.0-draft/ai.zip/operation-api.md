# Operation API - Abrechnungsinformationen des E-Rezepte für PKV-Versicherte v1.1.0-draft

Abrechnungsinformationen des E-Rezepte für PKV-Versicherte

Version 1.1.0-draft - ci-build 

* [**Table of Contents**](toc.md)
* **Operation API**

## Operation API

Operationen

Diese Seite bietet einen Einstieg in die Operations‑APIs.

## Operationen

* [$accept](./op-accept.md)
* [$activate](./op-activate.md)

