# Operation API - Abrechnungsinformationen für PKV-Versicherte v1.1.0-draft

Abrechnungsinformationen für PKV-Versicherte

Version 1.1.0-draft - ci-build 

* [**Table of Contents**](toc.md)
* **Operation API**

## Operation API

Diese Seite bietet einen Einstieg in die Operations‑APIs.

### Operationen

* [$accept](./op-accept.md)
* [$activate](./op-activate.md)

