# de.gematik.eflow-chargeitem#1.1.0-draft: Abrechnungsinformationen des E-Rezepte für PKV-Versicherte

## Pages

* [Implementation Guide E-Rezept-Fachdienst](index.md)
* [Primärsystem des abgebenden Leistungserbringers - Anforderungen: ChargeItem-Query](query-api-chargeitem-req-ps-put.md)
* [E-Rezept-FdV Anforderungen: ChargeItem](menu-technische-umsetzung-chargeitem-req-fdv.md)
* [E-Rezept-Fachdienst Anforderungen: ChargeItem-Query](query-api-chargeitem-req-fd.md)
* [Query API: ChargeItem](query-api-chargeitem.md)
* [Datenschutz und Sicherheit](menu-schnittstellen-datenschutz-und-sicherheit.md)
* [Abrechnungsinformationen des E-Rezepts für PKV-Versicherte](menu-fachlichkeit-szenario-pkv.md)
* [E-Rezept-Fachdienst Anforderungen: ChargeItem-Query](query-api-chargeitem-req-fd-post.md)
* [Operation API](operation-api.md)
* [Primärsystem des abgebenden Leistungserbringers - Anforderungen: ChargeItem-Query](query-api-chargeitem-req-ps-get-id.md)
* [Generelle Prinzipien](menu-schnittstellen-generelle-prinzipien.md)
* [ChargeItem: Abrechnungsinformationen des E-Rezepts für PKV-Versicherte](menu-technische-umsetzung-chargeitem.md)
* [E-Rezept-Fachdienst Anforderungen: ChargeItem-Query](query-api-chargeitem-req-fd-get.md)
* [E-Rezept-FdV Anforderungen: ChargeItem-Query](query-api-chargeitem-req-fdv-delete.md)
* [E-Rezept-Fachdienst Anforderungen: ChargeItem-Query](query-api-chargeitem-req-fd-put.md)
* [Operation: $accept](op-accept.md)
* [E-Rezept-FdV Anforderungen: ChargeItem-Query](query-api-chargeitem-req-fdv-get.md)
* [E-Rezept-Fachdienst Anforderungen: ChargeItem-Query](query-api-chargeitem-req-fd-delete.md)
* [Release Notes](release-notes.md)
* [E-Rezept-Fachdienst Anforderungen: ChargeItem-Query](query-api-chargeitem-req-fd-get-id.md)
* [Referenzen](referenced.md)
* [FHIR-Artefakte](artifacts.md)
* [Query API](query-api.md)
* [E-Rezept-FdV Anforderungen: ChargeItem-Query](query-api-chargeitem-req-fdv-patch.md)
* [Query API: Communication](query-api-communication.md)
* [Downloads](downloads.md)
* [Operation: $activate](op-activate.md)
* [Verarbeitungsregeln für den E-Rezept-Fachdienst](menu-technische-umsetzung-verarbeitungsregeln.md)
* [E-Rezept-Fachdienst Anforderungen: ChargeItem-Query](query-api-chargeitem-req-fd-patch.md)
* [E-Rezept-Fachdienst Anforderungen: Communication-Query](query-api-communication-req-fd.md)
* [Apache Licence](license.md)
* [E-Rezept-FdV Anforderungen: Communication-Query](query-api-communication-req-fdv.md)
* [Primärsystem des abgebenden Leistungserbringers - Anforderungen: ChargeItem-Query](query-api-chargeitem-req-ps-post.md)
* [Systemüberblick](menu-technische-umsetzung-systemueberblick.md)
* [E-Rezept-FdV Anforderungen: ChargeItem-Query](query-api-chargeitem-req-fdv-get-id.md)
* [E-Rezept-FdV Anforderungen: ChargeItem-Query](query-api-chargeitem-req-fdv.md)
* [Überblick über die Abrechnungsinformationen des E-Rezepts für PKV-Versicherte](menu-fachlichkeit-ueberblick.md)
* [Additional APIs](menu-schnittstellen-additional-api.md)
* [Technische Anwendungsfälle](menu-technische-umsetzung-anwendungsfaelle.md)
* [Steckbriefe](spec-sheet.md)
* [Query API: Consent](query-api-consent.md)
* [Query API: Task](query-api-task.md)

## Resources

### CodeSystems

* [CodeSystem of types for a consent](CodeSystem-GEM-ERPCHRG-CS-ConsentType.md)

### ValueSets

* [ValueSet of Consent Codes](ValueSet-GEM-ERPCHRG-VS-ConsentType.md)

### Complex-type Profiles

* [Identifier IKNR](StructureDefinition-identifier-iknr.md)
* [Identifier KVID-10](StructureDefinition-identifier-kvid-10.md)
* [Identifier Telematik-ID](StructureDefinition-identifier-telematik-id.md)

### Resource Profiles

* [GEM_ERPCHRG_PR_ChargeItem](StructureDefinition-GEM-ERPCHRG-PR-ChargeItem.md)
* [Reply on change Request on ChargeItem from pharmacy to Patient](StructureDefinition-GEM-ERPCHRG-PR-Communication-ChargChangeReply.md)
* [Request for Modification on ChargeItem](StructureDefinition-GEM-ERPCHRG-PR-Communication-ChargChangeReq.md)
* [GEM_ERPCHRG_PR_Consent](StructureDefinition-GEM-ERPCHRG-PR-Consent.md)
* [GEM ERPCHRG PR PAR Patch ChargeItem Input Parameter](StructureDefinition-GEM-ERPCHRG-PR-PAR-Patch-ChargeItem-Input.md)

### Extensions

* [GEM_ERPCHRG_EX_MarkingFlag](StructureDefinition-GEM-ERPCHRG-EX-MarkingFlag.md)

### CapabilityStatements

* [ERPCHRG CapabilityStatement für Clients des E-Rezept-Fachdienst](CapabilityStatement-erp-fachdienst-client.md)
* [ERPCHRG CapabilityStatement für den E-Rezept-Fachdienst](CapabilityStatement-erp-fachdienst-server-erpchrg.md)

### ImplementationGuides

* [Abrechnungsinformationen des E-Rezepte für PKV-Versicherte](index.md)

### Examples

* [ChargeItem-GET-Completed (ChargeItem)](ChargeItem-ChargeItem-GET-Completed.md)
* [ChargeItem-POST-Binary (ChargeItem)](ChargeItem-ChargeItem-POST-Binary.md)
* [3bbc2209-9c23-4553-986e-a5c9f69a39fb (Communication)](Communication-3bbc2209-9c23-4553-986e-a5c9f69a39fb.md)
* [b4cf7f71-3ade-40ab-97a9-929f95af29f2 (Communication)](Communication-b4cf7f71-3ade-40ab-97a9-929f95af29f2.md)
* [0dcc5d4c-bf24-4c06-b02e-be5bc24587e2 (Consent)](Consent-0dcc5d4c-bf24-4c06-b02e-be5bc24587e2.md)
* [ChargeItemConsent-Request (Consent)](Consent-ChargeItemConsent-Request.md)
* [Example-Parameters-Patch-ChargeItem-1 (Parameters)](Parameters-Example-Parameters-Patch-ChargeItem-1.md)
* [Example-Parameters-Patch-ChargeItem-2 (Parameters)](Parameters-Example-Parameters-Patch-ChargeItem-2.md)
