# de.gematik.eflow-chargeitem#1.1.0-draft: Abrechnungsinformationen für PKV-Versicherte

## Pages

* [Implementation Guide E-Rezept-Fachdienst](index.md)
* [E-Rezept-FdV Anforderungen: ChargeItem](menu-technische-umsetzung-chargeitem-req-fdv.md)
* [FD-Anforderungen: ChargeItem-Query](query-api-chargeitem-req-fd.md)
* [Query API: ChargeItem](query-api-chargeitem.md)
* [Abrechnungsinformationen des E-Rezepts für PKV-Versicherte](menu-fachlichkeit-szenario-pkv.md)
* [Operation API](operation-api.md)
* [FD-Anforderungen: $accept](op-accept-req-fd.md)
* [Primärsystem des abgebenden Leistungserbringers Anforderungen: ChargeItem](menu-technische-umsetzung-chargeitem-req-avs.md)
* [Generelle Prinzipien](menu-schnittstellen-generelle-prinzipien.md)
* [ChargeItem: Abrechnungsinformationen des E-Rezepts für PKV-Versicherte](menu-technische-umsetzung-chargeitem.md)
* [AVS-Anforderungen: ChargeItem-Query](query-api-chargeitem-req-avs.md)
* [Operation: $accept](op-accept.md)
* [FD-Anforderungen: $activate](op-activate-req-fd.md)
* [Client-Anforderungen: Consent-Query](query-api-consent-req-fdv.md)
* [Release Notes](release-notes.md)
* [Referenzen](referenced.md)
* [FHIR-Artefakte](artifacts.md)
* [Query API](query-api.md)
* [Query API: Communication](query-api-communication.md)
* [Downloads](downloads.md)
* [FD-Anforderungen: Consent-Query](query-api-consent-req-fd.md)
* [Operation: $activate](op-activate.md)
* [Verarbeitungsregeln für den E-Rezept-Fachdienst](menu-technische-umsetzung-verarbeitungsregeln.md)
* [FD-Anforderungen: Communication-Query](query-api-communication-req-fd.md)
* [Apache Licence](license.md)
* [FdV-Anforderungen: Communication-Query](query-api-communication-req-fdv.md)
* [AVS-Anforderungen: Communication-Query](query-api-communication-req-avs.md)
* [Systemüberblick](menu-technische-umsetzung-systemueberblick.md)
* [FdV-Anforderungen: ChargeItem-Query](query-api-chargeitem-req-fdv.md)
* [Technische Anwendungsfälle](menu-technische-umsetzung-anwendungsfaelle.md)
* [Steckbriefe](spec-sheet.md)
* [Query API: Consent](query-api-consent.md)
* [Query API: Task](query-api-task.md)
* [Datenschutz und Sicherheit](menu-technische-umsetzung-datenschutz-und-sicherheit.md)

## Resources

### CodeSystems

* [CodeSystem of types for a consent](CodeSystem-GEM-ERPCHRG-CS-ConsentType.md)

### ValueSets

* [ValueSet of Consent Codes](ValueSet-GEM-ERPCHRG-VS-ConsentType.md)

### Complex-type Profiles

* [Identifier IKNR](StructureDefinition-identifier-iknr.md)
* [Identifier KVID-10](StructureDefinition-identifier-kvid-10.md)
* [Identifier Telematik-ID](StructureDefinition-identifier-telematik-id.md)

### Resource Profiles

* [GEM_ERPCHRG_PR_ChargeItem](StructureDefinition-GEM-ERPCHRG-PR-ChargeItem.md)
* [Reply on change Request on ChargeItem from pharmacy to Patient](StructureDefinition-GEM-ERPCHRG-PR-Communication-ChargChangeReply.md)
* [Request for Modification on ChargeItem](StructureDefinition-GEM-ERPCHRG-PR-Communication-ChargChangeReq.md)
* [GEM_ERPCHRG_PR_Consent](StructureDefinition-GEM-ERPCHRG-PR-Consent.md)
* [GEM ERPCHRG PR PAR Patch ChargeItem Input Parameter](StructureDefinition-GEM-ERPCHRG-PR-PAR-Patch-ChargeItem-Input.md)

### Extensions

* [GEM_ERPCHRG_EX_MarkingFlag](StructureDefinition-GEM-ERPCHRG-EX-MarkingFlag.md)

### CapabilityStatements

* [ERPCHRG CapabilityStatement für Clients des E-Rezept-Fachdienst](CapabilityStatement-erp-fachdienst-client.md)
* [ERPCHRG CapabilityStatement für den E-Rezept-Fachdienst](CapabilityStatement-erp-fachdienst-server-erpchrg.md)

### ImplementationGuides

* [Abrechnungsinformationen für PKV-Versicherte](index.md)

### Examples

* [ChargeItem-GET-Completed (ChargeItem)](ChargeItem-ChargeItem-GET-Completed.md)
* [ChargeItem-POST-Binary (ChargeItem)](ChargeItem-ChargeItem-POST-Binary.md)
* [3bbc2209-9c23-4553-986e-a5c9f69a39fb (Communication)](Communication-3bbc2209-9c23-4553-986e-a5c9f69a39fb.md)
* [b4cf7f71-3ade-40ab-97a9-929f95af29f2 (Communication)](Communication-b4cf7f71-3ade-40ab-97a9-929f95af29f2.md)
* [0dcc5d4c-bf24-4c06-b02e-be5bc24587e2 (Consent)](Consent-0dcc5d4c-bf24-4c06-b02e-be5bc24587e2.md)
* [ChargeItemConsent-Request (Consent)](Consent-ChargeItemConsent-Request.md)
* [Example-Parameters-Patch-ChargeItem-1 (Parameters)](Parameters-Example-Parameters-Patch-ChargeItem-1.md)
* [Example-Parameters-Patch-ChargeItem-2 (Parameters)](Parameters-Example-Parameters-Patch-ChargeItem-2.md)
