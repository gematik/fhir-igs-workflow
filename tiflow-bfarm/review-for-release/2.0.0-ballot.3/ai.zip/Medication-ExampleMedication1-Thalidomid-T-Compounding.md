# Beispiel BfArM Medication (Verordnung) - Rezeptur - Implementation Guide TIFlow - Datenaustausch BfArM Webdienst v2.0.0-ballot.3

Implementation Guide

TIFlow - Datenaustausch BfArM Webdienst

Version 2.0.0-ballot.3 - ballot 

* [**Table of Contents**](toc.md)
* [**FHIR-Artefakte**](artifacts.md)
* **Beispiel BfArM Medication (Verordnung) - Rezeptur**

## Example Medication: Beispiel BfArM Medication (Verordnung) - Rezeptur



## Resource Content

```json
{
  "resourceType" : "Medication",
  "id" : "ExampleMedication1-Thalidomid-T-Compounding",
  "extension" : [{
    "url" : "https://gematik.de/fhir/epa-medication/StructureDefinition/medication-formulation-packaging-extension",
    "valueString" : "Packung als 20 Kapseln in Schachtel."
  },
  {
    "url" : "https://gematik.de/fhir/epa-medication/StructureDefinition/medication-manufacturing-instructions-extension",
    "valueString" : "M.D.S."
  }],
  "code" : {
    "coding" : [{
      "system" : "http://www.whocc.no/atc",
      "code" : "L04AX02",
      "display" : "thalidomide"
    }]
  },
  "form" : {
    "coding" : [{
      "system" : "https://fhir.kbv.de/CodeSystem/KBV_CS_SFHIR_KBV_DARREICHUNGSFORM",
      "code" : "HKP",
      "display" : "Hartkapseln"
    }]
  },
  "amount" : {
    "numerator" : {
      "extension" : [{
        "url" : "https://gematik.de/fhir/epa-medication/StructureDefinition/medication-packaging-size-extension",
        "valueString" : "100"
      }],
      "unit" : "ml"
    },
    "denominator" : {
      "value" : 1
    }
  },
  "ingredient" : [{
    "itemCodeableConcept" : {
      "text" : "Thalidomid"
    },
    "strength" : {
      "numerator" : {
        "value" : 5,
        "unit" : "g"
      },
      "denominator" : {
        "value" : 1
      }
    }
  },
  {
    "itemCodeableConcept" : {
      "text" : "Mannit"
    },
    "strength" : {
      "extension" : [{
        "url" : "https://gematik.de/fhir/epa-medication/StructureDefinition/medication-ingredient-amount-extension",
        "valueString" : "1g"
      }]
    }
  }]
}

```
