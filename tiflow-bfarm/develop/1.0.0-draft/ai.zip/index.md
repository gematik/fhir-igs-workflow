# Implementation Guide: Übermittlung an den BfArM Webdienst - TIFlow - Datenaustausch BfArM Webdienst v1.0.0-draft

TIFlow - Datenaustausch BfArM Webdienst

Version 1.0.0-draft - ci-build 

* [**Table of Contents**](toc.md)
* **Implementation Guide: Übermittlung an den BfArM Webdienst**

## Implementation Guide: Übermittlung an den BfArM Webdienst

| | |
| :--- | :--- |
| *Official URL*:https://gematik.de/fhir/tiflow/bfarm/ImplementationGuide/de.gematik.tiflow.bfarm | *Version*:1.0.0-draft |
| Draft as of 2026-03-26 | *Computable Name*:gemIG_TIFlow_bfarm |

Dieser Implementation Guide beschreibt Profile und deren Verwendung für den Datenaustausch zwischen dem TI-Flow-Fachdienst und dem BfArM Webdienst.

### Zweck und Geltungsbereich

* Übertragung des digitalen Durchschlags E-T-Rezept an das BfArM T-Register
* Profile und Mappingdaten für den Datenaustausch
* Dokumentation der relevanten Anwendungsfälle

### Nicht im Scope

* Beschreibung des Workflow **166** zur Verordnung von E-T-Rezepten, hierzu siehe [gemIG_TIFlow_rx].

### Anforderungen zur Umsetzung des IGs

Der TI-Flow-Fachdienst MUSS zur Umsetzung der Übertragung von Daten vom TI-Flow-Fachdienst an den BfArM Webdienst den Implementation Guide "Datenaustausch TI-Flow-Fachdienst und BfArM Webdienst" umsetzen.

Der TI-Flow-Fachdienst MUSS zur Umsetzung des Implementation Guides "Datenaustausch TI-Flow-Fachdienst und BfArM Webdienst" alle Anforderungen und FHIR-Artefakte umsetzen, die in diesem IG definiert sind, sowie Anforderungen und Artefakte aus [gemIG_TIFlow_core], die in diesem IG referenziert werden.
### Wie dieser IG zu lesen ist

Dieser Implementation Guide ist “von links nach rechts” zu lesen. Die Menüstruktur beginnt mit fachlichen Inhalten, welche über die technischen Anwendungsfälle dann in den Spezifikationen der Endpunkte und APIs münden. Es wird empfohlen, die Inhalte in der vorgegebenen Reihenfolge zu lesen, um ein umfassendes Verständnis der Anforderungen und Spezifikationen zu erhalten.

Für einen Überblick über die Inhalte und die Struktur dieses Implementation Guides kann die [Inhaltsübersicht](toc.md) konsultiert werden. Dort sind die verschiedenen Kapitel und Abschnitte mit ihren jeweiligen Inhalten und Anforderungen aufgeführt.

### Abhängigkeiten













### Kontakt und Feedback

Für Fragen und Feedback wenden Sie sich bitte an [erp-umsetzung@gematik.de](mailto:erp-umsetzung@gematik.de).

### Rechtliche Hinweise

Copyright ©2025+ gematik GmbH

HL7®, HEALTH LEVEL SEVEN®, FHIR® und das FHIR®-Logo sind Marken von Health Level Seven International.

