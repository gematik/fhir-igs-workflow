# de.gematik.tiflow.bfarm#2.0.0-ballot.2: Implementation Guide TIFlow - Datenaustausch BfArM Webdienst

## Pages

* [Implementation Guide: Übermittlung an den BfArM Webdienst](index.md)
* [Technische Umsetzung - Systemüberblick](menu-technische-umsetzung-systemueberblick.md)
* [Technische Umsetzung - Übermittlung an das BfArM T-Register](menu-technische-umsetzung-t-register.md)
* [Referenzen](referenced.md)
* [Beispiele](tests.md)
* [Schnittstellen - Query API](menu-schnittstellen-query-api.md)
* [Release Notes](release-notes.md)
* [Schnittstelle zur Übertragung an das BfArM T-Register](query-api-t-register-req-fd.md)
* [Szenario Übermittlung an das T-Register](menu-fachlichkeit-t-register.md)
* [Downloads](downloads.md)
* [Beispiel 4: Absolute Referenzierung](test-case-04.md)
* [FHIR-Artefakte](artifacts.md)
* [Technische Umsetzung - Anwendungsfälle](menu-technische-umsetzung-anwendungsfaelle.md)
* [Schnittstellen - Datenschutz und Sicherheit](menu-technische-umsetzung-datenschutz-und-sicherheit.md)
* [Beispiel 3: Freitext Verordnung](test-case-03.md)
* [Technische Umsetzung - Mapping des digitalen Durchschlags](menu-technische-umsetzung-mapping.md)
* [Lizenz](license.md)
* [Beispiel 1: PZN Verordnung](test-case-01.md)
* [Beispiel 2: Wirkstoff Verordnung](test-case-02.md)

## Resources

### Logicals

* [Logisches Modell digitaler Durchschlag E-T-Rezept](StructureDefinition-erp-tprescription-carbon-copy-logical.md)

### Resource Profiles

* [Digitaler Durchschlag T-Rezept](StructureDefinition-erp-tprescription-carbon-copy.md)
* [E-T-Rezept Medication Dispense](StructureDefinition-erp-tprescription-medication-dispense.md)
* [E-T-Rezept Medication Request](StructureDefinition-erp-tprescription-medication-request.md)
* [E-T-Rezept Medication](StructureDefinition-erp-tprescription-medication.md)
* [E-T-Rezept Organization](StructureDefinition-erp-tprescription-organization.md)

### ImplementationGuides

* [Implementation Guide TIFlow - Datenaustausch BfArM Webdienst](index.md)

### StructureMaps

* [E-T-Rezept Structure Map for CarbonCopy](StructureMap-ERPTPrescriptionStructureMapCarbonCopy.md)
* [E-T-Rezept Structure Map for Medication](StructureMap-ERPTPrescriptionStructureMapGEMMedication.md)
* [E-T-Rezept Structure Map for KBV Compounding Medication](StructureMap-ERPTPrescriptionStructureMapKBVCompoundingMedication.md)
* [E-T-Rezept Structure Map for KBV FreeText Medication](StructureMap-ERPTPrescriptionStructureMapKBVFreeTextMedication.md)
* [E-T-Rezept Structure Map for KBV Ingredient Medication](StructureMap-ERPTPrescriptionStructureMapKBVIngredientMedication.md)
* [E-T-Rezept Structure Map for KBV PZN Medication](StructureMap-ERPTPrescriptionStructureMapKBVPZNMedication.md)
* [E-T-Rezept Structure Map for Medication](StructureMap-ERPTPrescriptionStructureMapMedication.md)
* [E-T-Rezept Structure Map for MedicationDispense](StructureMap-ERPTPrescriptionStructureMapMedicationDispense.md)
* [E-T-Rezept Structure Map for MedicationRequest](StructureMap-ERPTPrescriptionStructureMapMedicationRequest.md)
* [E-T-Rezept Structure Map for Organization](StructureMap-ERPTPrescriptionStructureMapOrganization.md)
* [E-T-Rezept Structure Map for Task](StructureMap-ERPTPrescriptionStructureMapTask.md)

### Examples

* [VZD-SearchSet-Bundle (Bundle)](Bundle-VZD-SearchSet-Bundle.md)
* [ExampleMedication1-Pomalidomid-T (Medication)](Medication-ExampleMedication1-Pomalidomid-T.md)
* [ExampleMedication1-Thalidomid-T-Compounding (Medication)](Medication-ExampleMedication1-Thalidomid-T-Compounding.md)
* [ExampleMedication2-Pomalidomid-T (Medication)](Medication-ExampleMedication2-Pomalidomid-T.md)
* [ExampleMedicationDispense-T (MedicationDispense)](MedicationDispense-ExampleMedicationDispense-T.md)
* [ExampleMedicationRequest-T-Compounding (MedicationRequest)](MedicationRequest-ExampleMedicationRequest-T-Compounding.md)
* [ExampleMedicationRequest-T (MedicationRequest)](MedicationRequest-ExampleMedicationRequest-T.md)
* [ERP-TPrescription-OperationOutcome-1 (OperationOutcome)](OperationOutcome-ERP-TPrescription-OperationOutcome-1.md)
* [Stadt-Apotheke (Organization)](Organization-ExampleOrganization-T.md)
* [TRP-Carbon-Copy (Parameters)](Parameters-TRP-Carbon-Copy.md)
