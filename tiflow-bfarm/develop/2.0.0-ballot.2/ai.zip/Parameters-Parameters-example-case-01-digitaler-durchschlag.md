#  - TIFlow - Datenaustausch BfArM Webdienst v2.0.0-ballot.2

TIFlow - Datenaustausch BfArM Webdienst

Version 2.0.0-ballot.2 - ci-build 

* [**Table of Contents**](toc.md)
* [**FHIR-Artefakte**](artifacts.md)
* ****

## Parameters: 



## Resource Content

```json
{
  "resourceType" : "Parameters",
  "id" : "Parameters-example-case-01-digitaler-durchschlag",
  "meta" : {
    "profile" : ["https://gematik.de/fhir/tiflow/bfarm/StructureDefinition/erp-tprescription-carbon-copy|1.1"]
  },
  "parameter" : [{
    "name" : "rxPrescription",
    "part" : [{
      "name" : "prescriptionSignatureDate",
      "valueInstant" : "2026-04-01T08:23:12Z"
    },
    {
      "name" : "prescriptionId",
      "valueIdentifier" : {
        "system" : "https://gematik.de/fhir/erp/NamingSystem/GEM_ERP_NS_PrescriptionId",
        "value" : "166.100.000.000.001.39"
      }
    },
    {
      "name" : "medicationRequest",
      "resource" : {
        "resourceType" : "MedicationRequest",
        "extension" : [{
          "extension" : [{
            "url" : "off-label",
            "valueBoolean" : true
          },
          {
            "url" : "childbearing-potential",
            "valueBoolean" : false
          },
          {
            "url" : "security-compliance",
            "valueBoolean" : true
          },
          {
            "url" : "hand-out-information-material",
            "valueBoolean" : true
          },
          {
            "url" : "declaration-of-expertise",
            "valueBoolean" : true
          }],
          "url" : "https://gematik.de/fhir/epa-medication/StructureDefinition/teratogenic-extension"
        },
        {
          "extension" : [{
            "url" : "algorithmVersion",
            "valueString" : "1.0.0"
          },
          {
            "url" : "language",
            "valueCode" : "de-DE"
          }],
          "url" : "http://ig.fhir.de/igs/medication/StructureDefinition/GeneratedDosageInstructionsMeta"
        },
        {
          "url" : "http://hl7.org/fhir/5.0/StructureDefinition/extension-MedicationRequest.renderedDosageInstruction",
          "valueMarkdown" : "0-0-1-0 Stück"
        }],
        "status" : "completed",
        "intent" : "order",
        "medicationReference" : {
          "reference" : "urn:uuid:a3ca01a4-92c1-422a-87d9-ef046e94527f"
        },
        "subject" : {
          "identifier" : {
            "_system" : {
              "extension" : [{
                "url" : "http://hl7.org/fhir/StructureDefinition/data-absent-reason",
                "valueCode" : "not-permitted"
              }]
            },
            "_value" : {
              "extension" : [{
                "url" : "http://hl7.org/fhir/StructureDefinition/data-absent-reason",
                "valueCode" : "not-permitted"
              }]
            }
          }
        },
        "authoredOn" : "2025-05-20",
        "dosageInstruction" : [{
          "timing" : {
            "repeat" : {
              "frequency" : 1,
              "period" : 1,
              "periodUnit" : "d",
              "when" : ["EVE"]
            }
          },
          "doseAndRate" : [{
            "doseQuantity" : {
              "value" : 1,
              "unit" : "Stück",
              "system" : "https://fhir.kbv.de/CodeSystem/KBV_CS_SFHIR_BMP_DOSIEREINHEIT",
              "code" : "1"
            }
          }]
        }],
        "dispenseRequest" : {
          "quantity" : {
            "value" : 1,
            "unit" : "Packung"
          },
          "expectedSupplyDuration" : {
            "value" : 3,
            "unit" : "Woche(n)"
          }
        }
      }
    },
    {
      "name" : "medication",
      "resource" : {
        "resourceType" : "Medication",
        "id" : "a3ca01a4-92c1-422a-87d9-ef046e94527f",
        "extension" : [{
          "url" : "http://fhir.de/StructureDefinition/normgroesse",
          "valueCode" : "N1"
        }],
        "code" : {
          "coding" : [{
            "system" : "http://fhir.de/CodeSystem/ifa/pzn",
            "code" : "19201712"
          }],
          "text" : "Pomalidomid Accord 1 mg 21 x 1 Hartkapseln"
        },
        "form" : {
          "coding" : [{
            "system" : "https://fhir.kbv.de/CodeSystem/KBV_CS_SFHIR_KBV_DARREICHUNGSFORM",
            "code" : "HKP"
          }]
        },
        "amount" : {
          "numerator" : {
            "extension" : [{
              "url" : "https://gematik.de/fhir/epa-medication/StructureDefinition/medication-packaging-size-extension",
              "valueString" : "21"
            }],
            "unit" : "Stück"
          },
          "denominator" : {
            "value" : 1
          }
        },
        "ingredient" : [{
          "itemCodeableConcept" : {
            "text" : "Pomalidomid"
          },
          "strength" : {
            "numerator" : {
              "value" : 1,
              "unit" : "mg"
            },
            "denominator" : {
              "value" : 1,
              "unit" : "Stück"
            }
          }
        }]
      }
    }]
  },
  {
    "name" : "rxDispensation",
    "part" : [{
      "name" : "dispenseOrganization",
      "resource" : {
        "resourceType" : "Organization",
        "id" : "3-07.2.1234560000.10.789",
        "identifier" : [{
          "system" : "https://gematik.de/fhir/sid/telematik-id",
          "value" : "3-07.2.1234560000.10.789"
        }],
        "name" : "Schwarzwald Apotheke",
        "telecom" : [{
          "system" : "phone",
          "value" : "1234",
          "use" : "work"
        }],
        "address" : [{
          "use" : "work",
          "type" : "postal",
          "text" : "Schwarzwaldstr. 18&#13;&#10;63762&#13;&#10;Großostheim&#13;&#10;Bayern&#13;&#10;DE",
          "line" : ["Schwarzwaldstr. 18"],
          "city" : "Großostheim",
          "state" : "Bayern",
          "postalCode" : "63762",
          "country" : "DE"
        }]
      }
    },
    {
      "name" : "dispenseInformation",
      "part" : [{
        "name" : "medicationDispense",
        "resource" : {
          "resourceType" : "MedicationDispense",
          "status" : "completed",
          "medicationReference" : {
            "reference" : "urn:uuid:8e2e5e65-4c5d-49f2-8efc-c30e40838273"
          },
          "performer" : [{
            "actor" : {
              "reference" : "Organization/3-07.2.1234560000.10.789"
            }
          }],
          "quantity" : {
            "value" : 1,
            "unit" : "Packung"
          },
          "whenHandedOver" : "2025-10-30"
        }
      },
      {
        "name" : "medication",
        "resource" : {
          "resourceType" : "Medication",
          "id" : "8e2e5e65-4c5d-49f2-8efc-c30e40838273",
          "code" : {
            "coding" : [{
              "system" : "http://fhir.de/CodeSystem/ifa/pzn",
              "code" : "19201712"
            }],
            "text" : "Pomalidomid Accord 1 mg 21 x 1 Hartkapseln"
          },
          "form" : {
            "coding" : [{
              "system" : "https://fhir.kbv.de/CodeSystem/KBV_CS_SFHIR_KBV_DARREICHUNGSFORM",
              "code" : "TAB",
              "display" : "Tabletten"
            }]
          },
          "amount" : {
            "numerator" : {
              "extension" : [{
                "url" : "https://gematik.de/fhir/epa-medication/StructureDefinition/medication-packaging-size-extension",
                "valueString" : "21"
              }],
              "unit" : "St"
            },
            "denominator" : {
              "value" : 1
            }
          },
          "ingredient" : [{
            "itemCodeableConcept" : {
              "text" : "Pomalidomid"
            },
            "strength" : {
              "numerator" : {
                "value" : 1,
                "unit" : "mg"
              },
              "denominator" : {
                "value" : 1,
                "unit" : "Tbl."
              }
            }
          }]
        }
      }]
    }]
  }]
}

```
