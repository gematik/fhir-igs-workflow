# Beispiel VZD SearchSet Bundle - Implementation Guide TIFlow - Datenaustausch BfArM Webdienst v2.0.0-ballot.2

Implementation Guide

TIFlow - Datenaustausch BfArM Webdienst

Version 2.0.0-ballot.2 - ballot 

* [**Table of Contents**](toc.md)
* [**FHIR-Artefakte**](artifacts.md)
* **Beispiel VZD SearchSet Bundle**

## Example Bundle: Beispiel VZD SearchSet Bundle



## Resource Content

```json
{
  "resourceType" : "Bundle",
  "id" : "VZD-SearchSet-Bundle",
  "meta" : {
    "lastUpdated" : "2025-06-19T08:42:40.732+02:00"
  },
  "type" : "searchset",
  "total" : 3,
  "entry" : [{
    "fullUrl" : "https://fhir-directory-ref.vzd.ti-dienste.de/search/HealthcareService/a4f1b52e-c5de-47eb-874c-990c2b39bb77",
    "resource" : {
      "resourceType" : "HealthcareService",
      "id" : "a4f1b52e-c5de-47eb-874c-990c2b39bb77",
      "meta" : {
        "versionId" : "2",
        "lastUpdated" : "2024-03-27T17:49:37.898+01:00",
        "profile" : ["http://hl7.org/fhir/StructureDefinition/HealthcareService",
        "https://gematik.de/fhir/directory/StructureDefinition/HealthcareServiceDirectory"],
        "tag" : [{
          "system" : "https://gematik.de/fhir/directory/CodeSystem/Origin",
          "code" : "owner"
        }]
      },
      "identifier" : [{
        "system" : "http://hl7.org/fhir/sid/us-npi",
        "value" : "1b9b1767-5496-4c20-bfc1-32ad6d96adbc"
      }],
      "providedBy" : {
        "reference" : "Organization/4f5a9754-2a9d-486d-9eec-a5c6b5f95016"
      },
      "location" : [{
        "reference" : "Location/9514f96e-897d-492d-950f-aea11d6f2bb4"
      }],
      "telecom" : [{
        "system" : "phone",
        "value" : "1234",
        "use" : "work"
      }],
      "endpoint" : [{
        "reference" : "Endpoint/11d91987-d31e-468f-962e-845bb0c743c3"
      }]
    },
    "search" : {
      "mode" : "match"
    }
  },
  {
    "fullUrl" : "https://fhir-directory-ref.vzd.ti-dienste.de/search/Organization/4f5a9754-2a9d-486d-9eec-a5c6b5f95016",
    "resource" : {
      "resourceType" : "Organization",
      "id" : "4f5a9754-2a9d-486d-9eec-a5c6b5f95016",
      "meta" : {
        "versionId" : "1",
        "lastUpdated" : "2023-03-23T14:14:28.492+01:00",
        "profile" : ["http://hl7.org/fhir/StructureDefinition/Organization",
        "https://gematik.de/fhir/directory/StructureDefinition/OrganizationDirectory"],
        "tag" : [{
          "system" : "https://gematik.de/fhir/directory/CodeSystem/Origin",
          "code" : "owner"
        }]
      },
      "identifier" : [{
        "system" : "http://hl7.org/fhir/sid/us-npi",
        "value" : "44bb2f53-cdd7-4098-9d52-a6c5ac0ddc8d"
      },
      {
        "type" : {
          "coding" : [{
            "system" : "http://terminology.hl7.org/CodeSystem/v2-0203",
            "code" : "PRN"
          }]
        },
        "system" : "https://gematik.de/fhir/sid/telematik-id",
        "value" : "3-Test-APO000053"
      }],
      "active" : true,
      "type" : [{
        "coding" : [{
          "system" : "https://gematik.de/fhir/directory/CodeSystem/OrganizationProfessionOID",
          "code" : "1.2.276.0.76.4.54",
          "display" : "Öffentliche Apotheke"
        }]
      }],
      "name" : "Organisation 3-Test-APO000053",
      "alias" : ["Organisation 3-Test-APO000053"]
    },
    "search" : {
      "mode" : "include"
    }
  },
  {
    "fullUrl" : "https://fhir-directory-ref.vzd.ti-dienste.de/search/Location/9514f96e-897d-492d-950f-aea11d6f2bb4",
    "resource" : {
      "resourceType" : "Location",
      "id" : "9514f96e-897d-492d-950f-aea11d6f2bb4",
      "meta" : {
        "versionId" : "1",
        "lastUpdated" : "2023-03-23T14:14:28.492+01:00",
        "profile" : ["http://hl7.org/fhir/StructureDefinition/Location",
        "https://gematik.de/fhir/directory/StructureDefinition/LocationDirectory"],
        "tag" : [{
          "system" : "https://gematik.de/fhir/directory/CodeSystem/Origin",
          "code" : "owner"
        }]
      },
      "identifier" : [{
        "system" : "http://hl7.org/fhir/sid/us-npi",
        "value" : "995d8a48-f7fc-4ffb-a676-feb18c7c052c"
      }],
      "name" : "Location of Organisation 1-2arvtst-ap000053",
      "address" : {
        "use" : "work",
        "type" : "postal",
        "text" : "Schwarzwaldstr. 18&#13;&#10;63762&#13;&#10;Großostheim&#13;&#10;Bayern&#13;&#10;DE",
        "line" : ["Schwarzwaldstr. 18"],
        "city" : "Großostheim",
        "state" : "Bayern",
        "postalCode" : "63762",
        "country" : "DE"
      }
    },
    "search" : {
      "mode" : "include"
    }
  }]
}

```
