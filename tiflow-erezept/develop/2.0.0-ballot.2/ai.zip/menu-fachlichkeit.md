# Fachliche Aspekte zur Arzneimittelverordnung - TIFlow - Verordnungen für Arzneimittel v2.0.0-ballot.2

TIFlow - Verordnungen für Arzneimittel

Version 2.0.0-ballot.2 - ci-build 

* [**Table of Contents**](toc.md)
* **Fachliche Aspekte zur Arzneimittelverordnung**

## Fachliche Aspekte zur Arzneimittelverordnung

Folgende Szenarien werden in diesem Implementation Guide beschrieben:

* [Verordnung von apothekenpflichtigen Arzneimitteln](menu-fachlichkeit-e-rezept.md)
* [Verordnung mit Steuerung durch Leistungserbringer](menu-fachlichkeit-wf-le.md)
* [Verordnung von Mehrfachverordnungen (MVO)](menu-fachlichkeit-mvo.md)
* [Verordnung von E-T-Rezepten](menu-fachlichkeit-t-rezept.md)

Auf diesen Seiten werden Vorgaben und Empfehlungen für eine gute UX getroffen:

* [Best practice UX Primärsysteme für verordnende LEIs](./menu-fachlichkeit-ux-verordnend.md)
* [Best practice UX Primärsysteme für abgebende LEIs](./menu-fachlichkeit-ux-abgebend.md)

