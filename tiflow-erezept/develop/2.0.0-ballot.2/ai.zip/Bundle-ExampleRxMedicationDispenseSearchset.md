# MedicationDispense searchset response for Rx - TIFlow - Verordnungen für Arzneimittel v2.0.0-ballot.2

TIFlow - Verordnungen für Arzneimittel

Version 2.0.0-ballot.2 - ci-build 

* [**Table of Contents**](toc.md)
* [**FHIR-Artefakte**](artifacts.md)
* **MedicationDispense searchset response for Rx**

## Example Bundle: MedicationDispense searchset response for Rx



## Resource Content

```json
{
  "resourceType" : "Bundle",
  "id" : "ExampleRxMedicationDispenseSearchset",
  "type" : "searchset",
  "total" : 1,
  "link" : [{
    "relation" : "self",
    "url" : "https://erp-ref.example.org/MedicationDispense?whenhandedover=ge2026-03-01"
  }],
  "entry" : [{
    "fullUrl" : "https://erp-ref.example.org/MedicationDispense/ExampleRxMedicationDispense",
    "resource" : {
      "resourceType" : "MedicationDispense",
      "id" : "ExampleRxMedicationDispense",
      "status" : "completed",
      "medicationCodeableConcept" : {
        "text" : "Sumatriptan 50 mg"
      },
      "subject" : {
        "identifier" : {
          "system" : "http://fhir.de/sid/gkv/kvid-10",
          "value" : "X123456789"
        }
      },
      "whenHandedOver" : "2026-03-20T11:10:00+01:00"
    },
    "search" : {
      "mode" : "match"
    }
  }]
}

```
