# output-example-4 - Implementation Guide TIFlow - Verordnungen für Arzneimittel v2.0.0-ballot.3

Implementation Guide

TIFlow - Verordnungen für Arzneimittel

Version 2.0.0-ballot.3 - ci-build 

* [**Table of Contents**](toc.md)
* [**FHIR-Artefakte**](artifacts.md)
* **output-example-4**

## Parameters: output-example-4



## Resource Content

```json
{
  "resourceType" : "Parameters",
  "id" : "output-example-4",
  "parameter" : [{
    "name" : "rxPrescription",
    "part" : [{
      "name" : "authoredOn",
      "valueDateTime" : "2024-05-20"
    },
    {
      "name" : "medication",
      "resource" : {
        "resourceType" : "Medication",
        "meta" : {
          "profile" : ["https://gematik.de/fhir/epa-medication/StructureDefinition/epa-medication"]
        },
        "extension" : [{
          "url" : "https://gematik.de/fhir/epa-medication/StructureDefinition/drug-category-extension",
          "valueCoding" : {
            "system" : "https://gematik.de/fhir/epa-medication/CodeSystem/epa-drug-category-cs",
            "code" : "00"
          }
        },
        {
          "url" : "https://gematik.de/fhir/epa-medication/StructureDefinition/medication-id-vaccine-extension",
          "valueBoolean" : false
        }],
        "code" : {
          "coding" : [{
            "system" : "http://fhir.de/CodeSystem/ifa/pzn",
            "code" : "00814665"
          }],
          "text" : "Januvia® 50 mg 28 Filmtabletten N1"
        },
        "form" : {
          "coding" : [{
            "system" : "https://fhir.kbv.de/CodeSystem/KBV_CS_SFHIR_KBV_DARREICHUNGSFORM",
            "code" : "FTA"
          }]
        }
      }
    },
    {
      "name" : "medicationRequest",
      "resource" : {
        "resourceType" : "MedicationRequest",
        "meta" : {
          "profile" : ["https://gematik.de/fhir/epa-medication/StructureDefinition/epa-medication-request"]
        },
        "extension" : [{
          "url" : "https://gematik.de/fhir/epa-medication/StructureDefinition/indicator-ser-extension",
          "valueBoolean" : false
        },
        {
          "extension" : [{
            "url" : "indicator",
            "valueBoolean" : false
          }],
          "url" : "https://gematik.de/fhir/epa-medication/StructureDefinition/multiple-prescription-extension"
        }],
        "status" : "active",
        "intent" : "order",
        "medicationReference" : {
          "reference" : "urn:uuid:47076fb4-dc5c-4f75-85f6-b200033b3280"
        },
        "subject" : {
          "identifier" : {
            "system" : "http://fhir.de/sid/gkv/kvid-10",
            "value" : "X110411319"
          }
        },
        "authoredOn" : "2024-05-20",
        "requester" : {
          "reference" : "urn:uuid:bc329f24-3d65-4286-bf06-b54dd6cad655"
        },
        "basedOn" : [{
          "identifier" : {
            "system" : "https://gematik.de/fhir/sid/emp-identifier",
            "value" : "8cc8e04b-6df7-43b5-b847-508268e95ba7"
          }
        }],
        "dispenseRequest" : {
          "quantity" : {
            "value" : 1,
            "unit" : "Packung"
          }
        },
        "substitution" : {
          "allowedBoolean" : true
        }
      }
    },
    {
      "name" : "organization",
      "resource" : {
        "resourceType" : "Organization",
        "meta" : {
          "profile" : ["https://gematik.de/fhir/directory/StructureDefinition/OrganizationDirectory"],
          "tag" : [{
            "system" : "https://gematik.de/fhir/directory/CodeSystem/Origin",
            "code" : "ldap"
          }]
        },
        "identifier" : [{
          "type" : {
            "coding" : [{
              "system" : "http://terminology.hl7.org/CodeSystem/v2-0203",
              "code" : "BSNR"
            }]
          },
          "system" : "https://fhir.kbv.de/NamingSystem/KBV_NS_Base_BSNR",
          "value" : "724444400"
        },
        {
          "system" : "https://gematik.de/fhir/sid/telematik-id",
          "value" : "2-2.58.00000040"
        }],
        "name" : "Hausarztpraxis",
        "telecom" : [{
          "system" : "phone",
          "value" : "0301234567"
        },
        {
          "system" : "fax",
          "value" : "030123456789"
        },
        {
          "system" : "email",
          "value" : "mvz@e-mail.de"
        }],
        "address" : [{
          "type" : "both",
          "line" : ["Herbert-Lewin-Platz 2"],
          "_line" : [{
            "extension" : [{
              "url" : "http://hl7.org/fhir/StructureDefinition/iso21090-ADXP-houseNumber",
              "valueString" : "2"
            },
            {
              "url" : "http://hl7.org/fhir/StructureDefinition/iso21090-ADXP-streetName",
              "valueString" : "Herbert-Lewin-Platz"
            }]
          }],
          "city" : "Berlin",
          "postalCode" : "10623",
          "country" : "D"
        },
        {
          "type" : "both",
          "line" : ["Herbert-Lewin-Platz 2"],
          "_line" : [{
            "extension" : [{
              "url" : "http://hl7.org/fhir/StructureDefinition/iso21090-ADXP-houseNumber",
              "valueString" : "2"
            },
            {
              "url" : "http://hl7.org/fhir/StructureDefinition/iso21090-ADXP-streetName",
              "valueString" : "Herbert-Lewin-Platz"
            }]
          }],
          "city" : "Berlin",
          "postalCode" : "10623",
          "country" : "D"
        }]
      }
    },
    {
      "name" : "practitioner",
      "resource" : {
        "resourceType" : "Practitioner",
        "meta" : {
          "profile" : ["https://gematik.de/fhir/directory/StructureDefinition/PractitionerDirectory"],
          "tag" : [{
            "system" : "https://gematik.de/fhir/directory/CodeSystem/Origin",
            "code" : "ldap"
          }]
        },
        "name" : [{
          "use" : "official",
          "text" : "Dr. med. Paul Freiherr von Müller",
          "family" : "Freiherr von Müller",
          "_family" : {
            "extension" : [{
              "url" : "http://hl7.org/fhir/StructureDefinition/humanname-own-prefix",
              "valueString" : "von"
            },
            {
              "url" : "http://fhir.de/StructureDefinition/humanname-namenszusatz",
              "valueString" : "Freiherr"
            },
            {
              "url" : "http://hl7.org/fhir/StructureDefinition/humanname-own-name",
              "valueString" : "Müller"
            }]
          },
          "given" : ["Paul"],
          "prefix" : ["Dr. med."],
          "_prefix" : [{
            "extension" : [{
              "url" : "http://hl7.org/fhir/StructureDefinition/iso21090-EN-qualifier",
              "valueCode" : "AC"
            }]
          }]
        }]
      }
    },
    {
      "name" : "prescriptionId",
      "valueString" : "160.100.000.000.006.24"
    }]
  }]
}

```
