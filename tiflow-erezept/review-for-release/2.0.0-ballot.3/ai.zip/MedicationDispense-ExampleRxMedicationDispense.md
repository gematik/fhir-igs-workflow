# Rx MedicationDispense example - Implementation Guide TIFlow - Verordnungen für Arzneimittel v2.0.0-ballot.3

Implementation Guide

TIFlow - Verordnungen für Arzneimittel

Version 2.0.0-ballot.3 - ci-build 

* [**Table of Contents**](toc.md)
* [**FHIR-Artefakte**](artifacts.md)
* **Rx MedicationDispense example**

## Example MedicationDispense: Rx MedicationDispense example



## Resource Content

```json
{
  "resourceType" : "MedicationDispense",
  "id" : "ExampleRxMedicationDispense",
  "status" : "completed",
  "medicationCodeableConcept" : {
    "text" : "Sumatriptan 50 mg"
  },
  "subject" : {
    "identifier" : {
      "system" : "http://fhir.de/sid/gkv/kvid-10",
      "value" : "X123456789"
    }
  },
  "whenHandedOver" : "2026-03-20T11:10:00+01:00"
}

```
