# E-Rezept-Verordnungs-Bundle (unvollständig) - Implementation Guide TIFlow - Verordnungen für Arzneimittel v2.0.0-ballot.3

Implementation Guide

TIFlow - Verordnungen für Arzneimittel

Version 2.0.0-ballot.3 - ci-build 

* [**Table of Contents**](toc.md)
* [**FHIR-Artefakte**](artifacts.md)
* **E-Rezept-Verordnungs-Bundle (unvollständig)**

## Example Bundle: E-Rezept-Verordnungs-Bundle (unvollständig)



## Resource Content

```json
{
  "resourceType" : "Bundle",
  "id" : "ExampleERPBundle",
  "meta" : {
    "tag" : [{
      "display" : "Unvollständiges Beispiel eines E-Rezept-Bundles - https://fhir.kbv.de/StructureDefinition/KBV_PR_EVDGA_Bundle|1.2"
    }]
  },
  "identifier" : {
    "system" : "https://gematik.de/fhir/erp/NamingSystem/GEM_ERP_NS_PrescriptionId",
    "value" : "160.000.000.000.000.01"
  },
  "type" : "document",
  "timestamp" : "2028-10-01T15:29:00.434+00:00",
  "entry" : [{
    "fullUrl" : "https://erp-ref.zentral.erp.splitdns.ti-dienste.de/Composition/c624cf47-e235-4624-af71-0a09dc9254dc",
    "resource" : {
      "resourceType" : "Composition",
      "id" : "c624cf47-e235-4624-af71-0a09dc9254dc",
      "meta" : {
        "profile" : ["https://gematik.de/fhir/erp/StructureDefinition/GEM_ERP_PR_Composition"]
      },
      "extension" : [{
        "url" : "https://gematik.de/fhir/erp/StructureDefinition/GEM_ERP_EX_Beneficiary",
        "valueIdentifier" : {
          "system" : "https://gematik.de/fhir/sid/telematik-id",
          "value" : "3-SMC-B-Testkarte-883110000129070"
        }
      }],
      "status" : "final",
      "type" : {
        "coding" : [{
          "system" : "https://gematik.de/fhir/erp/CodeSystem/GEM_ERP_CS_DocumentType",
          "code" : "3",
          "display" : "Receipt"
        }]
      },
      "date" : "2028-10-01T15:29:00+00:00",
      "author" : [{
        "reference" : "https://erp-ref.zentral.erp.splitdns.ti-dienste.de/Device/ReceiptBundleDevice"
      }],
      "title" : "Quittung",
      "event" : [{
        "period" : {
          "start" : "2028-10-01T15:29:00+00:00",
          "end" : "2028-10-01T15:29:00+00:00"
        }
      }],
      "section" : [{
        "entry" : [{
          "reference" : "urn:uuid:b939a82a-9c23-4b6d-a139-f468d1b9d652"
        }]
      }]
    }
  },
  {
    "fullUrl" : "https://erp-ref.zentral.erp.splitdns.ti-dienste.de/Device/ReceiptBundleDevice",
    "resource" : {
      "resourceType" : "Device",
      "id" : "ReceiptBundleDevice",
      "meta" : {
        "profile" : ["https://gematik.de/fhir/erp/StructureDefinition/GEM_ERP_PR_Device"]
      },
      "status" : "active",
      "serialNumber" : "2.0.0",
      "deviceName" : [{
        "name" : "TI-Flow-Fachdienst",
        "type" : "user-friendly-name"
      }],
      "version" : [{
        "value" : "2.0.0"
      }],
      "contact" : [{
        "system" : "email",
        "value" : "betrieb@gematik.de"
      }]
    }
  },
  {
    "fullUrl" : "urn:uuid:b939a82a-9c23-4b6d-a139-f468d1b9d652",
    "resource" : {
      "resourceType" : "Binary",
      "id" : "b939a82a-9c23-4b6d-a139-f468d1b9d652",
      "meta" : {
        "profile" : ["https://gematik.de/fhir/erp/StructureDefinition/GEM_ERP_PR_Digest"]
      },
      "contentType" : "application/octet-stream",
      "data" : "tJg8c5ZtdhzEEhJ0ZpAsUVFx5dKuYgQFs5oKgthi17M="
    }
  }]
}

```
