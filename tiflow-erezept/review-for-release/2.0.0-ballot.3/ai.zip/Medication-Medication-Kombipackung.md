# Medikament-Kombipackung - Implementation Guide TIFlow - Verordnungen für Arzneimittel v2.0.0-ballot.3

Implementation Guide

TIFlow - Verordnungen für Arzneimittel

Version 2.0.0-ballot.3 - ci-build 

* [**Table of Contents**](toc.md)
* [**FHIR-Artefakte**](artifacts.md)
* **Medikament-Kombipackung**

## Example Medication: Medikament-Kombipackung



## Resource Content

```json
{
  "resourceType" : "Medication",
  "id" : "Medication-Kombipackung",
  "meta" : {
    "profile" : ["https://gematik.de/fhir/erp/StructureDefinition/GEM_ERP_PR_Medication|2.0"]
  },
  "contained" : [{
    "resourceType" : "Medication",
    "id" : "Augentropfen",
    "meta" : {
      "profile" : ["https://gematik.de/fhir/ti/StructureDefinition/ti-medication-dgmp"]
    },
    "extension" : [{
      "url" : "https://gematik.de/fhir/epa-medication/StructureDefinition/epa-medication-type-extension",
      "valueCoding" : {
        "system" : "http://snomed.info/sct",
        "code" : "373873005",
        "display" : "Pharmaceutical / biologic product"
      }
    }],
    "ingredient" : [{
      "itemCodeableConcept" : {
        "coding" : [{
          "system" : "http://fhir.de/CodeSystem/bfarm/atc",
          "version" : "1.4.0",
          "code" : "R01AC01",
          "display" : "Natriumcromoglicat"
        }]
      },
      "strength" : {
        "numerator" : {
          "value" : 20,
          "unit" : "mg",
          "system" : "http://unitsofmeasure.org",
          "code" : "mg"
        },
        "denominator" : {
          "value" : 1,
          "unit" : "ml",
          "system" : "http://unitsofmeasure.org",
          "code" : "ml"
        }
      }
    }]
  },
  {
    "resourceType" : "Medication",
    "id" : "NasenSpray",
    "meta" : {
      "profile" : ["https://gematik.de/fhir/ti/StructureDefinition/ti-medication-dgmp"]
    },
    "extension" : [{
      "url" : "https://gematik.de/fhir/epa-medication/StructureDefinition/epa-medication-type-extension",
      "valueCoding" : {
        "system" : "http://snomed.info/sct",
        "code" : "373873005",
        "display" : "Pharmaceutical / biologic product"
      }
    }],
    "ingredient" : [{
      "itemCodeableConcept" : {
        "coding" : [{
          "system" : "http://fhir.de/CodeSystem/bfarm/atc",
          "version" : "1.4.0",
          "code" : "R01AC01",
          "display" : "Natriumcromoglicat"
        }]
      },
      "strength" : {
        "numerator" : {
          "value" : 2.8,
          "unit" : "mg",
          "system" : "http://unitsofmeasure.org",
          "code" : "mg"
        },
        "denominator" : {
          "value" : 1,
          "unit" : "Sprühstoß",
          "system" : "http://unitsofmeasure.org",
          "code" : "1"
        }
      }
    }]
  }],
  "extension" : [{
    "url" : "https://gematik.de/fhir/epa-medication/StructureDefinition/medication-id-vaccine-extension",
    "valueBoolean" : false
  },
  {
    "url" : "https://gematik.de/fhir/epa-medication/StructureDefinition/drug-category-extension",
    "valueCoding" : {
      "system" : "https://gematik.de/fhir/epa-medication/CodeSystem/epa-drug-category-cs",
      "code" : "00",
      "display" : "Arzneimittel oder in die Arzneimittelversorgung nach § 31 SGB V einbezogenes Produkt"
    }
  }],
  "code" : {
    "coding" : [{
      "system" : "http://fhir.de/CodeSystem/ifa/pzn",
      "code" : "1746517",
      "display" : "CROMO-RATIOPHARM Kombipackung"
    }]
  },
  "status" : "active",
  "form" : {
    "coding" : [{
      "system" : "https://fhir.kbv.de/CodeSystem/KBV_CS_SFHIR_KBV_DARREICHUNGSFORM",
      "code" : "KPG"
    }],
    "text" : "Kombipackung"
  },
  "ingredient" : [{
    "itemReference" : {
      "reference" : "#NasenSpray"
    }
  },
  {
    "itemReference" : {
      "reference" : "#Augentropfen"
    }
  }],
  "batch" : {
    "lotNumber" : "56498416854"
  }
}

```
