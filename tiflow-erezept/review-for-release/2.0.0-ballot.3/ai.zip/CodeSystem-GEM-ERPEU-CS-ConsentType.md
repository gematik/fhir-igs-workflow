# CodeSystem of types for a consent - Implementation Guide TIFlow - Verordnungen für Arzneimittel v2.0.0-ballot.3

Implementation Guide

TIFlow - Verordnungen für Arzneimittel

Version 2.0.0-ballot.3 - ci-build 

* [**Table of Contents**](toc.md)
* [**FHIR-Artefakte**](artifacts.md)
* **CodeSystem of types for a consent**

## CodeSystem: CodeSystem of types for a consent 

| | |
| :--- | :--- |
| *Official URL*:https://gematik.de/fhir/tiflow-erezept/CodeSystem/GEM-ERPEU-CS-ConsentType | *Version*:2.0.0-ballot.3 |
| Draft as of 2026-06-30 | *Computable Name*:GEM_ERPEU_CS_ConsentType |
| **Copyright/Legal**: gematik GmbH | |

 
Type of patient consent. 

 This Code system is referenced in the content logical definition of the following value sets: 

* [ValueSet of Consent Codes](ValueSet-GEM-ERPEU-VS-ConsentType.md)



## Resource Content

```json
{
  "resourceType" : "CodeSystem",
  "id" : "GEM-ERPEU-CS-ConsentType",
  "url" : "https://gematik.de/fhir/tiflow-erezept/CodeSystem/GEM-ERPEU-CS-ConsentType",
  "version" : "2.0.0-ballot.3",
  "name" : "GEM_ERPEU_CS_ConsentType",
  "title" : "CodeSystem of types for a consent",
  "status" : "draft",
  "date" : "2026-06-30",
  "publisher" : "gematik GmbH",
  "contact" : [{
    "name" : "gematik GmbH",
    "telecom" : [{
      "system" : "url",
      "value" : "https://gematik.de"
    },
    {
      "system" : "email",
      "value" : "erp-umsetzung@gematik.de"
    }]
  }],
  "description" : "Type of patient consent.",
  "jurisdiction" : [{
    "coding" : [{
      "system" : "urn:iso:std:iso:3166",
      "code" : "DE",
      "display" : "Germany"
    }]
  }],
  "copyright" : "gematik GmbH",
  "caseSensitive" : true,
  "content" : "complete",
  "count" : 1,
  "concept" : [{
    "code" : "EUDISPCONS",
    "display" : "Consent for redeeming e-prescriptions in EU countries"
  }]
}

```
