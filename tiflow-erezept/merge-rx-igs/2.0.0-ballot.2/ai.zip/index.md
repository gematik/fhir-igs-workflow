# Implementation Guide TI-Flow-Fachdienst - Implementation Guide TIFlow - Verordnungen für Arzneimittel v2.0.0-ballot.2

Implementation Guide

TIFlow - Verordnungen für Arzneimittel

Version 2.0.0-ballot.2 - ballot 

* [**Table of Contents**](toc.md)
* **Implementation Guide TI-Flow-Fachdienst**

## Implementation Guide TI-Flow-Fachdienst

| | |
| :--- | :--- |
| *Official URL*:https://gematik.de/fhir/tiflow-erezept/ImplementationGuide/de.gematik.tiflow.erezept | *Version*:2.0.0-ballot.2 |
| Draft as of 2026-06-30 | *Computable Name*:gemIG_TIFlow_erezept |

Dieser Implementation Guide beschreibt die Datenmodelle und Prozesse des TI-Flow-Fachdienstes für den Anwendungsfall von "Arzneimittelverordnung". Er bildet das Fundament für die fachlichen Szenarien und die technischen Schnittstellen im E-Rezept-Workflow für dieses Szenario.

### Zweck und Geltungsbereich

* Grundlegende Workflows für E-Rezepte zur Arzneimittelversorgung: 
* **160, 200** zur Verordnung von Arzneimitteln
* **169, 209** zur Verordnung von Arzneimitteln mit Workflowsteuerung durch den Leistungserbringer
* **166** zur Verordnung von E-T-Rezepten
 
* Profile, Operationen und Validierungsregeln
* Funktionale Anforderungen
* Einlösen von E-Rezepten im EU-Ausland (Feature "EU Zugriff E-Rezept", siehe [gemspec eRp EU 1.0.1](https://gemspec.gematik.de/docs/gemF/gemF_eRp_EU/gemF_eRp_EU_V1.0.1/)): Ergänzungen an den Schnittstellen des TI-Flow-Fachdienstes sowie Use Cases für Versicherte zur Verwaltung von Einwilligung und Zugriff

### Nicht im Scope

* Modul-übergreifende Anwendungsfälle
* Produkttyp-spezifische Implementierungsdetails außerhalb des Fachdienstes
* Beschreibung und Definition von Prozessen außerhalb des Fachdienstes
* Anbindung der TI an die eHDSI
* Mapping zwischen deutschen Verordnungsdaten und dem EU-Datenmodell
* Abrechnung von im EU-Ausland eingelösten E-Rezepten

### Anforderungen zur Umsetzung des IGs

funkt. Eignung: Herstellererklärung

funkt. Eignung: Herstellererklärung

funkt. Eignung: Herstellererklärung

funkt. Eignung: HerstellererklärungDer TI-Flow-Fachdienst und dessen Clients MÜSSEN zur Umsetzung der Workflows 160, 166, 169, 200 und 209 den Implementation Guide "E-Rezept für Arzneimittel" umsetzen.

funkt. Eignung: Herstellererklärung

funkt. Eignung: Herstellererklärung

funkt. Eignung: Herstellererklärung

funkt. Eignung: HerstellererklärungDer TI-Flow-Fachdienst und dessen Clients MÜSSEN zur Umsetzung des Implementation Guides "E-Rezept für Arzneimittel" alle Anforderungen und FHIR-Artefakte umsetzen, die in diesem IG definiert sind, sowie Anforderungen und Artefakte aus [gemIG_TIFlow_core], die in diesem IG referenziert werden.

funkt. Eignung: Herstellererklärung

funkt. Eignung: HerstellererklärungDer TI-Flow-Fachdienst und dessen Client MÜSSEN zur Umsetzung des Einlösens von E-Rezepten im EU Ausland die in diesem Implementation Guide definierten Inhalte zum Feature "EU Zugriff E-Rezept" umsetzen.

funkt. Eignung: Herstellererklärung

funkt. Eignung: HerstellererklärungDer TI-Flow-Fachdienst und dessen Client MÜSSEN zur Umsetzung des Features "EU Zugriff E-Rezept" alle Anforderungen und FHIR-Artefakte umsetzen, die in diesem IG für das Feature definiert sind, sowie Anforderungen und Artefakte aus [gemIG_TIFlow_core], die in diesem IG referenziert werden.
### Wie dieser IG zu lesen ist

Dieser Implementation Guide ist "von links nach rechts" zu lesen. Die Menüstruktur beginnt mit fachlichen Inhalten, welche über die technischen Anwendungsfälle dann in den Spezifikationen der Endpunkte und APIs münden. Es wird empfohlen, die Inhalte in der vorgegebenen Reihenfolge zu lesen, um ein umfassendes Verständnis der Anforderungen und Spezifikationen zu erhalten.

Für einen Überblick über die Inhalte und die Struktur dieses Implementation Guides kann die [Inhaltsübersicht](toc.md) konsultiert werden. Dort sind die verschiedenen Kapitel und Abschnitte mit ihren jeweiligen Inhalten und Anforderungen aufgeführt.

### Abhängigkeiten






### Kontakt und Feedback

Für Fragen und Feedback wenden Sie sich bitte an [erp-umsetzung@gematik.de](mailto:erp-umsetzung@gematik.de).

### Rechtliche Hinweise

Copyright ©2026+ gematik GmbH

HL7®, HEALTH LEVEL SEVEN®, FHIR® und das FHIR®-Logo sind Marken von Health Level Seven International.

