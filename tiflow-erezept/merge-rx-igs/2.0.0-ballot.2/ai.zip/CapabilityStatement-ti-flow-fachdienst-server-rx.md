# TIFlow Fachdienst Server Capabilities - Implementation Guide TIFlow - Verordnungen für Arzneimittel v2.0.0-ballot.2

Implementation Guide

TIFlow - Verordnungen für Arzneimittel

Version 2.0.0-ballot.2 - ballot 

* [**Table of Contents**](toc.md)
* [**FHIR-Artefakte**](artifacts.md)
* **TIFlow Fachdienst Server Capabilities**

## CapabilityStatement: TIFlow Fachdienst Server Capabilities 

| | |
| :--- | :--- |
| *Official URL*:https://gematik.de/fhir/tiflow-erezept/CapabilityStatement/ti-flow-fachdienst-server-rx | *Version*:2.0.0-ballot.2 |
| Active as of 2026-06-30 | *Computable Name*: |

 
CapabilityStatement für den E-Rezept-Fachdienst (Arzneimittel-Workflow) 



## Resource Content

```json
{
  "resourceType" : "CapabilityStatement",
  "id" : "ti-flow-fachdienst-server-rx",
  "meta" : {
    "profile" : ["https://gematik.de/fhir/ti/StructureDefinition/ti-capability-statement"]
  },
  "extension" : [{
    "url" : "https://gematik.de/fhir/ti/StructureDefinition/extension-base-url",
    "valueString" : "https://tiflow.de/rx/fhir/v1"
  }],
  "url" : "https://gematik.de/fhir/tiflow-erezept/CapabilityStatement/ti-flow-fachdienst-server-rx",
  "version" : "2.0.0-ballot.2",
  "title" : "TIFlow Fachdienst Server Capabilities",
  "status" : "active",
  "date" : "2026-06-30",
  "publisher" : "gematik GmbH",
  "contact" : [{
    "name" : "gematik GmbH",
    "telecom" : [{
      "system" : "url",
      "value" : "https://gematik.de"
    },
    {
      "system" : "email",
      "value" : "erp-umsetzung@gematik.de"
    }]
  }],
  "description" : "CapabilityStatement für den E-Rezept-Fachdienst (Arzneimittel-Workflow)",
  "jurisdiction" : [{
    "coding" : [{
      "system" : "urn:iso:std:iso:3166",
      "code" : "DE",
      "display" : "Germany"
    }]
  }],
  "kind" : "requirements",
  "imports" : ["https://gematik.de/fhir/tiflow/CapabilityStatement/ti-flow-fachdienst-server"],
  "_imports" : [{
    "extension" : [{
      "url" : "http://hl7.org/fhir/StructureDefinition/capabilitystatement-expectation",
      "valueCode" : "SHALL"
    }]
  }],
  "fhirVersion" : "4.0.1",
  "format" : ["application/fhir+json", "application/fhir+xml"],
  "rest" : [{
    "mode" : "server",
    "resource" : [{
      "extension" : [{
        "url" : "http://hl7.org/fhir/StructureDefinition/capabilitystatement-expectation",
        "valueCode" : "SHALL"
      }],
      "type" : "Task",
      "supportedProfile" : ["https://gematik.de/fhir/erp/StructureDefinition/GEM_ERP_PR_Task"],
      "_supportedProfile" : [{
        "extension" : [{
          "url" : "http://hl7.org/fhir/StructureDefinition/capabilitystatement-expectation",
          "valueCode" : "SHALL"
        }]
      }],
      "interaction" : [{
        "extension" : [{
          "url" : "http://hl7.org/fhir/StructureDefinition/capabilitystatement-expectation",
          "valueCode" : "SHALL"
        },
        {
          "extension" : [{
            "url" : "statusCode",
            "valueString" : "400"
          },
          {
            "url" : "description",
            "valueString" : "Invalid request"
          },
          {
            "url" : "responseType",
            "valueString" : "TIFlowOperationOutcome"
          },
          {
            "url" : "errorCode",
            "valueString" : "MSG_BAD_FORMAT"
          }],
          "url" : "https://gematik.de/fhir/ti/StructureDefinition/extension-http-response-info"
        },
        {
          "extension" : [{
            "url" : "statusCode",
            "valueString" : "408"
          },
          {
            "url" : "description",
            "valueString" : "Timeout"
          },
          {
            "url" : "responseType",
            "valueString" : "TIFlowOperationOutcome"
          },
          {
            "url" : "errorCode",
            "valueString" : "TIFLOW_TIMEOUT"
          }],
          "url" : "https://gematik.de/fhir/ti/StructureDefinition/extension-http-response-info"
        },
        {
          "extension" : [{
            "url" : "statusCode",
            "valueString" : "500"
          },
          {
            "url" : "description",
            "valueString" : "Internal Server Error"
          },
          {
            "url" : "responseType",
            "valueString" : "TIFlowOperationOutcome"
          },
          {
            "url" : "errorCode",
            "valueString" : "TIFLOW_INTERNAL_ERROR"
          }],
          "url" : "https://gematik.de/fhir/ti/StructureDefinition/extension-http-response-info"
        },
        {
          "extension" : [{
            "url" : "statusCode",
            "valueString" : "200"
          },
          {
            "url" : "description",
            "valueString" : "Successful operation"
          }],
          "url" : "https://gematik.de/fhir/ti/StructureDefinition/extension-http-response-info"
        },
        {
          "extension" : [{
            "url" : "statusCode",
            "valueString" : "400"
          },
          {
            "url" : "description",
            "valueString" : "Unknown search parameter"
          },
          {
            "url" : "responseType",
            "valueString" : "TIFlowOperationOutcome"
          },
          {
            "url" : "errorCode",
            "valueString" : "MSG_PARAM_UNKNOWN"
          }],
          "url" : "https://gematik.de/fhir/ti/StructureDefinition/extension-http-response-info"
        },
        {
          "extension" : [{
            "url" : "statusCode",
            "valueString" : "400"
          },
          {
            "url" : "description",
            "valueString" : "Invalid query parameter(s)"
          },
          {
            "url" : "responseType",
            "valueString" : "TIFlowOperationOutcome"
          },
          {
            "url" : "errorCode",
            "valueString" : "MSG_BAD_SYNTAX"
          }],
          "url" : "https://gematik.de/fhir/ti/StructureDefinition/extension-http-response-info"
        },
        {
          "extension" : [{
            "url" : "statusCode",
            "valueString" : "404"
          },
          {
            "url" : "description",
            "valueString" : "Unknown resource type"
          },
          {
            "url" : "responseType",
            "valueString" : "TIFlowOperationOutcome"
          },
          {
            "url" : "errorCode",
            "valueString" : "MSG_UNKNOWN_TYPE"
          }],
          "url" : "https://gematik.de/fhir/ti/StructureDefinition/extension-http-response-info"
        }],
        "code" : "search-type"
      },
      {
        "extension" : [{
          "url" : "http://hl7.org/fhir/StructureDefinition/capabilitystatement-expectation",
          "valueCode" : "SHALL"
        },
        {
          "extension" : [{
            "url" : "statusCode",
            "valueString" : "400"
          },
          {
            "url" : "description",
            "valueString" : "Invalid request"
          },
          {
            "url" : "responseType",
            "valueString" : "TIFlowOperationOutcome"
          },
          {
            "url" : "errorCode",
            "valueString" : "MSG_BAD_FORMAT"
          }],
          "url" : "https://gematik.de/fhir/ti/StructureDefinition/extension-http-response-info"
        },
        {
          "extension" : [{
            "url" : "statusCode",
            "valueString" : "408"
          },
          {
            "url" : "description",
            "valueString" : "Timeout"
          },
          {
            "url" : "responseType",
            "valueString" : "TIFlowOperationOutcome"
          },
          {
            "url" : "errorCode",
            "valueString" : "TIFLOW_TIMEOUT"
          }],
          "url" : "https://gematik.de/fhir/ti/StructureDefinition/extension-http-response-info"
        },
        {
          "extension" : [{
            "url" : "statusCode",
            "valueString" : "500"
          },
          {
            "url" : "description",
            "valueString" : "Internal Server Error"
          },
          {
            "url" : "responseType",
            "valueString" : "TIFlowOperationOutcome"
          },
          {
            "url" : "errorCode",
            "valueString" : "TIFLOW_INTERNAL_ERROR"
          }],
          "url" : "https://gematik.de/fhir/ti/StructureDefinition/extension-http-response-info"
        },
        {
          "extension" : [{
            "url" : "statusCode",
            "valueString" : "200"
          },
          {
            "url" : "description",
            "valueString" : "Successful operation"
          }],
          "url" : "https://gematik.de/fhir/ti/StructureDefinition/extension-http-response-info"
        },
        {
          "extension" : [{
            "url" : "statusCode",
            "valueString" : "404"
          },
          {
            "url" : "description",
            "valueString" : "Unknown resource type"
          },
          {
            "url" : "responseType",
            "valueString" : "TIFlowOperationOutcome"
          },
          {
            "url" : "errorCode",
            "valueString" : "MSG_UNKNOWN_TYPE"
          }],
          "url" : "https://gematik.de/fhir/ti/StructureDefinition/extension-http-response-info"
        },
        {
          "extension" : [{
            "url" : "statusCode",
            "valueString" : "404"
          },
          {
            "url" : "description",
            "valueString" : "Resource is not known"
          },
          {
            "url" : "responseType",
            "valueString" : "TIFlowOperationOutcome"
          },
          {
            "url" : "errorCode",
            "valueString" : "MSG_RESOURCE_ID_FAIL"
          }],
          "url" : "https://gematik.de/fhir/ti/StructureDefinition/extension-http-response-info"
        },
        {
          "extension" : [{
            "url" : "statusCode",
            "valueString" : "410"
          },
          {
            "url" : "description",
            "valueString" : "Resource was deleted"
          },
          {
            "url" : "responseType",
            "valueString" : "TIFlowOperationOutcome"
          },
          {
            "url" : "errorCode",
            "valueString" : "MSG_DELETED"
          }],
          "url" : "https://gematik.de/fhir/ti/StructureDefinition/extension-http-response-info"
        }],
        "code" : "read"
      },
      {
        "extension" : [{
          "url" : "http://hl7.org/fhir/StructureDefinition/capabilitystatement-expectation",
          "valueCode" : "SHALL"
        }],
        "code" : "patch"
      }],
      "versioning" : "versioned-update",
      "readHistory" : true,
      "searchParam" : [{
        "extension" : [{
          "url" : "http://hl7.org/fhir/StructureDefinition/capabilitystatement-expectation",
          "valueCode" : "SHALL"
        }],
        "name" : "_id",
        "definition" : "http://hl7.org/fhir/SearchParameter/Resource-id",
        "type" : "token",
        "documentation" : "Task.id - Unterstützt die Suche nach der Task-ID"
      },
      {
        "extension" : [{
          "url" : "http://hl7.org/fhir/StructureDefinition/capabilitystatement-expectation",
          "valueCode" : "SHALL"
        }],
        "name" : "prescription-id",
        "type" : "token",
        "documentation" : "Task.identifier - Unterstützt die Suche nach der E-Rezept-ID"
      },
      {
        "extension" : [{
          "url" : "http://hl7.org/fhir/StructureDefinition/capabilitystatement-expectation",
          "valueCode" : "SHALL"
        }],
        "name" : "access-code",
        "type" : "token",
        "documentation" : "Task.identifier - Unterstützt die Suche nach dem Zugriffscode"
      },
      {
        "extension" : [{
          "url" : "http://hl7.org/fhir/StructureDefinition/capabilitystatement-expectation",
          "valueCode" : "SHALL"
        }],
        "name" : "authored-on",
        "definition" : "http://hl7.org/fhir/SearchParameter/Task-authored-on",
        "type" : "date",
        "documentation" : "Task.authoredOn - Unterstützt die Suche nach dem Erstellungsdatum; default sort if _sort is not provided"
      },
      {
        "extension" : [{
          "url" : "http://hl7.org/fhir/StructureDefinition/capabilitystatement-expectation",
          "valueCode" : "SHALL"
        }],
        "name" : "status",
        "definition" : "http://hl7.org/fhir/SearchParameter/Task-status",
        "type" : "token",
        "documentation" : "Task.status - Unterstützt die Suche nach dem Status einer Task"
      },
      {
        "extension" : [{
          "url" : "http://hl7.org/fhir/StructureDefinition/capabilitystatement-expectation",
          "valueCode" : "SHALL"
        }],
        "name" : "expiry-date",
        "type" : "date",
        "documentation" : "Task.extension:expiryDate.valueDate - Unterstützt die Suche nach dem Verfallsdatum"
      },
      {
        "extension" : [{
          "url" : "http://hl7.org/fhir/StructureDefinition/capabilitystatement-expectation",
          "valueCode" : "SHALL"
        }],
        "name" : "accept-date",
        "type" : "date",
        "documentation" : "Task.extension:acceptDate.valueDate - Unterstützt die Suche nach dem Akzeptanzdatum"
      },
      {
        "extension" : [{
          "url" : "http://hl7.org/fhir/StructureDefinition/capabilitystatement-expectation",
          "valueCode" : "SHALL"
        }],
        "name" : "modified",
        "definition" : "http://hl7.org/fhir/SearchParameter/Task-modified",
        "type" : "date",
        "documentation" : "Task.lastModified - Unterstützt die Suche nach dem zuletzt modifizierten Datum"
      },
      {
        "extension" : [{
          "url" : "http://hl7.org/fhir/StructureDefinition/capabilitystatement-expectation",
          "valueCode" : "SHALL"
        }],
        "name" : "_sort",
        "type" : "string",
        "documentation" : "Unterstützt das Sortieren nach unterstützten Task-Suchkriterien"
      },
      {
        "extension" : [{
          "url" : "http://hl7.org/fhir/StructureDefinition/capabilitystatement-expectation",
          "valueCode" : "SHALL"
        }],
        "name" : "_count",
        "type" : "number",
        "documentation" : "Maximale Anzahl zurückgegebener Einträge pro Seite; maximum value is 50"
      },
      {
        "extension" : [{
          "url" : "http://hl7.org/fhir/StructureDefinition/capabilitystatement-expectation",
          "valueCode" : "SHALL"
        }],
        "name" : "_offset",
        "type" : "number",
        "documentation" : "Nullbasierter Offset des ersten zurückgegebenen Eintrags; default is 0"
      }],
      "operation" : [{
        "extension" : [{
          "url" : "http://hl7.org/fhir/StructureDefinition/capabilitystatement-expectation",
          "valueCode" : "SHALL"
        },
        {
          "extension" : [{
            "url" : "statusCode",
            "valueString" : "201"
          },
          {
            "url" : "description",
            "valueString" : "Resource created"
          }],
          "url" : "https://gematik.de/fhir/ti/StructureDefinition/extension-http-response-info"
        },
        {
          "extension" : [{
            "url" : "statusCode",
            "valueString" : "400"
          },
          {
            "url" : "description",
            "valueString" : "FHIR Profile Validation Failed"
          },
          {
            "url" : "responseType",
            "valueString" : "TIFlowOperationOutcome"
          },
          {
            "url" : "errorCode",
            "valueString" : "SVC_VALIDATION_FAILED"
          }],
          "url" : "https://gematik.de/fhir/ti/StructureDefinition/extension-http-response-info"
        },
        {
          "extension" : [{
            "url" : "statusCode",
            "valueString" : "403"
          },
          {
            "url" : "description",
            "valueString" : "Access role not allowed"
          },
          {
            "url" : "responseType",
            "valueString" : "TIFlowOperationOutcome"
          },
          {
            "url" : "errorCode",
            "valueString" : "TIFLOW_AUTH_ROLE_NOT_ALLOWED"
          }],
          "url" : "https://gematik.de/fhir/ti/StructureDefinition/extension-http-response-info"
        },
        {
          "extension" : [{
            "url" : "statusCode",
            "valueString" : "404"
          },
          {
            "url" : "description",
            "valueString" : "Resource is not known"
          },
          {
            "url" : "responseType",
            "valueString" : "TIFlowOperationOutcome"
          },
          {
            "url" : "errorCode",
            "valueString" : "MSG_RESOURCE_ID_FAIL"
          }],
          "url" : "https://gematik.de/fhir/ti/StructureDefinition/extension-http-response-info"
        },
        {
          "extension" : [{
            "url" : "statusCode",
            "valueString" : "410"
          },
          {
            "url" : "description",
            "valueString" : "Resource was deleted"
          },
          {
            "url" : "responseType",
            "valueString" : "TIFlowOperationOutcome"
          },
          {
            "url" : "errorCode",
            "valueString" : "MSG_DELETED"
          }],
          "url" : "https://gematik.de/fhir/ti/StructureDefinition/extension-http-response-info"
        },
        {
          "extension" : [{
            "url" : "statusCode",
            "valueString" : "400"
          },
          {
            "url" : "description",
            "valueString" : "Invalid request"
          },
          {
            "url" : "responseType",
            "valueString" : "TIFlowOperationOutcome"
          },
          {
            "url" : "errorCode",
            "valueString" : "MSG_BAD_FORMAT"
          }],
          "url" : "https://gematik.de/fhir/ti/StructureDefinition/extension-http-response-info"
        },
        {
          "extension" : [{
            "url" : "statusCode",
            "valueString" : "500"
          },
          {
            "url" : "description",
            "valueString" : "Internal Server Error"
          },
          {
            "url" : "responseType",
            "valueString" : "TIFlowOperationOutcome"
          },
          {
            "url" : "errorCode",
            "valueString" : "TIFLOW_INTERNAL_ERROR"
          }],
          "url" : "https://gematik.de/fhir/ti/StructureDefinition/extension-http-response-info"
        },
        {
          "extension" : [{
            "url" : "statusCode",
            "valueString" : "408"
          },
          {
            "url" : "description",
            "valueString" : "Timeout"
          },
          {
            "url" : "responseType",
            "valueString" : "TIFlowOperationOutcome"
          },
          {
            "url" : "errorCode",
            "valueString" : "TIFLOW_TIMEOUT"
          }],
          "url" : "https://gematik.de/fhir/ti/StructureDefinition/extension-http-response-info"
        }],
        "name" : "create",
        "definition" : "https://gematik.de/fhir/tiflow-erezept/OperationDefinition/tiflow-rx-create-op",
        "documentation" : "Creates a Task for a specific flow type"
      },
      {
        "extension" : [{
          "url" : "http://hl7.org/fhir/StructureDefinition/capabilitystatement-expectation",
          "valueCode" : "SHALL"
        },
        {
          "extension" : [{
            "url" : "statusCode",
            "valueString" : "200"
          },
          {
            "url" : "description",
            "valueString" : "Successful operation"
          }],
          "url" : "https://gematik.de/fhir/ti/StructureDefinition/extension-http-response-info"
        },
        {
          "extension" : [{
            "url" : "statusCode",
            "valueString" : "400"
          },
          {
            "url" : "description",
            "valueString" : "FHIR Profile Validation Failed"
          },
          {
            "url" : "responseType",
            "valueString" : "TIFlowOperationOutcome"
          },
          {
            "url" : "errorCode",
            "valueString" : "SVC_VALIDATION_FAILED"
          }],
          "url" : "https://gematik.de/fhir/ti/StructureDefinition/extension-http-response-info"
        },
        {
          "extension" : [{
            "url" : "statusCode",
            "valueString" : "403"
          },
          {
            "url" : "description",
            "valueString" : "Access code mismatch"
          },
          {
            "url" : "responseType",
            "valueString" : "TIFlowOperationOutcome"
          },
          {
            "url" : "errorCode",
            "valueString" : "TIFLOW_ACCESSCODE_MISMATCH"
          }],
          "url" : "https://gematik.de/fhir/ti/StructureDefinition/extension-http-response-info"
        },
        {
          "extension" : [{
            "url" : "statusCode",
            "valueString" : "403"
          },
          {
            "url" : "description",
            "valueString" : "Access role not allowed"
          },
          {
            "url" : "responseType",
            "valueString" : "TIFlowOperationOutcome"
          },
          {
            "url" : "errorCode",
            "valueString" : "TIFLOW_AUTH_ROLE_NOT_ALLOWED"
          }],
          "url" : "https://gematik.de/fhir/ti/StructureDefinition/extension-http-response-info"
        },
        {
          "extension" : [{
            "url" : "statusCode",
            "valueString" : "400"
          },
          {
            "url" : "description",
            "valueString" : "Coverage type mismatch"
          },
          {
            "url" : "responseType",
            "valueString" : "TIFlowOperationOutcome"
          },
          {
            "url" : "errorCode",
            "valueString" : "TIFLOW_COVERAGE_TYPE_MISMATCH"
          }],
          "url" : "https://gematik.de/fhir/ti/StructureDefinition/extension-http-response-info"
        },
        {
          "extension" : [{
            "url" : "statusCode",
            "valueString" : "400"
          },
          {
            "url" : "description",
            "valueString" : "Flow type mismatch"
          },
          {
            "url" : "responseType",
            "valueString" : "TIFlowOperationOutcome"
          },
          {
            "url" : "errorCode",
            "valueString" : "TIFLOW_FLOWTYPE_MISMATCH"
          }],
          "url" : "https://gematik.de/fhir/ti/StructureDefinition/extension-http-response-info"
        },
        {
          "extension" : [{
            "url" : "statusCode",
            "valueString" : "400"
          },
          {
            "url" : "description",
            "valueString" : "IKNR invalid"
          },
          {
            "url" : "responseType",
            "valueString" : "TIFlowOperationOutcome"
          },
          {
            "url" : "errorCode",
            "valueString" : "TIFLOW_IKNR_INVALID"
          }],
          "url" : "https://gematik.de/fhir/ti/StructureDefinition/extension-http-response-info"
        },
        {
          "extension" : [{
            "url" : "statusCode",
            "valueString" : "400"
          },
          {
            "url" : "description",
            "valueString" : "KVNR invalid"
          },
          {
            "url" : "responseType",
            "valueString" : "TIFlowOperationOutcome"
          },
          {
            "url" : "errorCode",
            "valueString" : "TIFLOW_KVNR_INVALID"
          }],
          "url" : "https://gematik.de/fhir/ti/StructureDefinition/extension-http-response-info"
        },
        {
          "extension" : [{
            "url" : "statusCode",
            "valueString" : "400"
          },
          {
            "url" : "description",
            "valueString" : "LANR or ZANR invalid"
          },
          {
            "url" : "responseType",
            "valueString" : "TIFlowOperationOutcome"
          },
          {
            "url" : "errorCode",
            "valueString" : "TIFLOW_LANR_ZANR_INVALID"
          }],
          "url" : "https://gematik.de/fhir/ti/StructureDefinition/extension-http-response-info"
        },
        {
          "extension" : [{
            "url" : "statusCode",
            "valueString" : "400"
          },
          {
            "url" : "description",
            "valueString" : "Signature authoredOn mismatch"
          },
          {
            "url" : "responseType",
            "valueString" : "TIFlowOperationOutcome"
          },
          {
            "url" : "errorCode",
            "valueString" : "TIFLOW_SIGNATURE_AUTHOREDON_MISMATCH"
          }],
          "url" : "https://gematik.de/fhir/ti/StructureDefinition/extension-http-response-info"
        },
        {
          "extension" : [{
            "url" : "statusCode",
            "valueString" : "400"
          },
          {
            "url" : "description",
            "valueString" : "Signature invalid"
          },
          {
            "url" : "responseType",
            "valueString" : "TIFlowOperationOutcome"
          },
          {
            "url" : "errorCode",
            "valueString" : "TIFLOW_SIGNATURE_INVALID"
          }],
          "url" : "https://gematik.de/fhir/ti/StructureDefinition/extension-http-response-info"
        },
        {
          "extension" : [{
            "url" : "statusCode",
            "valueString" : "400"
          },
          {
            "url" : "description",
            "valueString" : "Signature issuing role invalid"
          },
          {
            "url" : "responseType",
            "valueString" : "TIFlowOperationOutcome"
          },
          {
            "url" : "errorCode",
            "valueString" : "TIFLOW_SIGNATURE_INVALID_ISSUING_ROLE"
          }],
          "url" : "https://gematik.de/fhir/ti/StructureDefinition/extension-http-response-info"
        },
        {
          "extension" : [{
            "url" : "statusCode",
            "valueString" : "400"
          },
          {
            "url" : "description",
            "valueString" : "Task status mismatch"
          },
          {
            "url" : "responseType",
            "valueString" : "TIFlowOperationOutcome"
          },
          {
            "url" : "errorCode",
            "valueString" : "TIFLOW_TASK_STATUS_MISMATCH"
          }],
          "url" : "https://gematik.de/fhir/ti/StructureDefinition/extension-http-response-info"
        },
        {
          "extension" : [{
            "url" : "statusCode",
            "valueString" : "400"
          },
          {
            "url" : "description",
            "valueString" : "Certificate invalid"
          },
          {
            "url" : "responseType",
            "valueString" : "TIFlowOperationOutcome"
          },
          {
            "url" : "errorCode",
            "valueString" : "TIFLOW_CERTIFICATE_INVALID"
          }],
          "url" : "https://gematik.de/fhir/ti/StructureDefinition/extension-http-response-info"
        },
        {
          "extension" : [{
            "url" : "statusCode",
            "valueString" : "400"
          },
          {
            "url" : "description",
            "valueString" : "Drug category forbidden"
          },
          {
            "url" : "responseType",
            "valueString" : "TIFlowOperationOutcome"
          },
          {
            "url" : "errorCode",
            "valueString" : "TIFLOW_EREZEPT_DRUG_CATEGORY_FORBIDDEN"
          }],
          "url" : "https://gematik.de/fhir/ti/StructureDefinition/extension-http-response-info"
        },
        {
          "extension" : [{
            "url" : "statusCode",
            "valueString" : "400"
          },
          {
            "url" : "description",
            "valueString" : "MVO end date invalid"
          },
          {
            "url" : "responseType",
            "valueString" : "TIFlowOperationOutcome"
          },
          {
            "url" : "errorCode",
            "valueString" : "TIFLOW_EREZEPT_MVO_ENDDATE_INVALID"
          }],
          "url" : "https://gematik.de/fhir/ti/StructureDefinition/extension-http-response-info"
        },
        {
          "extension" : [{
            "url" : "statusCode",
            "valueString" : "400"
          },
          {
            "url" : "description",
            "valueString" : "MVO flow type invalid"
          },
          {
            "url" : "responseType",
            "valueString" : "TIFlowOperationOutcome"
          },
          {
            "url" : "errorCode",
            "valueString" : "TIFLOW_EREZEPT_MVO_FLOWTYPE_INVALID"
          }],
          "url" : "https://gematik.de/fhir/ti/StructureDefinition/extension-http-response-info"
        },
        {
          "extension" : [{
            "url" : "statusCode",
            "valueString" : "400"
          },
          {
            "url" : "description",
            "valueString" : "MVO id invalid"
          },
          {
            "url" : "responseType",
            "valueString" : "TIFlowOperationOutcome"
          },
          {
            "url" : "errorCode",
            "valueString" : "TIFLOW_EREZEPT_MVO_ID_INVALID"
          }],
          "url" : "https://gematik.de/fhir/ti/StructureDefinition/extension-http-response-info"
        },
        {
          "extension" : [{
            "url" : "statusCode",
            "valueString" : "400"
          },
          {
            "url" : "description",
            "valueString" : "MVO invalid"
          },
          {
            "url" : "responseType",
            "valueString" : "TIFlowOperationOutcome"
          },
          {
            "url" : "errorCode",
            "valueString" : "TIFLOW_EREZEPT_MVO_INVALID"
          }],
          "url" : "https://gematik.de/fhir/ti/StructureDefinition/extension-http-response-info"
        },
        {
          "extension" : [{
            "url" : "statusCode",
            "valueString" : "400"
          },
          {
            "url" : "description",
            "valueString" : "MVO start date invalid"
          },
          {
            "url" : "responseType",
            "valueString" : "TIFlowOperationOutcome"
          },
          {
            "url" : "errorCode",
            "valueString" : "TIFLOW_EREZEPT_MVO_STARTDATE_INVALID"
          }],
          "url" : "https://gematik.de/fhir/ti/StructureDefinition/extension-http-response-info"
        },
        {
          "extension" : [{
            "url" : "statusCode",
            "valueString" : "400"
          },
          {
            "url" : "description",
            "valueString" : "PZN invalid"
          },
          {
            "url" : "responseType",
            "valueString" : "TIFlowOperationOutcome"
          },
          {
            "url" : "errorCode",
            "valueString" : "TIFLOW_EREZEPT_PZN_INVALID"
          }],
          "url" : "https://gematik.de/fhir/ti/StructureDefinition/extension-http-response-info"
        },
        {
          "extension" : [{
            "url" : "statusCode",
            "valueString" : "512"
          },
          {
            "url" : "description",
            "valueString" : "Invalid OCSP response"
          },
          {
            "url" : "responseType",
            "valueString" : "TIFlowOperationOutcome"
          },
          {
            "url" : "errorCode",
            "valueString" : "TIFLOW_OCSP_BACKEND_ERROR"
          }],
          "url" : "https://gematik.de/fhir/ti/StructureDefinition/extension-http-response-info"
        },
        {
          "extension" : [{
            "url" : "statusCode",
            "valueString" : "404"
          },
          {
            "url" : "description",
            "valueString" : "Resource is not known"
          },
          {
            "url" : "responseType",
            "valueString" : "TIFlowOperationOutcome"
          },
          {
            "url" : "errorCode",
            "valueString" : "MSG_RESOURCE_ID_FAIL"
          }],
          "url" : "https://gematik.de/fhir/ti/StructureDefinition/extension-http-response-info"
        },
        {
          "extension" : [{
            "url" : "statusCode",
            "valueString" : "410"
          },
          {
            "url" : "description",
            "valueString" : "Resource was deleted"
          },
          {
            "url" : "responseType",
            "valueString" : "TIFlowOperationOutcome"
          },
          {
            "url" : "errorCode",
            "valueString" : "MSG_DELETED"
          }],
          "url" : "https://gematik.de/fhir/ti/StructureDefinition/extension-http-response-info"
        },
        {
          "extension" : [{
            "url" : "statusCode",
            "valueString" : "400"
          },
          {
            "url" : "description",
            "valueString" : "Invalid request"
          },
          {
            "url" : "responseType",
            "valueString" : "TIFlowOperationOutcome"
          },
          {
            "url" : "errorCode",
            "valueString" : "MSG_BAD_FORMAT"
          }],
          "url" : "https://gematik.de/fhir/ti/StructureDefinition/extension-http-response-info"
        },
        {
          "extension" : [{
            "url" : "statusCode",
            "valueString" : "500"
          },
          {
            "url" : "description",
            "valueString" : "Internal Server Error"
          },
          {
            "url" : "responseType",
            "valueString" : "TIFlowOperationOutcome"
          },
          {
            "url" : "errorCode",
            "valueString" : "TIFLOW_INTERNAL_ERROR"
          }],
          "url" : "https://gematik.de/fhir/ti/StructureDefinition/extension-http-response-info"
        },
        {
          "extension" : [{
            "url" : "statusCode",
            "valueString" : "408"
          },
          {
            "url" : "description",
            "valueString" : "Timeout"
          },
          {
            "url" : "responseType",
            "valueString" : "TIFlowOperationOutcome"
          },
          {
            "url" : "errorCode",
            "valueString" : "TIFLOW_TIMEOUT"
          }],
          "url" : "https://gematik.de/fhir/ti/StructureDefinition/extension-http-response-info"
        }],
        "name" : "activate",
        "definition" : "https://gematik.de/fhir/tiflow-erezept/OperationDefinition/tiflow-rx-activate-op",
        "documentation" : "Activates the created Task using the signed ePrescription bundle"
      },
      {
        "extension" : [{
          "url" : "http://hl7.org/fhir/StructureDefinition/capabilitystatement-expectation",
          "valueCode" : "SHALL"
        },
        {
          "extension" : [{
            "url" : "statusCode",
            "valueString" : "200"
          },
          {
            "url" : "description",
            "valueString" : "Successful operation"
          }],
          "url" : "https://gematik.de/fhir/ti/StructureDefinition/extension-http-response-info"
        },
        {
          "extension" : [{
            "url" : "statusCode",
            "valueString" : "403"
          },
          {
            "url" : "description",
            "valueString" : "Access code mismatch"
          },
          {
            "url" : "responseType",
            "valueString" : "TIFlowOperationOutcome"
          },
          {
            "url" : "errorCode",
            "valueString" : "TIFLOW_ACCESSCODE_MISMATCH"
          }],
          "url" : "https://gematik.de/fhir/ti/StructureDefinition/extension-http-response-info"
        },
        {
          "extension" : [{
            "url" : "statusCode",
            "valueString" : "403"
          },
          {
            "url" : "description",
            "valueString" : "Access role not allowed"
          },
          {
            "url" : "responseType",
            "valueString" : "TIFlowOperationOutcome"
          },
          {
            "url" : "errorCode",
            "valueString" : "TIFLOW_AUTH_ROLE_NOT_ALLOWED"
          }],
          "url" : "https://gematik.de/fhir/ti/StructureDefinition/extension-http-response-info"
        },
        {
          "extension" : [{
            "url" : "statusCode",
            "valueString" : "410"
          },
          {
            "url" : "description",
            "valueString" : "Task deleted"
          },
          {
            "url" : "responseType",
            "valueString" : "TIFlowOperationOutcome"
          },
          {
            "url" : "errorCode",
            "valueString" : "TIFLOW_TASK_DELETED"
          }],
          "url" : "https://gematik.de/fhir/ti/StructureDefinition/extension-http-response-info"
        },
        {
          "extension" : [{
            "url" : "statusCode",
            "valueString" : "400"
          },
          {
            "url" : "description",
            "valueString" : "Task expired"
          },
          {
            "url" : "responseType",
            "valueString" : "TIFlowOperationOutcome"
          },
          {
            "url" : "errorCode",
            "valueString" : "TIFLOW_TASK_EXPIRED"
          }],
          "url" : "https://gematik.de/fhir/ti/StructureDefinition/extension-http-response-info"
        },
        {
          "extension" : [{
            "url" : "statusCode",
            "valueString" : "400"
          },
          {
            "url" : "description",
            "valueString" : "Task status mismatch"
          },
          {
            "url" : "responseType",
            "valueString" : "TIFlowOperationOutcome"
          },
          {
            "url" : "errorCode",
            "valueString" : "TIFLOW_TASK_STATUS_MISMATCH"
          }],
          "url" : "https://gematik.de/fhir/ti/StructureDefinition/extension-http-response-info"
        },
        {
          "extension" : [{
            "url" : "statusCode",
            "valueString" : "403"
          },
          {
            "url" : "description",
            "valueString" : "MVO not valid yet"
          },
          {
            "url" : "responseType",
            "valueString" : "TIFlowOperationOutcome"
          },
          {
            "url" : "errorCode",
            "valueString" : "TIFLOW_EREZEPT_MVO_NOT_VALID"
          }],
          "url" : "https://gematik.de/fhir/ti/StructureDefinition/extension-http-response-info"
        },
        {
          "extension" : [{
            "url" : "statusCode",
            "valueString" : "404"
          },
          {
            "url" : "description",
            "valueString" : "Resource is not known"
          },
          {
            "url" : "responseType",
            "valueString" : "TIFlowOperationOutcome"
          },
          {
            "url" : "errorCode",
            "valueString" : "MSG_RESOURCE_ID_FAIL"
          }],
          "url" : "https://gematik.de/fhir/ti/StructureDefinition/extension-http-response-info"
        },
        {
          "extension" : [{
            "url" : "statusCode",
            "valueString" : "410"
          },
          {
            "url" : "description",
            "valueString" : "Resource was deleted"
          },
          {
            "url" : "responseType",
            "valueString" : "TIFlowOperationOutcome"
          },
          {
            "url" : "errorCode",
            "valueString" : "MSG_DELETED"
          }],
          "url" : "https://gematik.de/fhir/ti/StructureDefinition/extension-http-response-info"
        },
        {
          "extension" : [{
            "url" : "statusCode",
            "valueString" : "400"
          },
          {
            "url" : "description",
            "valueString" : "Invalid request"
          },
          {
            "url" : "responseType",
            "valueString" : "TIFlowOperationOutcome"
          },
          {
            "url" : "errorCode",
            "valueString" : "MSG_BAD_FORMAT"
          }],
          "url" : "https://gematik.de/fhir/ti/StructureDefinition/extension-http-response-info"
        },
        {
          "extension" : [{
            "url" : "statusCode",
            "valueString" : "500"
          },
          {
            "url" : "description",
            "valueString" : "Internal Server Error"
          },
          {
            "url" : "responseType",
            "valueString" : "TIFlowOperationOutcome"
          },
          {
            "url" : "errorCode",
            "valueString" : "TIFLOW_INTERNAL_ERROR"
          }],
          "url" : "https://gematik.de/fhir/ti/StructureDefinition/extension-http-response-info"
        },
        {
          "extension" : [{
            "url" : "statusCode",
            "valueString" : "408"
          },
          {
            "url" : "description",
            "valueString" : "Timeout"
          },
          {
            "url" : "responseType",
            "valueString" : "TIFlowOperationOutcome"
          },
          {
            "url" : "errorCode",
            "valueString" : "TIFLOW_TIMEOUT"
          }],
          "url" : "https://gematik.de/fhir/ti/StructureDefinition/extension-http-response-info"
        }],
        "name" : "accept",
        "definition" : "https://gematik.de/fhir/tiflow-erezept/OperationDefinition/tiflow-rx-accept-op",
        "documentation" : "Pharmacy claims an ePrescription and sets Task status to in-progress"
      },
      {
        "extension" : [{
          "url" : "http://hl7.org/fhir/StructureDefinition/capabilitystatement-expectation",
          "valueCode" : "SHALL"
        },
        {
          "extension" : [{
            "url" : "statusCode",
            "valueString" : "204"
          },
          {
            "url" : "description",
            "valueString" : "Successful operation without response body"
          }],
          "url" : "https://gematik.de/fhir/ti/StructureDefinition/extension-http-response-info"
        },
        {
          "extension" : [{
            "url" : "statusCode",
            "valueString" : "403"
          },
          {
            "url" : "description",
            "valueString" : "Task secret mismatch"
          },
          {
            "url" : "responseType",
            "valueString" : "TIFlowOperationOutcome"
          },
          {
            "url" : "errorCode",
            "valueString" : "TIFLOW_SECRET_MISMATCH"
          }],
          "url" : "https://gematik.de/fhir/ti/StructureDefinition/extension-http-response-info"
        },
        {
          "extension" : [{
            "url" : "statusCode",
            "valueString" : "403"
          },
          {
            "url" : "description",
            "valueString" : "Access role not allowed"
          },
          {
            "url" : "responseType",
            "valueString" : "TIFlowOperationOutcome"
          },
          {
            "url" : "errorCode",
            "valueString" : "TIFLOW_AUTH_ROLE_NOT_ALLOWED"
          }],
          "url" : "https://gematik.de/fhir/ti/StructureDefinition/extension-http-response-info"
        },
        {
          "extension" : [{
            "url" : "statusCode",
            "valueString" : "400"
          },
          {
            "url" : "description",
            "valueString" : "Task status mismatch"
          },
          {
            "url" : "responseType",
            "valueString" : "TIFlowOperationOutcome"
          },
          {
            "url" : "errorCode",
            "valueString" : "TIFLOW_TASK_STATUS_MISMATCH"
          }],
          "url" : "https://gematik.de/fhir/ti/StructureDefinition/extension-http-response-info"
        },
        {
          "extension" : [{
            "url" : "statusCode",
            "valueString" : "404"
          },
          {
            "url" : "description",
            "valueString" : "Resource is not known"
          },
          {
            "url" : "responseType",
            "valueString" : "TIFlowOperationOutcome"
          },
          {
            "url" : "errorCode",
            "valueString" : "MSG_RESOURCE_ID_FAIL"
          }],
          "url" : "https://gematik.de/fhir/ti/StructureDefinition/extension-http-response-info"
        },
        {
          "extension" : [{
            "url" : "statusCode",
            "valueString" : "410"
          },
          {
            "url" : "description",
            "valueString" : "Resource was deleted"
          },
          {
            "url" : "responseType",
            "valueString" : "TIFlowOperationOutcome"
          },
          {
            "url" : "errorCode",
            "valueString" : "MSG_DELETED"
          }],
          "url" : "https://gematik.de/fhir/ti/StructureDefinition/extension-http-response-info"
        },
        {
          "extension" : [{
            "url" : "statusCode",
            "valueString" : "400"
          },
          {
            "url" : "description",
            "valueString" : "Invalid request"
          },
          {
            "url" : "responseType",
            "valueString" : "TIFlowOperationOutcome"
          },
          {
            "url" : "errorCode",
            "valueString" : "MSG_BAD_FORMAT"
          }],
          "url" : "https://gematik.de/fhir/ti/StructureDefinition/extension-http-response-info"
        },
        {
          "extension" : [{
            "url" : "statusCode",
            "valueString" : "500"
          },
          {
            "url" : "description",
            "valueString" : "Internal Server Error"
          },
          {
            "url" : "responseType",
            "valueString" : "TIFlowOperationOutcome"
          },
          {
            "url" : "errorCode",
            "valueString" : "TIFLOW_INTERNAL_ERROR"
          }],
          "url" : "https://gematik.de/fhir/ti/StructureDefinition/extension-http-response-info"
        },
        {
          "extension" : [{
            "url" : "statusCode",
            "valueString" : "408"
          },
          {
            "url" : "description",
            "valueString" : "Timeout"
          },
          {
            "url" : "responseType",
            "valueString" : "TIFlowOperationOutcome"
          },
          {
            "url" : "errorCode",
            "valueString" : "TIFLOW_TIMEOUT"
          }],
          "url" : "https://gematik.de/fhir/ti/StructureDefinition/extension-http-response-info"
        }],
        "name" : "reject",
        "definition" : "https://gematik.de/fhir/tiflow-erezept/OperationDefinition/tiflow-rx-reject-op",
        "documentation" : "Rejects dispensing and resets Task status to active"
      },
      {
        "extension" : [{
          "url" : "http://hl7.org/fhir/StructureDefinition/capabilitystatement-expectation",
          "valueCode" : "SHALL"
        },
        {
          "extension" : [{
            "url" : "statusCode",
            "valueString" : "200"
          },
          {
            "url" : "description",
            "valueString" : "Successful operation"
          }],
          "url" : "https://gematik.de/fhir/ti/StructureDefinition/extension-http-response-info"
        },
        {
          "extension" : [{
            "url" : "statusCode",
            "valueString" : "400"
          },
          {
            "url" : "description",
            "valueString" : "FHIR Profile Validation Failed"
          },
          {
            "url" : "responseType",
            "valueString" : "TIFlowOperationOutcome"
          },
          {
            "url" : "errorCode",
            "valueString" : "SVC_VALIDATION_FAILED"
          }],
          "url" : "https://gematik.de/fhir/ti/StructureDefinition/extension-http-response-info"
        },
        {
          "extension" : [{
            "url" : "statusCode",
            "valueString" : "403"
          },
          {
            "url" : "description",
            "valueString" : "MedicationDispense missing"
          },
          {
            "url" : "responseType",
            "valueString" : "TIFlowOperationOutcome"
          },
          {
            "url" : "errorCode",
            "valueString" : "TIFLOW_MEDICATION_DISPENSE_MISSING"
          }],
          "url" : "https://gematik.de/fhir/ti/StructureDefinition/extension-http-response-info"
        },
        {
          "extension" : [{
            "url" : "statusCode",
            "valueString" : "403"
          },
          {
            "url" : "description",
            "valueString" : "Task secret mismatch"
          },
          {
            "url" : "responseType",
            "valueString" : "TIFlowOperationOutcome"
          },
          {
            "url" : "errorCode",
            "valueString" : "TIFLOW_SECRET_MISMATCH"
          }],
          "url" : "https://gematik.de/fhir/ti/StructureDefinition/extension-http-response-info"
        },
        {
          "extension" : [{
            "url" : "statusCode",
            "valueString" : "503"
          },
          {
            "url" : "description",
            "valueString" : "No OCSP response for signature"
          },
          {
            "url" : "responseType",
            "valueString" : "TIFlowOperationOutcome"
          },
          {
            "url" : "errorCode",
            "valueString" : "TIFLOW_SIGNATURE_NO_OCSP_RESPONSE"
          }],
          "url" : "https://gematik.de/fhir/ti/StructureDefinition/extension-http-response-info"
        },
        {
          "extension" : [{
            "url" : "statusCode",
            "valueString" : "400"
          },
          {
            "url" : "description",
            "valueString" : "MedicationDispense invalid"
          },
          {
            "url" : "responseType",
            "valueString" : "TIFlowOperationOutcome"
          },
          {
            "url" : "errorCode",
            "valueString" : "TIFLOW_MEDICATION_DISPENSE_INVALID"
          }],
          "url" : "https://gematik.de/fhir/ti/StructureDefinition/extension-http-response-info"
        },
        {
          "extension" : [{
            "url" : "statusCode",
            "valueString" : "400"
          },
          {
            "url" : "description",
            "valueString" : "Task status mismatch"
          },
          {
            "url" : "responseType",
            "valueString" : "TIFlowOperationOutcome"
          },
          {
            "url" : "errorCode",
            "valueString" : "TIFLOW_TASK_STATUS_MISMATCH"
          }],
          "url" : "https://gematik.de/fhir/ti/StructureDefinition/extension-http-response-info"
        },
        {
          "extension" : [{
            "url" : "statusCode",
            "valueString" : "403"
          },
          {
            "url" : "description",
            "valueString" : "Access role not allowed"
          },
          {
            "url" : "responseType",
            "valueString" : "TIFlowOperationOutcome"
          },
          {
            "url" : "errorCode",
            "valueString" : "TIFLOW_AUTH_ROLE_NOT_ALLOWED"
          }],
          "url" : "https://gematik.de/fhir/ti/StructureDefinition/extension-http-response-info"
        },
        {
          "extension" : [{
            "url" : "statusCode",
            "valueString" : "404"
          },
          {
            "url" : "description",
            "valueString" : "Resource is not known"
          },
          {
            "url" : "responseType",
            "valueString" : "TIFlowOperationOutcome"
          },
          {
            "url" : "errorCode",
            "valueString" : "MSG_RESOURCE_ID_FAIL"
          }],
          "url" : "https://gematik.de/fhir/ti/StructureDefinition/extension-http-response-info"
        },
        {
          "extension" : [{
            "url" : "statusCode",
            "valueString" : "410"
          },
          {
            "url" : "description",
            "valueString" : "Resource was deleted"
          },
          {
            "url" : "responseType",
            "valueString" : "TIFlowOperationOutcome"
          },
          {
            "url" : "errorCode",
            "valueString" : "MSG_DELETED"
          }],
          "url" : "https://gematik.de/fhir/ti/StructureDefinition/extension-http-response-info"
        },
        {
          "extension" : [{
            "url" : "statusCode",
            "valueString" : "400"
          },
          {
            "url" : "description",
            "valueString" : "Invalid request"
          },
          {
            "url" : "responseType",
            "valueString" : "TIFlowOperationOutcome"
          },
          {
            "url" : "errorCode",
            "valueString" : "MSG_BAD_FORMAT"
          }],
          "url" : "https://gematik.de/fhir/ti/StructureDefinition/extension-http-response-info"
        },
        {
          "extension" : [{
            "url" : "statusCode",
            "valueString" : "500"
          },
          {
            "url" : "description",
            "valueString" : "Internal Server Error"
          },
          {
            "url" : "responseType",
            "valueString" : "TIFlowOperationOutcome"
          },
          {
            "url" : "errorCode",
            "valueString" : "TIFLOW_INTERNAL_ERROR"
          }],
          "url" : "https://gematik.de/fhir/ti/StructureDefinition/extension-http-response-info"
        },
        {
          "extension" : [{
            "url" : "statusCode",
            "valueString" : "408"
          },
          {
            "url" : "description",
            "valueString" : "Timeout"
          },
          {
            "url" : "responseType",
            "valueString" : "TIFlowOperationOutcome"
          },
          {
            "url" : "errorCode",
            "valueString" : "TIFLOW_TIMEOUT"
          }],
          "url" : "https://gematik.de/fhir/ti/StructureDefinition/extension-http-response-info"
        }],
        "name" : "close",
        "definition" : "https://gematik.de/fhir/tiflow-erezept/OperationDefinition/tiflow-rx-close-op",
        "documentation" : "Finishes the ePrescription workflow and sets Task status to completed"
      },
      {
        "extension" : [{
          "url" : "http://hl7.org/fhir/StructureDefinition/capabilitystatement-expectation",
          "valueCode" : "SHALL"
        },
        {
          "extension" : [{
            "url" : "statusCode",
            "valueString" : "204"
          },
          {
            "url" : "description",
            "valueString" : "Successful operation without response body"
          }],
          "url" : "https://gematik.de/fhir/ti/StructureDefinition/extension-http-response-info"
        },
        {
          "extension" : [{
            "url" : "statusCode",
            "valueString" : "403"
          },
          {
            "url" : "description",
            "valueString" : "Identity mismatch: Access token or x-insurantid header does not match FHIR data (Telematik-ID / KVNR)"
          },
          {
            "url" : "responseType",
            "valueString" : "TIFlowOperationOutcome"
          },
          {
            "url" : "errorCode",
            "valueString" : "SVC_IDENTITY_MISMATCH"
          }],
          "url" : "https://gematik.de/fhir/ti/StructureDefinition/extension-http-response-info"
        },
        {
          "extension" : [{
            "url" : "statusCode",
            "valueString" : "403"
          },
          {
            "url" : "description",
            "valueString" : "Access code mismatch"
          },
          {
            "url" : "responseType",
            "valueString" : "TIFlowOperationOutcome"
          },
          {
            "url" : "errorCode",
            "valueString" : "TIFLOW_ACCESSCODE_MISMATCH"
          }],
          "url" : "https://gematik.de/fhir/ti/StructureDefinition/extension-http-response-info"
        },
        {
          "extension" : [{
            "url" : "statusCode",
            "valueString" : "403"
          },
          {
            "url" : "description",
            "valueString" : "Access role not allowed"
          },
          {
            "url" : "responseType",
            "valueString" : "TIFlowOperationOutcome"
          },
          {
            "url" : "errorCode",
            "valueString" : "TIFLOW_AUTH_ROLE_NOT_ALLOWED"
          }],
          "url" : "https://gematik.de/fhir/ti/StructureDefinition/extension-http-response-info"
        },
        {
          "extension" : [{
            "url" : "statusCode",
            "valueString" : "403"
          },
          {
            "url" : "description",
            "valueString" : "Task secret mismatch"
          },
          {
            "url" : "responseType",
            "valueString" : "TIFlowOperationOutcome"
          },
          {
            "url" : "errorCode",
            "valueString" : "TIFLOW_SECRET_MISMATCH"
          }],
          "url" : "https://gematik.de/fhir/ti/StructureDefinition/extension-http-response-info"
        },
        {
          "extension" : [{
            "url" : "statusCode",
            "valueString" : "400"
          },
          {
            "url" : "description",
            "valueString" : "Task status mismatch"
          },
          {
            "url" : "responseType",
            "valueString" : "TIFlowOperationOutcome"
          },
          {
            "url" : "errorCode",
            "valueString" : "TIFLOW_TASK_STATUS_MISMATCH"
          }],
          "url" : "https://gematik.de/fhir/ti/StructureDefinition/extension-http-response-info"
        },
        {
          "extension" : [{
            "url" : "statusCode",
            "valueString" : "404"
          },
          {
            "url" : "description",
            "valueString" : "Resource is not known"
          },
          {
            "url" : "responseType",
            "valueString" : "TIFlowOperationOutcome"
          },
          {
            "url" : "errorCode",
            "valueString" : "MSG_RESOURCE_ID_FAIL"
          }],
          "url" : "https://gematik.de/fhir/ti/StructureDefinition/extension-http-response-info"
        },
        {
          "extension" : [{
            "url" : "statusCode",
            "valueString" : "410"
          },
          {
            "url" : "description",
            "valueString" : "Resource was deleted"
          },
          {
            "url" : "responseType",
            "valueString" : "TIFlowOperationOutcome"
          },
          {
            "url" : "errorCode",
            "valueString" : "MSG_DELETED"
          }],
          "url" : "https://gematik.de/fhir/ti/StructureDefinition/extension-http-response-info"
        },
        {
          "extension" : [{
            "url" : "statusCode",
            "valueString" : "400"
          },
          {
            "url" : "description",
            "valueString" : "Invalid request"
          },
          {
            "url" : "responseType",
            "valueString" : "TIFlowOperationOutcome"
          },
          {
            "url" : "errorCode",
            "valueString" : "MSG_BAD_FORMAT"
          }],
          "url" : "https://gematik.de/fhir/ti/StructureDefinition/extension-http-response-info"
        },
        {
          "extension" : [{
            "url" : "statusCode",
            "valueString" : "500"
          },
          {
            "url" : "description",
            "valueString" : "Internal Server Error"
          },
          {
            "url" : "responseType",
            "valueString" : "TIFlowOperationOutcome"
          },
          {
            "url" : "errorCode",
            "valueString" : "TIFLOW_INTERNAL_ERROR"
          }],
          "url" : "https://gematik.de/fhir/ti/StructureDefinition/extension-http-response-info"
        },
        {
          "extension" : [{
            "url" : "statusCode",
            "valueString" : "408"
          },
          {
            "url" : "description",
            "valueString" : "Timeout"
          },
          {
            "url" : "responseType",
            "valueString" : "TIFlowOperationOutcome"
          },
          {
            "url" : "errorCode",
            "valueString" : "TIFLOW_TIMEOUT"
          }],
          "url" : "https://gematik.de/fhir/ti/StructureDefinition/extension-http-response-info"
        }],
        "name" : "abort",
        "definition" : "https://gematik.de/fhir/tiflow-erezept/OperationDefinition/tiflow-rx-abort-op",
        "documentation" : "Aborts the ePrescription workflow and deletes Task related data"
      },
      {
        "extension" : [{
          "url" : "http://hl7.org/fhir/StructureDefinition/capabilitystatement-expectation",
          "valueCode" : "SHALL"
        },
        {
          "extension" : [{
            "url" : "statusCode",
            "valueString" : "200"
          },
          {
            "url" : "description",
            "valueString" : "Successful operation"
          }],
          "url" : "https://gematik.de/fhir/ti/StructureDefinition/extension-http-response-info"
        },
        {
          "extension" : [{
            "url" : "statusCode",
            "valueString" : "400"
          },
          {
            "url" : "description",
            "valueString" : "FHIR Profile Validation Failed"
          },
          {
            "url" : "responseType",
            "valueString" : "TIFlowOperationOutcome"
          },
          {
            "url" : "errorCode",
            "valueString" : "SVC_VALIDATION_FAILED"
          }],
          "url" : "https://gematik.de/fhir/ti/StructureDefinition/extension-http-response-info"
        },
        {
          "extension" : [{
            "url" : "statusCode",
            "valueString" : "403"
          },
          {
            "url" : "description",
            "valueString" : "Access role not allowed"
          },
          {
            "url" : "responseType",
            "valueString" : "TIFlowOperationOutcome"
          },
          {
            "url" : "errorCode",
            "valueString" : "TIFLOW_AUTH_ROLE_NOT_ALLOWED"
          }],
          "url" : "https://gematik.de/fhir/ti/StructureDefinition/extension-http-response-info"
        },
        {
          "extension" : [{
            "url" : "statusCode",
            "valueString" : "403"
          },
          {
            "url" : "description",
            "valueString" : "Task secret mismatch"
          },
          {
            "url" : "responseType",
            "valueString" : "TIFlowOperationOutcome"
          },
          {
            "url" : "errorCode",
            "valueString" : "TIFLOW_SECRET_MISMATCH"
          }],
          "url" : "https://gematik.de/fhir/ti/StructureDefinition/extension-http-response-info"
        },
        {
          "extension" : [{
            "url" : "statusCode",
            "valueString" : "400"
          },
          {
            "url" : "description",
            "valueString" : "Task status mismatch"
          },
          {
            "url" : "responseType",
            "valueString" : "TIFlowOperationOutcome"
          },
          {
            "url" : "errorCode",
            "valueString" : "TIFLOW_TASK_STATUS_MISMATCH"
          }],
          "url" : "https://gematik.de/fhir/ti/StructureDefinition/extension-http-response-info"
        },
        {
          "extension" : [{
            "url" : "statusCode",
            "valueString" : "404"
          },
          {
            "url" : "description",
            "valueString" : "Resource is not known"
          },
          {
            "url" : "responseType",
            "valueString" : "TIFlowOperationOutcome"
          },
          {
            "url" : "errorCode",
            "valueString" : "MSG_RESOURCE_ID_FAIL"
          }],
          "url" : "https://gematik.de/fhir/ti/StructureDefinition/extension-http-response-info"
        },
        {
          "extension" : [{
            "url" : "statusCode",
            "valueString" : "410"
          },
          {
            "url" : "description",
            "valueString" : "Resource was deleted"
          },
          {
            "url" : "responseType",
            "valueString" : "TIFlowOperationOutcome"
          },
          {
            "url" : "errorCode",
            "valueString" : "MSG_DELETED"
          }],
          "url" : "https://gematik.de/fhir/ti/StructureDefinition/extension-http-response-info"
        },
        {
          "extension" : [{
            "url" : "statusCode",
            "valueString" : "400"
          },
          {
            "url" : "description",
            "valueString" : "Invalid request"
          },
          {
            "url" : "responseType",
            "valueString" : "TIFlowOperationOutcome"
          },
          {
            "url" : "errorCode",
            "valueString" : "MSG_BAD_FORMAT"
          }],
          "url" : "https://gematik.de/fhir/ti/StructureDefinition/extension-http-response-info"
        },
        {
          "extension" : [{
            "url" : "statusCode",
            "valueString" : "500"
          },
          {
            "url" : "description",
            "valueString" : "Internal Server Error"
          },
          {
            "url" : "responseType",
            "valueString" : "TIFlowOperationOutcome"
          },
          {
            "url" : "errorCode",
            "valueString" : "TIFLOW_INTERNAL_ERROR"
          }],
          "url" : "https://gematik.de/fhir/ti/StructureDefinition/extension-http-response-info"
        },
        {
          "extension" : [{
            "url" : "statusCode",
            "valueString" : "408"
          },
          {
            "url" : "description",
            "valueString" : "Timeout"
          },
          {
            "url" : "responseType",
            "valueString" : "TIFlowOperationOutcome"
          },
          {
            "url" : "errorCode",
            "valueString" : "TIFLOW_TIMEOUT"
          }],
          "url" : "https://gematik.de/fhir/ti/StructureDefinition/extension-http-response-info"
        }],
        "name" : "dispense",
        "definition" : "https://gematik.de/fhir/tiflow-erezept/OperationDefinition/tiflow-rx-dispense-op",
        "documentation" : "Documents medication dispensation without changing Task status"
      },
      {
        "extension" : [{
          "url" : "http://hl7.org/fhir/StructureDefinition/capabilitystatement-expectation",
          "valueCode" : "SHALL"
        },
        {
          "extension" : [{
            "url" : "statusCode",
            "valueString" : "400"
          },
          {
            "url" : "description",
            "valueString" : "FHIR Profile Validation Failed"
          },
          {
            "url" : "responseType",
            "valueString" : "TIFlowOperationOutcome"
          },
          {
            "url" : "errorCode",
            "valueString" : "SVC_VALIDATION_FAILED"
          }],
          "url" : "https://gematik.de/fhir/ti/StructureDefinition/extension-http-response-info"
        },
        {
          "extension" : [{
            "url" : "statusCode",
            "valueString" : "403"
          },
          {
            "url" : "description",
            "valueString" : "Access permission invalid"
          },
          {
            "url" : "responseType",
            "valueString" : "TIFlowOperationOutcome"
          },
          {
            "url" : "errorCode",
            "valueString" : "TIFLOW_ACCESS_PERMISSION_INVALID"
          }],
          "url" : "https://gematik.de/fhir/ti/StructureDefinition/extension-http-response-info"
        },
        {
          "extension" : [{
            "url" : "statusCode",
            "valueString" : "403"
          },
          {
            "url" : "description",
            "valueString" : "Access role not allowed"
          },
          {
            "url" : "responseType",
            "valueString" : "TIFlowOperationOutcome"
          },
          {
            "url" : "errorCode",
            "valueString" : "TIFLOW_AUTH_ROLE_NOT_ALLOWED"
          }],
          "url" : "https://gematik.de/fhir/ti/StructureDefinition/extension-http-response-info"
        },
        {
          "extension" : [{
            "url" : "statusCode",
            "valueString" : "403"
          },
          {
            "url" : "description",
            "valueString" : "Consent missing"
          },
          {
            "url" : "responseType",
            "valueString" : "TIFlowOperationOutcome"
          },
          {
            "url" : "errorCode",
            "valueString" : "TIFLOW_CONSENT_MISSING"
          }],
          "url" : "https://gematik.de/fhir/ti/StructureDefinition/extension-http-response-info"
        },
        {
          "extension" : [{
            "url" : "statusCode",
            "valueString" : "400"
          },
          {
            "url" : "description",
            "valueString" : "Task status mismatch"
          },
          {
            "url" : "responseType",
            "valueString" : "TIFlowOperationOutcome"
          },
          {
            "url" : "errorCode",
            "valueString" : "TIFLOW_TASK_STATUS_MISMATCH"
          }],
          "url" : "https://gematik.de/fhir/ti/StructureDefinition/extension-http-response-info"
        },
        {
          "extension" : [{
            "url" : "statusCode",
            "valueString" : "404"
          },
          {
            "url" : "description",
            "valueString" : "Resource is not known"
          },
          {
            "url" : "responseType",
            "valueString" : "TIFlowOperationOutcome"
          },
          {
            "url" : "errorCode",
            "valueString" : "MSG_RESOURCE_ID_FAIL"
          }],
          "url" : "https://gematik.de/fhir/ti/StructureDefinition/extension-http-response-info"
        },
        {
          "extension" : [{
            "url" : "statusCode",
            "valueString" : "410"
          },
          {
            "url" : "description",
            "valueString" : "Resource was deleted"
          },
          {
            "url" : "responseType",
            "valueString" : "TIFlowOperationOutcome"
          },
          {
            "url" : "errorCode",
            "valueString" : "MSG_DELETED"
          }],
          "url" : "https://gematik.de/fhir/ti/StructureDefinition/extension-http-response-info"
        },
        {
          "extension" : [{
            "url" : "statusCode",
            "valueString" : "400"
          },
          {
            "url" : "description",
            "valueString" : "Invalid request"
          },
          {
            "url" : "responseType",
            "valueString" : "TIFlowOperationOutcome"
          },
          {
            "url" : "errorCode",
            "valueString" : "MSG_BAD_FORMAT"
          }],
          "url" : "https://gematik.de/fhir/ti/StructureDefinition/extension-http-response-info"
        },
        {
          "extension" : [{
            "url" : "statusCode",
            "valueString" : "500"
          },
          {
            "url" : "description",
            "valueString" : "Internal Server Error"
          },
          {
            "url" : "responseType",
            "valueString" : "TIFlowOperationOutcome"
          },
          {
            "url" : "errorCode",
            "valueString" : "TIFLOW_INTERNAL_ERROR"
          }],
          "url" : "https://gematik.de/fhir/ti/StructureDefinition/extension-http-response-info"
        },
        {
          "extension" : [{
            "url" : "statusCode",
            "valueString" : "408"
          },
          {
            "url" : "description",
            "valueString" : "Timeout"
          },
          {
            "url" : "responseType",
            "valueString" : "TIFlowOperationOutcome"
          },
          {
            "url" : "errorCode",
            "valueString" : "TIFLOW_TIMEOUT"
          }],
          "url" : "https://gematik.de/fhir/ti/StructureDefinition/extension-http-response-info"
        }],
        "name" : "eu-close",
        "definition" : "https://gematik.de/fhir/tiflow-erezept/OperationDefinition/EUCloseOperation",
        "documentation" : "Finishes the EU ePrescription workflow and creates a signed receipt bundle"
      }]
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/StructureDefinition/capabilitystatement-expectation",
        "valueCode" : "SHALL"
      }],
      "type" : "Communication",
      "supportedProfile" : ["https://gematik.de/fhir/erp/StructureDefinition/GEM_ERP_PR_Communication_DispReq",
      "https://gematik.de/fhir/erp/StructureDefinition/GEM_ERP_PR_Communication_Reply"],
      "_supportedProfile" : [{
        "extension" : [{
          "url" : "http://hl7.org/fhir/StructureDefinition/capabilitystatement-expectation",
          "valueCode" : "SHALL"
        }]
      },
      {
        "extension" : [{
          "url" : "http://hl7.org/fhir/StructureDefinition/capabilitystatement-expectation",
          "valueCode" : "SHALL"
        }]
      }],
      "interaction" : [{
        "extension" : [{
          "url" : "http://hl7.org/fhir/StructureDefinition/capabilitystatement-expectation",
          "valueCode" : "SHALL"
        },
        {
          "extension" : [{
            "url" : "statusCode",
            "valueString" : "400"
          },
          {
            "url" : "description",
            "valueString" : "Invalid request"
          },
          {
            "url" : "responseType",
            "valueString" : "TIFlowOperationOutcome"
          },
          {
            "url" : "errorCode",
            "valueString" : "MSG_BAD_FORMAT"
          }],
          "url" : "https://gematik.de/fhir/ti/StructureDefinition/extension-http-response-info"
        },
        {
          "extension" : [{
            "url" : "statusCode",
            "valueString" : "408"
          },
          {
            "url" : "description",
            "valueString" : "Timeout"
          },
          {
            "url" : "responseType",
            "valueString" : "TIFlowOperationOutcome"
          },
          {
            "url" : "errorCode",
            "valueString" : "TIFLOW_TIMEOUT"
          }],
          "url" : "https://gematik.de/fhir/ti/StructureDefinition/extension-http-response-info"
        },
        {
          "extension" : [{
            "url" : "statusCode",
            "valueString" : "500"
          },
          {
            "url" : "description",
            "valueString" : "Internal Server Error"
          },
          {
            "url" : "responseType",
            "valueString" : "TIFlowOperationOutcome"
          },
          {
            "url" : "errorCode",
            "valueString" : "TIFLOW_INTERNAL_ERROR"
          }],
          "url" : "https://gematik.de/fhir/ti/StructureDefinition/extension-http-response-info"
        },
        {
          "extension" : [{
            "url" : "statusCode",
            "valueString" : "200"
          },
          {
            "url" : "description",
            "valueString" : "Successful operation"
          }],
          "url" : "https://gematik.de/fhir/ti/StructureDefinition/extension-http-response-info"
        },
        {
          "extension" : [{
            "url" : "statusCode",
            "valueString" : "400"
          },
          {
            "url" : "description",
            "valueString" : "Unknown search parameter"
          },
          {
            "url" : "responseType",
            "valueString" : "TIFlowOperationOutcome"
          },
          {
            "url" : "errorCode",
            "valueString" : "MSG_PARAM_UNKNOWN"
          }],
          "url" : "https://gematik.de/fhir/ti/StructureDefinition/extension-http-response-info"
        },
        {
          "extension" : [{
            "url" : "statusCode",
            "valueString" : "400"
          },
          {
            "url" : "description",
            "valueString" : "Invalid query parameter(s)"
          },
          {
            "url" : "responseType",
            "valueString" : "TIFlowOperationOutcome"
          },
          {
            "url" : "errorCode",
            "valueString" : "MSG_BAD_SYNTAX"
          }],
          "url" : "https://gematik.de/fhir/ti/StructureDefinition/extension-http-response-info"
        },
        {
          "extension" : [{
            "url" : "statusCode",
            "valueString" : "404"
          },
          {
            "url" : "description",
            "valueString" : "Unknown resource type"
          },
          {
            "url" : "responseType",
            "valueString" : "TIFlowOperationOutcome"
          },
          {
            "url" : "errorCode",
            "valueString" : "MSG_UNKNOWN_TYPE"
          }],
          "url" : "https://gematik.de/fhir/ti/StructureDefinition/extension-http-response-info"
        }],
        "code" : "search-type"
      },
      {
        "extension" : [{
          "url" : "http://hl7.org/fhir/StructureDefinition/capabilitystatement-expectation",
          "valueCode" : "SHALL"
        },
        {
          "extension" : [{
            "url" : "statusCode",
            "valueString" : "400"
          },
          {
            "url" : "description",
            "valueString" : "Invalid request"
          },
          {
            "url" : "responseType",
            "valueString" : "TIFlowOperationOutcome"
          },
          {
            "url" : "errorCode",
            "valueString" : "MSG_BAD_FORMAT"
          }],
          "url" : "https://gematik.de/fhir/ti/StructureDefinition/extension-http-response-info"
        },
        {
          "extension" : [{
            "url" : "statusCode",
            "valueString" : "408"
          },
          {
            "url" : "description",
            "valueString" : "Timeout"
          },
          {
            "url" : "responseType",
            "valueString" : "TIFlowOperationOutcome"
          },
          {
            "url" : "errorCode",
            "valueString" : "TIFLOW_TIMEOUT"
          }],
          "url" : "https://gematik.de/fhir/ti/StructureDefinition/extension-http-response-info"
        },
        {
          "extension" : [{
            "url" : "statusCode",
            "valueString" : "500"
          },
          {
            "url" : "description",
            "valueString" : "Internal Server Error"
          },
          {
            "url" : "responseType",
            "valueString" : "TIFlowOperationOutcome"
          },
          {
            "url" : "errorCode",
            "valueString" : "TIFLOW_INTERNAL_ERROR"
          }],
          "url" : "https://gematik.de/fhir/ti/StructureDefinition/extension-http-response-info"
        },
        {
          "extension" : [{
            "url" : "statusCode",
            "valueString" : "200"
          },
          {
            "url" : "description",
            "valueString" : "Successful operation"
          }],
          "url" : "https://gematik.de/fhir/ti/StructureDefinition/extension-http-response-info"
        },
        {
          "extension" : [{
            "url" : "statusCode",
            "valueString" : "404"
          },
          {
            "url" : "description",
            "valueString" : "Unknown resource type"
          },
          {
            "url" : "responseType",
            "valueString" : "TIFlowOperationOutcome"
          },
          {
            "url" : "errorCode",
            "valueString" : "MSG_UNKNOWN_TYPE"
          }],
          "url" : "https://gematik.de/fhir/ti/StructureDefinition/extension-http-response-info"
        },
        {
          "extension" : [{
            "url" : "statusCode",
            "valueString" : "404"
          },
          {
            "url" : "description",
            "valueString" : "Resource is not known"
          },
          {
            "url" : "responseType",
            "valueString" : "TIFlowOperationOutcome"
          },
          {
            "url" : "errorCode",
            "valueString" : "MSG_RESOURCE_ID_FAIL"
          }],
          "url" : "https://gematik.de/fhir/ti/StructureDefinition/extension-http-response-info"
        },
        {
          "extension" : [{
            "url" : "statusCode",
            "valueString" : "410"
          },
          {
            "url" : "description",
            "valueString" : "Resource was deleted"
          },
          {
            "url" : "responseType",
            "valueString" : "TIFlowOperationOutcome"
          },
          {
            "url" : "errorCode",
            "valueString" : "MSG_DELETED"
          }],
          "url" : "https://gematik.de/fhir/ti/StructureDefinition/extension-http-response-info"
        }],
        "code" : "read"
      },
      {
        "extension" : [{
          "url" : "http://hl7.org/fhir/StructureDefinition/capabilitystatement-expectation",
          "valueCode" : "SHALL"
        },
        {
          "extension" : [{
            "url" : "statusCode",
            "valueString" : "400"
          },
          {
            "url" : "description",
            "valueString" : "Invalid request"
          },
          {
            "url" : "responseType",
            "valueString" : "TIFlowOperationOutcome"
          },
          {
            "url" : "errorCode",
            "valueString" : "MSG_BAD_FORMAT"
          }],
          "url" : "https://gematik.de/fhir/ti/StructureDefinition/extension-http-response-info"
        },
        {
          "extension" : [{
            "url" : "statusCode",
            "valueString" : "408"
          },
          {
            "url" : "description",
            "valueString" : "Timeout"
          },
          {
            "url" : "responseType",
            "valueString" : "TIFlowOperationOutcome"
          },
          {
            "url" : "errorCode",
            "valueString" : "TIFLOW_TIMEOUT"
          }],
          "url" : "https://gematik.de/fhir/ti/StructureDefinition/extension-http-response-info"
        },
        {
          "extension" : [{
            "url" : "statusCode",
            "valueString" : "500"
          },
          {
            "url" : "description",
            "valueString" : "Internal Server Error"
          },
          {
            "url" : "responseType",
            "valueString" : "TIFlowOperationOutcome"
          },
          {
            "url" : "errorCode",
            "valueString" : "TIFLOW_INTERNAL_ERROR"
          }],
          "url" : "https://gematik.de/fhir/ti/StructureDefinition/extension-http-response-info"
        },
        {
          "extension" : [{
            "url" : "statusCode",
            "valueString" : "201"
          },
          {
            "url" : "description",
            "valueString" : "Resource created"
          }],
          "url" : "https://gematik.de/fhir/ti/StructureDefinition/extension-http-response-info"
        },
        {
          "extension" : [{
            "url" : "statusCode",
            "valueString" : "404"
          },
          {
            "url" : "description",
            "valueString" : "Unknown resource type"
          },
          {
            "url" : "responseType",
            "valueString" : "TIFlowOperationOutcome"
          },
          {
            "url" : "errorCode",
            "valueString" : "MSG_UNKNOWN_TYPE"
          }],
          "url" : "https://gematik.de/fhir/ti/StructureDefinition/extension-http-response-info"
        }],
        "code" : "create"
      },
      {
        "extension" : [{
          "url" : "http://hl7.org/fhir/StructureDefinition/capabilitystatement-expectation",
          "valueCode" : "SHALL"
        },
        {
          "extension" : [{
            "url" : "statusCode",
            "valueString" : "400"
          },
          {
            "url" : "description",
            "valueString" : "Invalid request"
          },
          {
            "url" : "responseType",
            "valueString" : "TIFlowOperationOutcome"
          },
          {
            "url" : "errorCode",
            "valueString" : "MSG_BAD_FORMAT"
          }],
          "url" : "https://gematik.de/fhir/ti/StructureDefinition/extension-http-response-info"
        },
        {
          "extension" : [{
            "url" : "statusCode",
            "valueString" : "408"
          },
          {
            "url" : "description",
            "valueString" : "Timeout"
          },
          {
            "url" : "responseType",
            "valueString" : "TIFlowOperationOutcome"
          },
          {
            "url" : "errorCode",
            "valueString" : "TIFLOW_TIMEOUT"
          }],
          "url" : "https://gematik.de/fhir/ti/StructureDefinition/extension-http-response-info"
        },
        {
          "extension" : [{
            "url" : "statusCode",
            "valueString" : "500"
          },
          {
            "url" : "description",
            "valueString" : "Internal Server Error"
          },
          {
            "url" : "responseType",
            "valueString" : "TIFlowOperationOutcome"
          },
          {
            "url" : "errorCode",
            "valueString" : "TIFLOW_INTERNAL_ERROR"
          }],
          "url" : "https://gematik.de/fhir/ti/StructureDefinition/extension-http-response-info"
        },
        {
          "extension" : [{
            "url" : "statusCode",
            "valueString" : "204"
          },
          {
            "url" : "description",
            "valueString" : "Successful operation without response body"
          }],
          "url" : "https://gematik.de/fhir/ti/StructureDefinition/extension-http-response-info"
        },
        {
          "extension" : [{
            "url" : "statusCode",
            "valueString" : "404"
          },
          {
            "url" : "description",
            "valueString" : "Unknown resource type"
          },
          {
            "url" : "responseType",
            "valueString" : "TIFlowOperationOutcome"
          },
          {
            "url" : "errorCode",
            "valueString" : "MSG_UNKNOWN_TYPE"
          }],
          "url" : "https://gematik.de/fhir/ti/StructureDefinition/extension-http-response-info"
        },
        {
          "extension" : [{
            "url" : "statusCode",
            "valueString" : "404"
          },
          {
            "url" : "description",
            "valueString" : "Resource is not known"
          },
          {
            "url" : "responseType",
            "valueString" : "TIFlowOperationOutcome"
          },
          {
            "url" : "errorCode",
            "valueString" : "MSG_RESOURCE_ID_FAIL"
          }],
          "url" : "https://gematik.de/fhir/ti/StructureDefinition/extension-http-response-info"
        },
        {
          "extension" : [{
            "url" : "statusCode",
            "valueString" : "410"
          },
          {
            "url" : "description",
            "valueString" : "Resource was deleted"
          },
          {
            "url" : "responseType",
            "valueString" : "TIFlowOperationOutcome"
          },
          {
            "url" : "errorCode",
            "valueString" : "MSG_DELETED"
          }],
          "url" : "https://gematik.de/fhir/ti/StructureDefinition/extension-http-response-info"
        }],
        "code" : "delete"
      }],
      "versioning" : "versioned-update",
      "readHistory" : true,
      "searchParam" : [{
        "extension" : [{
          "url" : "http://hl7.org/fhir/StructureDefinition/capabilitystatement-expectation",
          "valueCode" : "SHALL"
        }],
        "name" : "sent",
        "definition" : "http://hl7.org/fhir/SearchParameter/Communication-sent",
        "type" : "date",
        "documentation" : "Communication.sent - Unterstützt die Suche nach dem Sendedatum; default sort if _sort is not provided"
      },
      {
        "extension" : [{
          "url" : "http://hl7.org/fhir/StructureDefinition/capabilitystatement-expectation",
          "valueCode" : "SHALL"
        }],
        "name" : "received",
        "definition" : "http://hl7.org/fhir/SearchParameter/Communication-received",
        "type" : "date",
        "documentation" : "Communication.received - Unterstützt die Suche nach dem Empfangsdatum"
      },
      {
        "extension" : [{
          "url" : "http://hl7.org/fhir/StructureDefinition/capabilitystatement-expectation",
          "valueCode" : "SHALL"
        }],
        "name" : "recipient",
        "definition" : "http://hl7.org/fhir/SearchParameter/Communication-recipient",
        "type" : "reference",
        "documentation" : "Communication.recipient.identifier.value - Unterstützt die Suche nach dem Empfänger einer Nachricht"
      },
      {
        "extension" : [{
          "url" : "http://hl7.org/fhir/StructureDefinition/capabilitystatement-expectation",
          "valueCode" : "SHALL"
        }],
        "name" : "sender",
        "definition" : "http://hl7.org/fhir/SearchParameter/Communication-sender",
        "type" : "reference",
        "documentation" : "Communication.sender.identifier.value - Unterstützt die Suche nach dem Absender einer Nachricht"
      },
      {
        "extension" : [{
          "url" : "http://hl7.org/fhir/StructureDefinition/capabilitystatement-expectation",
          "valueCode" : "SHALL"
        }],
        "name" : "_sort",
        "type" : "string",
        "documentation" : "Unterstützt das Sortieren nach unterstützten Communication-Suchkriterien"
      },
      {
        "extension" : [{
          "url" : "http://hl7.org/fhir/StructureDefinition/capabilitystatement-expectation",
          "valueCode" : "SHALL"
        }],
        "name" : "_count",
        "type" : "number",
        "documentation" : "Maximale Anzahl zurückgegebener Einträge pro Seite; maximum value is 50"
      },
      {
        "extension" : [{
          "url" : "http://hl7.org/fhir/StructureDefinition/capabilitystatement-expectation",
          "valueCode" : "SHALL"
        }],
        "name" : "_offset",
        "type" : "number",
        "documentation" : "Nullbasierter Offset des ersten zurückgegebenen Eintrags; default is 0"
      }]
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/StructureDefinition/capabilitystatement-expectation",
        "valueCode" : "SHALL"
      }],
      "type" : "MedicationDispense",
      "supportedProfile" : ["https://gematik.de/fhir/erp/StructureDefinition/GEM_ERP_PR_MedicationDispense"],
      "_supportedProfile" : [{
        "extension" : [{
          "url" : "http://hl7.org/fhir/StructureDefinition/capabilitystatement-expectation",
          "valueCode" : "SHALL"
        }]
      }],
      "interaction" : [{
        "extension" : [{
          "url" : "http://hl7.org/fhir/StructureDefinition/capabilitystatement-expectation",
          "valueCode" : "SHALL"
        },
        {
          "extension" : [{
            "url" : "statusCode",
            "valueString" : "400"
          },
          {
            "url" : "description",
            "valueString" : "Invalid request"
          },
          {
            "url" : "responseType",
            "valueString" : "TIFlowOperationOutcome"
          },
          {
            "url" : "errorCode",
            "valueString" : "MSG_BAD_FORMAT"
          }],
          "url" : "https://gematik.de/fhir/ti/StructureDefinition/extension-http-response-info"
        },
        {
          "extension" : [{
            "url" : "statusCode",
            "valueString" : "408"
          },
          {
            "url" : "description",
            "valueString" : "Timeout"
          },
          {
            "url" : "responseType",
            "valueString" : "TIFlowOperationOutcome"
          },
          {
            "url" : "errorCode",
            "valueString" : "TIFLOW_TIMEOUT"
          }],
          "url" : "https://gematik.de/fhir/ti/StructureDefinition/extension-http-response-info"
        },
        {
          "extension" : [{
            "url" : "statusCode",
            "valueString" : "500"
          },
          {
            "url" : "description",
            "valueString" : "Internal Server Error"
          },
          {
            "url" : "responseType",
            "valueString" : "TIFlowOperationOutcome"
          },
          {
            "url" : "errorCode",
            "valueString" : "TIFLOW_INTERNAL_ERROR"
          }],
          "url" : "https://gematik.de/fhir/ti/StructureDefinition/extension-http-response-info"
        },
        {
          "extension" : [{
            "url" : "statusCode",
            "valueString" : "200"
          },
          {
            "url" : "description",
            "valueString" : "Successful operation"
          }],
          "url" : "https://gematik.de/fhir/ti/StructureDefinition/extension-http-response-info"
        },
        {
          "extension" : [{
            "url" : "statusCode",
            "valueString" : "400"
          },
          {
            "url" : "description",
            "valueString" : "Unknown search parameter"
          },
          {
            "url" : "responseType",
            "valueString" : "TIFlowOperationOutcome"
          },
          {
            "url" : "errorCode",
            "valueString" : "MSG_PARAM_UNKNOWN"
          }],
          "url" : "https://gematik.de/fhir/ti/StructureDefinition/extension-http-response-info"
        },
        {
          "extension" : [{
            "url" : "statusCode",
            "valueString" : "400"
          },
          {
            "url" : "description",
            "valueString" : "Invalid query parameter(s)"
          },
          {
            "url" : "responseType",
            "valueString" : "TIFlowOperationOutcome"
          },
          {
            "url" : "errorCode",
            "valueString" : "MSG_BAD_SYNTAX"
          }],
          "url" : "https://gematik.de/fhir/ti/StructureDefinition/extension-http-response-info"
        },
        {
          "extension" : [{
            "url" : "statusCode",
            "valueString" : "404"
          },
          {
            "url" : "description",
            "valueString" : "Unknown resource type"
          },
          {
            "url" : "responseType",
            "valueString" : "TIFlowOperationOutcome"
          },
          {
            "url" : "errorCode",
            "valueString" : "MSG_UNKNOWN_TYPE"
          }],
          "url" : "https://gematik.de/fhir/ti/StructureDefinition/extension-http-response-info"
        }],
        "code" : "search-type"
      },
      {
        "extension" : [{
          "url" : "http://hl7.org/fhir/StructureDefinition/capabilitystatement-expectation",
          "valueCode" : "SHALL"
        },
        {
          "extension" : [{
            "url" : "statusCode",
            "valueString" : "400"
          },
          {
            "url" : "description",
            "valueString" : "Invalid request"
          },
          {
            "url" : "responseType",
            "valueString" : "TIFlowOperationOutcome"
          },
          {
            "url" : "errorCode",
            "valueString" : "MSG_BAD_FORMAT"
          }],
          "url" : "https://gematik.de/fhir/ti/StructureDefinition/extension-http-response-info"
        },
        {
          "extension" : [{
            "url" : "statusCode",
            "valueString" : "408"
          },
          {
            "url" : "description",
            "valueString" : "Timeout"
          },
          {
            "url" : "responseType",
            "valueString" : "TIFlowOperationOutcome"
          },
          {
            "url" : "errorCode",
            "valueString" : "TIFLOW_TIMEOUT"
          }],
          "url" : "https://gematik.de/fhir/ti/StructureDefinition/extension-http-response-info"
        },
        {
          "extension" : [{
            "url" : "statusCode",
            "valueString" : "500"
          },
          {
            "url" : "description",
            "valueString" : "Internal Server Error"
          },
          {
            "url" : "responseType",
            "valueString" : "TIFlowOperationOutcome"
          },
          {
            "url" : "errorCode",
            "valueString" : "TIFLOW_INTERNAL_ERROR"
          }],
          "url" : "https://gematik.de/fhir/ti/StructureDefinition/extension-http-response-info"
        },
        {
          "extension" : [{
            "url" : "statusCode",
            "valueString" : "200"
          },
          {
            "url" : "description",
            "valueString" : "Successful operation"
          }],
          "url" : "https://gematik.de/fhir/ti/StructureDefinition/extension-http-response-info"
        },
        {
          "extension" : [{
            "url" : "statusCode",
            "valueString" : "404"
          },
          {
            "url" : "description",
            "valueString" : "Unknown resource type"
          },
          {
            "url" : "responseType",
            "valueString" : "TIFlowOperationOutcome"
          },
          {
            "url" : "errorCode",
            "valueString" : "MSG_UNKNOWN_TYPE"
          }],
          "url" : "https://gematik.de/fhir/ti/StructureDefinition/extension-http-response-info"
        },
        {
          "extension" : [{
            "url" : "statusCode",
            "valueString" : "404"
          },
          {
            "url" : "description",
            "valueString" : "Resource is not known"
          },
          {
            "url" : "responseType",
            "valueString" : "TIFlowOperationOutcome"
          },
          {
            "url" : "errorCode",
            "valueString" : "MSG_RESOURCE_ID_FAIL"
          }],
          "url" : "https://gematik.de/fhir/ti/StructureDefinition/extension-http-response-info"
        },
        {
          "extension" : [{
            "url" : "statusCode",
            "valueString" : "410"
          },
          {
            "url" : "description",
            "valueString" : "Resource was deleted"
          },
          {
            "url" : "responseType",
            "valueString" : "TIFlowOperationOutcome"
          },
          {
            "url" : "errorCode",
            "valueString" : "MSG_DELETED"
          }],
          "url" : "https://gematik.de/fhir/ti/StructureDefinition/extension-http-response-info"
        }],
        "code" : "read"
      }],
      "versioning" : "versioned-update",
      "readHistory" : true,
      "searchParam" : [{
        "extension" : [{
          "url" : "http://hl7.org/fhir/StructureDefinition/capabilitystatement-expectation",
          "valueCode" : "SHALL"
        }],
        "name" : "whenhandedover",
        "definition" : "http://hl7.org/fhir/SearchParameter/MedicationDispense-whenhandedover",
        "type" : "date",
        "documentation" : "MedicationDispense.whenHandedOver - Unterstützt die Suche nach dem Abgabedatum; default sort if _sort is not provided"
      },
      {
        "extension" : [{
          "url" : "http://hl7.org/fhir/StructureDefinition/capabilitystatement-expectation",
          "valueCode" : "SHALL"
        }],
        "name" : "whenprepared",
        "definition" : "http://hl7.org/fhir/SearchParameter/MedicationDispense-whenprepared",
        "type" : "date",
        "documentation" : "MedicationDispense.whenPrepared - Unterstützt die Suche nach dem Herstellungsdatum"
      },
      {
        "extension" : [{
          "url" : "http://hl7.org/fhir/StructureDefinition/capabilitystatement-expectation",
          "valueCode" : "SHALL"
        }],
        "name" : "performer",
        "definition" : "http://hl7.org/fhir/SearchParameter/MedicationDispense-performer",
        "type" : "reference",
        "documentation" : "MedicationDispense.performer.actor.identifier.value - Unterstützt die Suche einer MedicationDispense zu einer Abgebenden LEI."
      },
      {
        "extension" : [{
          "url" : "http://hl7.org/fhir/StructureDefinition/capabilitystatement-expectation",
          "valueCode" : "SHALL"
        }],
        "name" : "_sort",
        "type" : "string",
        "documentation" : "Unterstützt das Sortieren nach unterstützten MedicationDispense-Suchkriterien"
      },
      {
        "extension" : [{
          "url" : "http://hl7.org/fhir/StructureDefinition/capabilitystatement-expectation",
          "valueCode" : "SHALL"
        }],
        "name" : "_count",
        "type" : "number",
        "documentation" : "Maximale Anzahl zurückgegebener Einträge pro Seite; maximum value is 50"
      },
      {
        "extension" : [{
          "url" : "http://hl7.org/fhir/StructureDefinition/capabilitystatement-expectation",
          "valueCode" : "SHALL"
        }],
        "name" : "_offset",
        "type" : "number",
        "documentation" : "Nullbasierter Offset des ersten zurückgegebenen Eintrags; default is 0"
      }]
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/StructureDefinition/capabilitystatement-expectation",
        "valueCode" : "SHALL"
      }],
      "type" : "Subscription",
      "interaction" : [{
        "extension" : [{
          "url" : "http://hl7.org/fhir/StructureDefinition/capabilitystatement-expectation",
          "valueCode" : "SHALL"
        },
        {
          "extension" : [{
            "url" : "statusCode",
            "valueString" : "400"
          },
          {
            "url" : "description",
            "valueString" : "Invalid request"
          },
          {
            "url" : "responseType",
            "valueString" : "TIFlowOperationOutcome"
          },
          {
            "url" : "errorCode",
            "valueString" : "MSG_BAD_FORMAT"
          }],
          "url" : "https://gematik.de/fhir/ti/StructureDefinition/extension-http-response-info"
        },
        {
          "extension" : [{
            "url" : "statusCode",
            "valueString" : "408"
          },
          {
            "url" : "description",
            "valueString" : "Timeout"
          },
          {
            "url" : "responseType",
            "valueString" : "TIFlowOperationOutcome"
          },
          {
            "url" : "errorCode",
            "valueString" : "TIFLOW_TIMEOUT"
          }],
          "url" : "https://gematik.de/fhir/ti/StructureDefinition/extension-http-response-info"
        },
        {
          "extension" : [{
            "url" : "statusCode",
            "valueString" : "500"
          },
          {
            "url" : "description",
            "valueString" : "Internal Server Error"
          },
          {
            "url" : "responseType",
            "valueString" : "TIFlowOperationOutcome"
          },
          {
            "url" : "errorCode",
            "valueString" : "TIFLOW_INTERNAL_ERROR"
          }],
          "url" : "https://gematik.de/fhir/ti/StructureDefinition/extension-http-response-info"
        },
        {
          "extension" : [{
            "url" : "statusCode",
            "valueString" : "200"
          },
          {
            "url" : "description",
            "valueString" : "Successful operation"
          }],
          "url" : "https://gematik.de/fhir/ti/StructureDefinition/extension-http-response-info"
        },
        {
          "extension" : [{
            "url" : "statusCode",
            "valueString" : "400"
          },
          {
            "url" : "description",
            "valueString" : "Unknown search parameter"
          },
          {
            "url" : "responseType",
            "valueString" : "TIFlowOperationOutcome"
          },
          {
            "url" : "errorCode",
            "valueString" : "MSG_PARAM_UNKNOWN"
          }],
          "url" : "https://gematik.de/fhir/ti/StructureDefinition/extension-http-response-info"
        },
        {
          "extension" : [{
            "url" : "statusCode",
            "valueString" : "400"
          },
          {
            "url" : "description",
            "valueString" : "Invalid query parameter(s)"
          },
          {
            "url" : "responseType",
            "valueString" : "TIFlowOperationOutcome"
          },
          {
            "url" : "errorCode",
            "valueString" : "MSG_BAD_SYNTAX"
          }],
          "url" : "https://gematik.de/fhir/ti/StructureDefinition/extension-http-response-info"
        },
        {
          "extension" : [{
            "url" : "statusCode",
            "valueString" : "404"
          },
          {
            "url" : "description",
            "valueString" : "Unknown resource type"
          },
          {
            "url" : "responseType",
            "valueString" : "TIFlowOperationOutcome"
          },
          {
            "url" : "errorCode",
            "valueString" : "MSG_UNKNOWN_TYPE"
          }],
          "url" : "https://gematik.de/fhir/ti/StructureDefinition/extension-http-response-info"
        }],
        "code" : "search-type"
      },
      {
        "extension" : [{
          "url" : "http://hl7.org/fhir/StructureDefinition/capabilitystatement-expectation",
          "valueCode" : "SHALL"
        },
        {
          "extension" : [{
            "url" : "statusCode",
            "valueString" : "400"
          },
          {
            "url" : "description",
            "valueString" : "Invalid request"
          },
          {
            "url" : "responseType",
            "valueString" : "TIFlowOperationOutcome"
          },
          {
            "url" : "errorCode",
            "valueString" : "MSG_BAD_FORMAT"
          }],
          "url" : "https://gematik.de/fhir/ti/StructureDefinition/extension-http-response-info"
        },
        {
          "extension" : [{
            "url" : "statusCode",
            "valueString" : "408"
          },
          {
            "url" : "description",
            "valueString" : "Timeout"
          },
          {
            "url" : "responseType",
            "valueString" : "TIFlowOperationOutcome"
          },
          {
            "url" : "errorCode",
            "valueString" : "TIFLOW_TIMEOUT"
          }],
          "url" : "https://gematik.de/fhir/ti/StructureDefinition/extension-http-response-info"
        },
        {
          "extension" : [{
            "url" : "statusCode",
            "valueString" : "500"
          },
          {
            "url" : "description",
            "valueString" : "Internal Server Error"
          },
          {
            "url" : "responseType",
            "valueString" : "TIFlowOperationOutcome"
          },
          {
            "url" : "errorCode",
            "valueString" : "TIFLOW_INTERNAL_ERROR"
          }],
          "url" : "https://gematik.de/fhir/ti/StructureDefinition/extension-http-response-info"
        },
        {
          "extension" : [{
            "url" : "statusCode",
            "valueString" : "201"
          },
          {
            "url" : "description",
            "valueString" : "Resource created"
          }],
          "url" : "https://gematik.de/fhir/ti/StructureDefinition/extension-http-response-info"
        },
        {
          "extension" : [{
            "url" : "statusCode",
            "valueString" : "404"
          },
          {
            "url" : "description",
            "valueString" : "Unknown resource type"
          },
          {
            "url" : "responseType",
            "valueString" : "TIFlowOperationOutcome"
          },
          {
            "url" : "errorCode",
            "valueString" : "MSG_UNKNOWN_TYPE"
          }],
          "url" : "https://gematik.de/fhir/ti/StructureDefinition/extension-http-response-info"
        }],
        "code" : "create"
      }],
      "versioning" : "versioned-update",
      "readHistory" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/StructureDefinition/capabilitystatement-expectation",
        "valueCode" : "SHALL"
      }],
      "type" : "Consent",
      "interaction" : [{
        "extension" : [{
          "url" : "http://hl7.org/fhir/StructureDefinition/capabilitystatement-expectation",
          "valueCode" : "SHALL"
        },
        {
          "extension" : [{
            "url" : "statusCode",
            "valueString" : "400"
          },
          {
            "url" : "description",
            "valueString" : "Invalid request"
          },
          {
            "url" : "responseType",
            "valueString" : "TIFlowOperationOutcome"
          },
          {
            "url" : "errorCode",
            "valueString" : "MSG_BAD_FORMAT"
          }],
          "url" : "https://gematik.de/fhir/ti/StructureDefinition/extension-http-response-info"
        },
        {
          "extension" : [{
            "url" : "statusCode",
            "valueString" : "408"
          },
          {
            "url" : "description",
            "valueString" : "Timeout"
          },
          {
            "url" : "responseType",
            "valueString" : "TIFlowOperationOutcome"
          },
          {
            "url" : "errorCode",
            "valueString" : "TIFLOW_TIMEOUT"
          }],
          "url" : "https://gematik.de/fhir/ti/StructureDefinition/extension-http-response-info"
        },
        {
          "extension" : [{
            "url" : "statusCode",
            "valueString" : "500"
          },
          {
            "url" : "description",
            "valueString" : "Internal Server Error"
          },
          {
            "url" : "responseType",
            "valueString" : "TIFlowOperationOutcome"
          },
          {
            "url" : "errorCode",
            "valueString" : "TIFLOW_INTERNAL_ERROR"
          }],
          "url" : "https://gematik.de/fhir/ti/StructureDefinition/extension-http-response-info"
        },
        {
          "extension" : [{
            "url" : "statusCode",
            "valueString" : "200"
          },
          {
            "url" : "description",
            "valueString" : "Successful operation"
          }],
          "url" : "https://gematik.de/fhir/ti/StructureDefinition/extension-http-response-info"
        },
        {
          "extension" : [{
            "url" : "statusCode",
            "valueString" : "400"
          },
          {
            "url" : "description",
            "valueString" : "Unknown search parameter"
          },
          {
            "url" : "responseType",
            "valueString" : "TIFlowOperationOutcome"
          },
          {
            "url" : "errorCode",
            "valueString" : "MSG_PARAM_UNKNOWN"
          }],
          "url" : "https://gematik.de/fhir/ti/StructureDefinition/extension-http-response-info"
        },
        {
          "extension" : [{
            "url" : "statusCode",
            "valueString" : "400"
          },
          {
            "url" : "description",
            "valueString" : "Invalid query parameter(s)"
          },
          {
            "url" : "responseType",
            "valueString" : "TIFlowOperationOutcome"
          },
          {
            "url" : "errorCode",
            "valueString" : "MSG_BAD_SYNTAX"
          }],
          "url" : "https://gematik.de/fhir/ti/StructureDefinition/extension-http-response-info"
        },
        {
          "extension" : [{
            "url" : "statusCode",
            "valueString" : "404"
          },
          {
            "url" : "description",
            "valueString" : "Unknown resource type"
          },
          {
            "url" : "responseType",
            "valueString" : "TIFlowOperationOutcome"
          },
          {
            "url" : "errorCode",
            "valueString" : "MSG_UNKNOWN_TYPE"
          }],
          "url" : "https://gematik.de/fhir/ti/StructureDefinition/extension-http-response-info"
        }],
        "code" : "search-type"
      },
      {
        "extension" : [{
          "url" : "http://hl7.org/fhir/StructureDefinition/capabilitystatement-expectation",
          "valueCode" : "SHALL"
        },
        {
          "extension" : [{
            "url" : "statusCode",
            "valueString" : "400"
          },
          {
            "url" : "description",
            "valueString" : "Invalid request"
          },
          {
            "url" : "responseType",
            "valueString" : "TIFlowOperationOutcome"
          },
          {
            "url" : "errorCode",
            "valueString" : "MSG_BAD_FORMAT"
          }],
          "url" : "https://gematik.de/fhir/ti/StructureDefinition/extension-http-response-info"
        },
        {
          "extension" : [{
            "url" : "statusCode",
            "valueString" : "408"
          },
          {
            "url" : "description",
            "valueString" : "Timeout"
          },
          {
            "url" : "responseType",
            "valueString" : "TIFlowOperationOutcome"
          },
          {
            "url" : "errorCode",
            "valueString" : "TIFLOW_TIMEOUT"
          }],
          "url" : "https://gematik.de/fhir/ti/StructureDefinition/extension-http-response-info"
        },
        {
          "extension" : [{
            "url" : "statusCode",
            "valueString" : "500"
          },
          {
            "url" : "description",
            "valueString" : "Internal Server Error"
          },
          {
            "url" : "responseType",
            "valueString" : "TIFlowOperationOutcome"
          },
          {
            "url" : "errorCode",
            "valueString" : "TIFLOW_INTERNAL_ERROR"
          }],
          "url" : "https://gematik.de/fhir/ti/StructureDefinition/extension-http-response-info"
        },
        {
          "extension" : [{
            "url" : "statusCode",
            "valueString" : "201"
          },
          {
            "url" : "description",
            "valueString" : "Resource created"
          }],
          "url" : "https://gematik.de/fhir/ti/StructureDefinition/extension-http-response-info"
        },
        {
          "extension" : [{
            "url" : "statusCode",
            "valueString" : "404"
          },
          {
            "url" : "description",
            "valueString" : "Unknown resource type"
          },
          {
            "url" : "responseType",
            "valueString" : "TIFlowOperationOutcome"
          },
          {
            "url" : "errorCode",
            "valueString" : "MSG_UNKNOWN_TYPE"
          }],
          "url" : "https://gematik.de/fhir/ti/StructureDefinition/extension-http-response-info"
        }],
        "code" : "create"
      },
      {
        "extension" : [{
          "url" : "http://hl7.org/fhir/StructureDefinition/capabilitystatement-expectation",
          "valueCode" : "SHALL"
        },
        {
          "extension" : [{
            "url" : "statusCode",
            "valueString" : "400"
          },
          {
            "url" : "description",
            "valueString" : "Invalid request"
          },
          {
            "url" : "responseType",
            "valueString" : "TIFlowOperationOutcome"
          },
          {
            "url" : "errorCode",
            "valueString" : "MSG_BAD_FORMAT"
          }],
          "url" : "https://gematik.de/fhir/ti/StructureDefinition/extension-http-response-info"
        },
        {
          "extension" : [{
            "url" : "statusCode",
            "valueString" : "408"
          },
          {
            "url" : "description",
            "valueString" : "Timeout"
          },
          {
            "url" : "responseType",
            "valueString" : "TIFlowOperationOutcome"
          },
          {
            "url" : "errorCode",
            "valueString" : "TIFLOW_TIMEOUT"
          }],
          "url" : "https://gematik.de/fhir/ti/StructureDefinition/extension-http-response-info"
        },
        {
          "extension" : [{
            "url" : "statusCode",
            "valueString" : "500"
          },
          {
            "url" : "description",
            "valueString" : "Internal Server Error"
          },
          {
            "url" : "responseType",
            "valueString" : "TIFlowOperationOutcome"
          },
          {
            "url" : "errorCode",
            "valueString" : "TIFLOW_INTERNAL_ERROR"
          }],
          "url" : "https://gematik.de/fhir/ti/StructureDefinition/extension-http-response-info"
        },
        {
          "extension" : [{
            "url" : "statusCode",
            "valueString" : "204"
          },
          {
            "url" : "description",
            "valueString" : "Successful operation without response body"
          }],
          "url" : "https://gematik.de/fhir/ti/StructureDefinition/extension-http-response-info"
        },
        {
          "extension" : [{
            "url" : "statusCode",
            "valueString" : "404"
          },
          {
            "url" : "description",
            "valueString" : "Unknown resource type"
          },
          {
            "url" : "responseType",
            "valueString" : "TIFlowOperationOutcome"
          },
          {
            "url" : "errorCode",
            "valueString" : "MSG_UNKNOWN_TYPE"
          }],
          "url" : "https://gematik.de/fhir/ti/StructureDefinition/extension-http-response-info"
        },
        {
          "extension" : [{
            "url" : "statusCode",
            "valueString" : "404"
          },
          {
            "url" : "description",
            "valueString" : "Resource is not known"
          },
          {
            "url" : "responseType",
            "valueString" : "TIFlowOperationOutcome"
          },
          {
            "url" : "errorCode",
            "valueString" : "MSG_RESOURCE_ID_FAIL"
          }],
          "url" : "https://gematik.de/fhir/ti/StructureDefinition/extension-http-response-info"
        },
        {
          "extension" : [{
            "url" : "statusCode",
            "valueString" : "410"
          },
          {
            "url" : "description",
            "valueString" : "Resource was deleted"
          },
          {
            "url" : "responseType",
            "valueString" : "TIFlowOperationOutcome"
          },
          {
            "url" : "errorCode",
            "valueString" : "MSG_DELETED"
          }],
          "url" : "https://gematik.de/fhir/ti/StructureDefinition/extension-http-response-info"
        }],
        "code" : "delete"
      }],
      "versioning" : "versioned-update",
      "readHistory" : true,
      "searchParam" : [{
        "extension" : [{
          "url" : "http://hl7.org/fhir/StructureDefinition/capabilitystatement-expectation",
          "valueCode" : "SHALL"
        }],
        "name" : "category",
        "definition" : "http://hl7.org/fhir/SearchParameter/Consent-category",
        "type" : "token",
        "documentation" : "Consent.category - Unterstützt die Suche nach der Art der Einwilligung"
      }]
    }],
    "operation" : [{
      "extension" : [{
        "url" : "http://hl7.org/fhir/StructureDefinition/capabilitystatement-expectation",
        "valueCode" : "SHALL"
      },
      {
        "extension" : [{
          "url" : "statusCode",
          "valueString" : "200"
        },
        {
          "url" : "description",
          "valueString" : "Successful operation"
        },
        {
          "url" : "responseType",
          "valueString" : "Parameters"
        }],
        "url" : "https://gematik.de/fhir/ti/StructureDefinition/extension-http-response-info"
      },
      {
        "extension" : [{
          "url" : "statusCode",
          "valueString" : "400"
        },
        {
          "url" : "description",
          "valueString" : "Invalid request"
        },
        {
          "url" : "responseType",
          "valueString" : "TIFlowOperationOutcome"
        },
        {
          "url" : "errorCode",
          "valueString" : "MSG_BAD_FORMAT"
        }],
        "url" : "https://gematik.de/fhir/ti/StructureDefinition/extension-http-response-info"
      },
      {
        "extension" : [{
          "url" : "statusCode",
          "valueString" : "400"
        },
        {
          "url" : "description",
          "valueString" : "Access code invalid"
        },
        {
          "url" : "responseType",
          "valueString" : "TIFlowOperationOutcome"
        },
        {
          "url" : "errorCode",
          "valueString" : "TIFLOW_ACCESS_CODE_INVALID"
        }],
        "url" : "https://gematik.de/fhir/ti/StructureDefinition/extension-http-response-info"
      },
      {
        "extension" : [{
          "url" : "statusCode",
          "valueString" : "403"
        },
        {
          "url" : "description",
          "valueString" : "Consent required"
        },
        {
          "url" : "responseType",
          "valueString" : "TIFlowOperationOutcome"
        },
        {
          "url" : "errorCode",
          "valueString" : "TIFLOW_CONSENT_REQUIRED"
        }],
        "url" : "https://gematik.de/fhir/ti/StructureDefinition/extension-http-response-info"
      },
      {
        "extension" : [{
          "url" : "statusCode",
          "valueString" : "409"
        },
        {
          "url" : "description",
          "valueString" : "Country code invalid"
        },
        {
          "url" : "responseType",
          "valueString" : "TIFlowOperationOutcome"
        },
        {
          "url" : "errorCode",
          "valueString" : "TIFLOW_XBORDER_COUNTRY_CODE_INVALID"
        }],
        "url" : "https://gematik.de/fhir/ti/StructureDefinition/extension-http-response-info"
      },
      {
        "extension" : [{
          "url" : "statusCode",
          "valueString" : "403"
        },
        {
          "url" : "description",
          "valueString" : "Access role not allowed"
        },
        {
          "url" : "responseType",
          "valueString" : "TIFlowOperationOutcome"
        },
        {
          "url" : "errorCode",
          "valueString" : "TIFLOW_AUTH_ROLE_NOT_ALLOWED"
        }],
        "url" : "https://gematik.de/fhir/ti/StructureDefinition/extension-http-response-info"
      }],
      "name" : "grant-eu-access-permission",
      "definition" : "https://gematik.de/fhir/tiflow-erezept/OperationDefinition/GrantEUAccessPermission",
      "documentation" : "Registers access code and country for EU prescription access"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/StructureDefinition/capabilitystatement-expectation",
        "valueCode" : "SHALL"
      },
      {
        "extension" : [{
          "url" : "statusCode",
          "valueString" : "200"
        },
        {
          "url" : "description",
          "valueString" : "Successful operation"
        },
        {
          "url" : "responseType",
          "valueString" : "Parameters"
        }],
        "url" : "https://gematik.de/fhir/ti/StructureDefinition/extension-http-response-info"
      },
      {
        "extension" : [{
          "url" : "statusCode",
          "valueString" : "400"
        },
        {
          "url" : "description",
          "valueString" : "Invalid request"
        },
        {
          "url" : "responseType",
          "valueString" : "TIFlowOperationOutcome"
        },
        {
          "url" : "errorCode",
          "valueString" : "MSG_BAD_FORMAT"
        }],
        "url" : "https://gematik.de/fhir/ti/StructureDefinition/extension-http-response-info"
      },
      {
        "extension" : [{
          "url" : "statusCode",
          "valueString" : "403"
        },
        {
          "url" : "description",
          "valueString" : "Access role not allowed"
        },
        {
          "url" : "responseType",
          "valueString" : "TIFlowOperationOutcome"
        },
        {
          "url" : "errorCode",
          "valueString" : "TIFLOW_AUTH_ROLE_NOT_ALLOWED"
        }],
        "url" : "https://gematik.de/fhir/ti/StructureDefinition/extension-http-response-info"
      }],
      "name" : "read-eu-access-permission",
      "definition" : "https://gematik.de/fhir/tiflow-erezept/OperationDefinition/ReadEUAccessPermission",
      "documentation" : "Reads the currently registered EU access code"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/StructureDefinition/capabilitystatement-expectation",
        "valueCode" : "SHALL"
      },
      {
        "extension" : [{
          "url" : "statusCode",
          "valueString" : "200"
        },
        {
          "url" : "description",
          "valueString" : "Successful operation"
        }],
        "url" : "https://gematik.de/fhir/ti/StructureDefinition/extension-http-response-info"
      },
      {
        "extension" : [{
          "url" : "statusCode",
          "valueString" : "400"
        },
        {
          "url" : "description",
          "valueString" : "Invalid request"
        },
        {
          "url" : "responseType",
          "valueString" : "TIFlowOperationOutcome"
        },
        {
          "url" : "errorCode",
          "valueString" : "MSG_BAD_FORMAT"
        }],
        "url" : "https://gematik.de/fhir/ti/StructureDefinition/extension-http-response-info"
      },
      {
        "extension" : [{
          "url" : "statusCode",
          "valueString" : "403"
        },
        {
          "url" : "description",
          "valueString" : "Access role not allowed"
        },
        {
          "url" : "responseType",
          "valueString" : "TIFlowOperationOutcome"
        },
        {
          "url" : "errorCode",
          "valueString" : "TIFLOW_AUTH_ROLE_NOT_ALLOWED"
        }],
        "url" : "https://gematik.de/fhir/ti/StructureDefinition/extension-http-response-info"
      }],
      "name" : "revoke-eu-access-permission",
      "definition" : "https://gematik.de/fhir/tiflow-erezept/OperationDefinition/RevokeEUAccessPermission",
      "documentation" : "Revokes the currently registered EU access code"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/StructureDefinition/capabilitystatement-expectation",
        "valueCode" : "SHALL"
      },
      {
        "extension" : [{
          "url" : "statusCode",
          "valueString" : "200"
        },
        {
          "url" : "description",
          "valueString" : "Successful operation"
        },
        {
          "url" : "responseType",
          "valueString" : "Parameters"
        }],
        "url" : "https://gematik.de/fhir/ti/StructureDefinition/extension-http-response-info"
      },
      {
        "extension" : [{
          "url" : "statusCode",
          "valueString" : "400"
        },
        {
          "url" : "description",
          "valueString" : "Invalid request"
        },
        {
          "url" : "responseType",
          "valueString" : "TIFlowOperationOutcome"
        },
        {
          "url" : "errorCode",
          "valueString" : "MSG_BAD_FORMAT"
        }],
        "url" : "https://gematik.de/fhir/ti/StructureDefinition/extension-http-response-info"
      },
      {
        "extension" : [{
          "url" : "statusCode",
          "valueString" : "400"
        },
        {
          "url" : "description",
          "valueString" : "FHIR Profile Validation Failed"
        },
        {
          "url" : "responseType",
          "valueString" : "TIFlowOperationOutcome"
        },
        {
          "url" : "errorCode",
          "valueString" : "SVC_VALIDATION_FAILED"
        }],
        "url" : "https://gematik.de/fhir/ti/StructureDefinition/extension-http-response-info"
      },
      {
        "extension" : [{
          "url" : "statusCode",
          "valueString" : "403"
        },
        {
          "url" : "description",
          "valueString" : "Access permission invalid"
        },
        {
          "url" : "responseType",
          "valueString" : "TIFlowOperationOutcome"
        },
        {
          "url" : "errorCode",
          "valueString" : "TIFLOW_ACCESS_PERMISSION_INVALID"
        }],
        "url" : "https://gematik.de/fhir/ti/StructureDefinition/extension-http-response-info"
      },
      {
        "extension" : [{
          "url" : "statusCode",
          "valueString" : "403"
        },
        {
          "url" : "description",
          "valueString" : "Access role not allowed"
        },
        {
          "url" : "responseType",
          "valueString" : "TIFlowOperationOutcome"
        },
        {
          "url" : "errorCode",
          "valueString" : "TIFLOW_AUTH_ROLE_NOT_ALLOWED"
        }],
        "url" : "https://gematik.de/fhir/ti/StructureDefinition/extension-http-response-info"
      },
      {
        "extension" : [{
          "url" : "statusCode",
          "valueString" : "403"
        },
        {
          "url" : "description",
          "valueString" : "Consent required"
        },
        {
          "url" : "responseType",
          "valueString" : "TIFlowOperationOutcome"
        },
        {
          "url" : "errorCode",
          "valueString" : "TIFLOW_CONSENT_REQUIRED"
        }],
        "url" : "https://gematik.de/fhir/ti/StructureDefinition/extension-http-response-info"
      },
      {
        "extension" : [{
          "url" : "statusCode",
          "valueString" : "404"
        },
        {
          "url" : "description",
          "valueString" : "No prescriptions found"
        },
        {
          "url" : "responseType",
          "valueString" : "TIFlowOperationOutcome"
        },
        {
          "url" : "errorCode",
          "valueString" : "TIFLOW_XBORDER_NO_PRESCRIPTIONS_FOUND"
        }],
        "url" : "https://gematik.de/fhir/ti/StructureDefinition/extension-http-response-info"
      }],
      "name" : "get-eu-prescriptions",
      "definition" : "https://gematik.de/fhir/tiflow-erezept/OperationDefinition/GETPrescriptionEU",
      "documentation" : "Returns prescription information for EU ePrescription workflows"
    }]
  }]
}

```
