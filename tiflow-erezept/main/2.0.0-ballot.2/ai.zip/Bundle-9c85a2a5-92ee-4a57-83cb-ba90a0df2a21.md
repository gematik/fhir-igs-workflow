# 9c85a2a5-92ee-4a57-83cb-ba90a0df2a21 - Implementation Guide TIFlow - Verordnungen für Arzneimittel v2.0.0-ballot.2

Implementation Guide

TIFlow - Verordnungen für Arzneimittel

Version 2.0.0-ballot.2 - ballot 

* [**Table of Contents**](toc.md)
* [**FHIR-Artefakte**](artifacts.md)
* **9c85a2a5-92ee-4a57-83cb-ba90a0df2a21**

## Bundle: 9c85a2a5-92ee-4a57-83cb-ba90a0df2a21



## Resource Content

```json
{
  "resourceType" : "Bundle",
  "id" : "9c85a2a5-92ee-4a57-83cb-ba90a0df2a21",
  "meta" : {
    "profile" : ["https://fhir.kbv.de/StructureDefinition/KBV_PR_ERP_Bundle|1.3"]
  },
  "identifier" : {
    "system" : "https://gematik.de/fhir/erp/NamingSystem/GEM_ERP_NS_PrescriptionId",
    "value" : "160.100.000.000.019.82"
  },
  "type" : "document",
  "timestamp" : "2024-05-20T08:30:00+00:00",
  "entry" : [{
    "fullUrl" : "http://pvs.praxis.local/fhir/Composition/4ca03203-b01b-4b4c-aeac-c36adb30ea34",
    "resource" : {
      "resourceType" : "Composition",
      "id" : "4ca03203-b01b-4b4c-aeac-c36adb30ea34",
      "meta" : {
        "profile" : ["https://fhir.kbv.de/StructureDefinition/KBV_PR_ERP_Composition|1.3"]
      },
      "extension" : [{
        "url" : "https://fhir.kbv.de/StructureDefinition/KBV_EX_FOR_Legal_basis",
        "valueCoding" : {
          "system" : "https://fhir.kbv.de/CodeSystem/KBV_CS_SFHIR_KBV_STATUSKENNZEICHEN",
          "code" : "00"
        }
      }],
      "status" : "final",
      "type" : {
        "coding" : [{
          "system" : "https://fhir.kbv.de/CodeSystem/KBV_CS_SFHIR_KBV_FORMULAR_ART",
          "code" : "e16A"
        }]
      },
      "subject" : {
        "reference" : "Patient/ce4104af-b86b-4664-afee-1b5fc3ac8acf"
      },
      "date" : "2024-05-20T08:00:00Z",
      "author" : [{
        "reference" : "Practitioner/bc329f24-3d65-4286-bf06-b54dd6cad655",
        "type" : "Practitioner"
      },
      {
        "type" : "Device",
        "identifier" : {
          "system" : "https://fhir.kbv.de/NamingSystem/KBV_NS_FOR_Pruefnummer",
          "value" : "Y/400/2107/36/999"
        }
      }],
      "title" : "elektronische Arzneimittelverordnung",
      "custodian" : {
        "reference" : "Organization/5d3f4ac0-2b44-4d48-b363-e63efa72973b"
      },
      "section" : [{
        "code" : {
          "coding" : [{
            "system" : "https://fhir.kbv.de/CodeSystem/KBV_CS_ERP_Section_Type",
            "code" : "Prescription"
          }]
        },
        "entry" : [{
          "reference" : "MedicationRequest/4a7eefdd-df71-4a72-8047-c158017534a1"
        }]
      },
      {
        "code" : {
          "coding" : [{
            "system" : "https://fhir.kbv.de/CodeSystem/KBV_CS_ERP_Section_Type",
            "code" : "Coverage"
          }]
        },
        "entry" : [{
          "reference" : "Coverage/da80211e-61ee-458e-a651-87370b6ec30c"
        }]
      }]
    }
  },
  {
    "fullUrl" : "http://pvs.praxis.local/fhir/MedicationRequest/4a7eefdd-df71-4a72-8047-c158017534a1",
    "resource" : {
      "resourceType" : "MedicationRequest",
      "id" : "4a7eefdd-df71-4a72-8047-c158017534a1",
      "meta" : {
        "profile" : ["https://fhir.kbv.de/StructureDefinition/KBV_PR_ERP_Prescription|1.3"]
      },
      "extension" : [{
        "url" : "https://fhir.kbv.de/StructureDefinition/KBV_EX_FOR_StatusCoPayment",
        "valueCoding" : {
          "system" : "https://fhir.kbv.de/CodeSystem/KBV_CS_FOR_StatusCoPayment",
          "code" : "0"
        }
      },
      {
        "url" : "https://fhir.kbv.de/StructureDefinition/KBV_EX_ERP_EmergencyServicesFee",
        "valueBoolean" : false
      },
      {
        "url" : "https://fhir.kbv.de/StructureDefinition/KBV_EX_FOR_SER",
        "valueBoolean" : false
      },
      {
        "extension" : [{
          "url" : "Kennzeichen",
          "valueBoolean" : false
        }],
        "url" : "https://fhir.kbv.de/StructureDefinition/KBV_EX_ERP_Multiple_Prescription"
      }],
      "status" : "active",
      "intent" : "order",
      "medicationReference" : {
        "reference" : "Medication/86fa62c7-06a0-418e-ba26-e99baa053c07"
      },
      "subject" : {
        "reference" : "Patient/ce4104af-b86b-4664-afee-1b5fc3ac8acf"
      },
      "authoredOn" : "2024-05-20",
      "requester" : {
        "reference" : "Practitioner/bc329f24-3d65-4286-bf06-b54dd6cad655"
      },
      "insurance" : [{
        "reference" : "Coverage/da80211e-61ee-458e-a651-87370b6ec30c"
      }],
      "note" : [{
        "text" : "Bitte längliche Tabletten, da Patient Probleme mit dem Schlucken von runden hat."
      }],
      "dosageInstruction" : [{
        "extension" : [{
          "url" : "https://fhir.kbv.de/StructureDefinition/KBV_EX_ERP_DosageFlag",
          "valueBoolean" : true
        }],
        "text" : "1-0-0-0"
      }],
      "dispenseRequest" : {
        "quantity" : {
          "value" : 1,
          "unit" : "Packung"
        }
      }
    }
  },
  {
    "fullUrl" : "http://pvs.praxis.local/fhir/Medication/86fa62c7-06a0-418e-ba26-e99baa053c07",
    "resource" : {
      "resourceType" : "Medication",
      "id" : "86fa62c7-06a0-418e-ba26-e99baa053c07",
      "meta" : {
        "profile" : ["https://fhir.kbv.de/StructureDefinition/KBV_PR_ERP_Medication_Ingredient|1.3"]
      },
      "extension" : [{
        "url" : "https://fhir.kbv.de/StructureDefinition/KBV_EX_ERP_Medication_Vaccine",
        "valueBoolean" : false
      },
      {
        "url" : "https://fhir.kbv.de/StructureDefinition/KBV_EX_ERP_Medication_Category",
        "valueCoding" : {
          "system" : "https://fhir.kbv.de/CodeSystem/KBV_CS_ERP_Medication_Category",
          "code" : "00"
        }
      },
      {
        "url" : "http://fhir.de/StructureDefinition/normgroesse",
        "valueCode" : "N3"
      }],
      "code" : {
        "coding" : [{
          "system" : "https://fhir.kbv.de/CodeSystem/KBV_CS_ERP_Medication_Type",
          "code" : "wirkstoff"
        }]
      },
      "form" : {
        "text" : "Tabletten"
      },
      "amount" : {
        "numerator" : {
          "extension" : [{
            "url" : "https://fhir.kbv.de/StructureDefinition/KBV_EX_ERP_Medication_PackagingSize",
            "valueString" : "100"
          }],
          "unit" : "Stück"
        },
        "denominator" : {
          "value" : 1
        }
      },
      "ingredient" : [{
        "itemCodeableConcept" : {
          "coding" : [{
            "system" : "http://fhir.de/CodeSystem/ask",
            "code" : "22686"
          }],
          "text" : "Ramipril"
        },
        "strength" : {
          "numerator" : {
            "value" : 5,
            "unit" : "mg"
          },
          "denominator" : {
            "value" : 1,
            "unit" : "Stück"
          }
        }
      }]
    }
  },
  {
    "fullUrl" : "http://pvs.praxis.local/fhir/Patient/ce4104af-b86b-4664-afee-1b5fc3ac8acf",
    "resource" : {
      "resourceType" : "Patient",
      "id" : "ce4104af-b86b-4664-afee-1b5fc3ac8acf",
      "meta" : {
        "profile" : ["https://fhir.kbv.de/StructureDefinition/KBV_PR_FOR_Patient|1.2"]
      },
      "identifier" : [{
        "type" : {
          "coding" : [{
            "system" : "http://fhir.de/CodeSystem/identifier-type-de-basis",
            "code" : "KVZ10"
          }]
        },
        "system" : "http://fhir.de/sid/gkv/kvid-10",
        "value" : "K030182229"
      }],
      "name" : [{
        "use" : "official",
        "family" : "Kluge",
        "_family" : {
          "extension" : [{
            "url" : "http://hl7.org/fhir/StructureDefinition/humanname-own-name",
            "valueString" : "Kluge"
          }]
        },
        "given" : ["Eva"],
        "prefix" : ["Prof. Dr. Dr. med"],
        "_prefix" : [{
          "extension" : [{
            "url" : "http://hl7.org/fhir/StructureDefinition/iso21090-EN-qualifier",
            "valueCode" : "AC"
          }]
        }]
      }],
      "birthDate" : "1982-01-03",
      "address" : [{
        "type" : "both",
        "line" : ["Pflasterhofweg 111B"],
        "_line" : [{
          "extension" : [{
            "url" : "http://hl7.org/fhir/StructureDefinition/iso21090-ADXP-houseNumber",
            "valueString" : "111B"
          },
          {
            "url" : "http://hl7.org/fhir/StructureDefinition/iso21090-ADXP-streetName",
            "valueString" : "Pflasterhofweg"
          }]
        }],
        "city" : "Köln",
        "postalCode" : "50999",
        "country" : "D"
      }]
    }
  },
  {
    "fullUrl" : "http://pvs.praxis.local/fhir/Practitioner/bc329f24-3d65-4286-bf06-b54dd6cad655",
    "resource" : {
      "resourceType" : "Practitioner",
      "id" : "bc329f24-3d65-4286-bf06-b54dd6cad655",
      "meta" : {
        "profile" : ["https://fhir.kbv.de/StructureDefinition/KBV_PR_FOR_Practitioner|1.2"]
      },
      "identifier" : [{
        "type" : {
          "coding" : [{
            "system" : "http://terminology.hl7.org/CodeSystem/v2-0203",
            "code" : "LANR"
          }]
        },
        "system" : "https://fhir.kbv.de/NamingSystem/KBV_NS_Base_ANR",
        "value" : "123456628"
      }],
      "name" : [{
        "use" : "official",
        "family" : "Freiherr von Müller",
        "_family" : {
          "extension" : [{
            "url" : "http://hl7.org/fhir/StructureDefinition/humanname-own-prefix",
            "valueString" : "von"
          },
          {
            "url" : "http://fhir.de/StructureDefinition/humanname-namenszusatz",
            "valueString" : "Freiherr"
          },
          {
            "url" : "http://hl7.org/fhir/StructureDefinition/humanname-own-name",
            "valueString" : "Müller"
          }]
        },
        "given" : ["Paul"],
        "prefix" : ["Dr. med."],
        "_prefix" : [{
          "extension" : [{
            "url" : "http://hl7.org/fhir/StructureDefinition/iso21090-EN-qualifier",
            "valueCode" : "AC"
          }]
        }]
      }],
      "qualification" : [{
        "code" : {
          "coding" : [{
            "system" : "https://fhir.kbv.de/CodeSystem/KBV_CS_FOR_Qualification_Type",
            "code" : "00"
          }]
        }
      },
      {
        "code" : {
          "coding" : [{
            "system" : "https://fhir.kbv.de/CodeSystem/KBV_CS_FOR_Berufsbezeichnung",
            "code" : "Berufsbezeichnung"
          }],
          "text" : "Facharzt für Innere Medizin: Kardiologie"
        }
      }]
    }
  },
  {
    "fullUrl" : "http://pvs.praxis.local/fhir/Organization/5d3f4ac0-2b44-4d48-b363-e63efa72973b",
    "resource" : {
      "resourceType" : "Organization",
      "id" : "5d3f4ac0-2b44-4d48-b363-e63efa72973b",
      "meta" : {
        "profile" : ["https://fhir.kbv.de/StructureDefinition/KBV_PR_FOR_Organization|1.2"]
      },
      "identifier" : [{
        "type" : {
          "coding" : [{
            "system" : "http://terminology.hl7.org/CodeSystem/v2-0203",
            "code" : "BSNR"
          }]
        },
        "system" : "https://fhir.kbv.de/NamingSystem/KBV_NS_Base_BSNR",
        "value" : "721111100"
      }],
      "name" : "MVZ",
      "telecom" : [{
        "system" : "phone",
        "value" : "0301234567"
      },
      {
        "system" : "fax",
        "value" : "030123456789"
      },
      {
        "system" : "email",
        "value" : "mvz@e-mail.de"
      }],
      "address" : [{
        "type" : "both",
        "line" : ["Herbert-Lewin-Platz 2"],
        "_line" : [{
          "extension" : [{
            "url" : "http://hl7.org/fhir/StructureDefinition/iso21090-ADXP-houseNumber",
            "valueString" : "2"
          },
          {
            "url" : "http://hl7.org/fhir/StructureDefinition/iso21090-ADXP-streetName",
            "valueString" : "Herbert-Lewin-Platz"
          }]
        }],
        "city" : "Berlin",
        "postalCode" : "10623",
        "country" : "D"
      }]
    }
  },
  {
    "fullUrl" : "http://pvs.praxis.local/fhir/Coverage/da80211e-61ee-458e-a651-87370b6ec30c",
    "resource" : {
      "resourceType" : "Coverage",
      "id" : "da80211e-61ee-458e-a651-87370b6ec30c",
      "meta" : {
        "profile" : ["https://fhir.kbv.de/StructureDefinition/KBV_PR_FOR_Coverage|1.2"]
      },
      "extension" : [{
        "url" : "http://fhir.de/StructureDefinition/gkv/besondere-personengruppe",
        "valueCoding" : {
          "system" : "https://fhir.kbv.de/CodeSystem/KBV_CS_SFHIR_KBV_PERSONENGRUPPE",
          "code" : "00"
        }
      },
      {
        "url" : "http://fhir.de/StructureDefinition/gkv/dmp-kennzeichen",
        "valueCoding" : {
          "system" : "https://fhir.kbv.de/CodeSystem/KBV_CS_SFHIR_KBV_DMP",
          "code" : "00"
        }
      },
      {
        "url" : "http://fhir.de/StructureDefinition/gkv/wop",
        "valueCoding" : {
          "system" : "https://fhir.kbv.de/CodeSystem/KBV_CS_SFHIR_ITA_WOP",
          "code" : "38"
        }
      },
      {
        "url" : "http://fhir.de/StructureDefinition/gkv/versichertenart",
        "valueCoding" : {
          "system" : "https://fhir.kbv.de/CodeSystem/KBV_CS_SFHIR_KBV_VERSICHERTENSTATUS",
          "code" : "3"
        }
      }],
      "status" : "active",
      "type" : {
        "coding" : [{
          "system" : "http://fhir.de/CodeSystem/versicherungsart-de-basis",
          "code" : "GKV"
        }]
      },
      "beneficiary" : {
        "reference" : "Patient/ce4104af-b86b-4664-afee-1b5fc3ac8acf"
      },
      "payor" : [{
        "identifier" : {
          "system" : "http://fhir.de/sid/arge-ik/iknr",
          "value" : "109777509"
        },
        "display" : "Techniker Krankenkasse"
      }]
    }
  }]
}

```
