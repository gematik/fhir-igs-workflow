# Operation API - Implementation Guide TIFlow - Verordnungen für Arzneimittel v2.0.0-ballot.2

Implementation Guide

TIFlow - Verordnungen für Arzneimittel

Version 2.0.0-ballot.2 - ballot 

* [**Table of Contents**](toc.md)
* **Operation API**

## Operation API

Die folgenden Operation APIs stellt der TI-Flow-Fachdienst dem **Primärsystem eRP** sowie dem **TI-Flow-Fachdienst** zur Verfügung.

### E-Rezepte bereitstellen

* Primärsystem: [Operation API: E-Rezept erstellen](./op-create.md)
* Primärsystem: [Operation API: E-Rezept aktivieren](./op-activate.md)
* Primärsystem / E-Rezept-FdV: [Operation API: E-Rezept löschen](./op-abort.md)

### E-Rezepte beliefern

* Primärsystem: [Operation API: Task abrufen](./op-accept.md)
* Primärsystem: [Operation API: Task zurückweisen](./op-reject.md)
* Primärsystem: [Operation API: Dispensierinformationen bereitstellen](./op-dispense.md)
* Primärsystem: [Operation API: Task schließen](./op-close.md)

