# Logical Medication Dispense - TIFlow - Verordnungen für Arzneimittel v0.9.0

TIFlow - Verordnungen für Arzneimittel

Version 0.9.0 - ci-build 

* [**Table of Contents**](toc.md)
* [**FHIR-Artefakte**](artifacts.md)
* **Logical Medication Dispense**

## Logical Model: Logical Medication Dispense 

| | |
| :--- | :--- |
| *Official URL*:https://gematik.de/fhir/tiflow/erezept/StructureDefinition/GEM-ERP-LOG-MedicationDispense | *Version*:0.9.0 |
| Draft as of 2025-12-15 | *Computable Name*:GEM_ERP_LOG_MedicationDispense |
| **Copyright/Legal**: gematik GmbH / Dieses Artefakt ist lizenziert unter [Apache License](./license.md), Version 2.0. | |

 
Fachliches Modell zur Beschreibung der Informationen, die bei $close und $dispense in der MedicationDispense-Ressource übermittelt werden. 

**Usages:**

* This Logical Model is not used by any profiles in this Implementation Guide

You can also check for [usages in the FHIR IG Statistics](https://packages2.fhir.org/xig/de.gematik.tiflow.erezept|current/StructureDefinition/GEM-ERP-LOG-MedicationDispense)

### Formal Views of Profile Content

 [Description of Profiles, Differentials, Snapshots and how the different presentations work](http://build.fhir.org/ig/FHIR/ig-guidance/readingIgs.html#structure-definitions). 

 

Other representations of profile: [CSV](StructureDefinition-GEM-ERP-LOG-MedicationDispense.csv), [Excel](StructureDefinition-GEM-ERP-LOG-MedicationDispense.xlsx) 



## Resource Content

```json
{
  "resourceType" : "StructureDefinition",
  "id" : "GEM-ERP-LOG-MedicationDispense",
  "url" : "https://gematik.de/fhir/tiflow/erezept/StructureDefinition/GEM-ERP-LOG-MedicationDispense",
  "version" : "0.9.0",
  "name" : "GEM_ERP_LOG_MedicationDispense",
  "title" : "Logical Medication Dispense",
  "status" : "draft",
  "experimental" : false,
  "date" : "2025-12-15",
  "publisher" : "gematik GmbH",
  "contact" : [{
    "name" : "gematik GmbH",
    "telecom" : [{
      "system" : "url",
      "value" : "https://gematik.de"
    },
    {
      "system" : "email",
      "value" : "erp-umsetzung@gematik.de"
    }]
  }],
  "description" : "Fachliches Modell zur Beschreibung der Informationen, die bei $close und $dispense in der MedicationDispense-Ressource übermittelt werden.",
  "jurisdiction" : [{
    "coding" : [{
      "system" : "urn:iso:std:iso:3166",
      "code" : "DE",
      "display" : "Germany"
    }]
  }],
  "copyright" : "gematik GmbH / Dieses Artefakt ist lizenziert unter [Apache License](./license.html), Version 2.0.",
  "fhirVersion" : "4.0.1",
  "mapping" : [{
    "identity" : "rim",
    "uri" : "http://hl7.org/v3",
    "name" : "RIM Mapping"
  }],
  "kind" : "logical",
  "abstract" : false,
  "type" : "https://gematik.de/fhir/tiflow/erezept/StructureDefinition/GEM-ERP-LOG-MedicationDispense",
  "baseDefinition" : "http://hl7.org/fhir/StructureDefinition/Element",
  "derivation" : "specialization",
  "differential" : {
    "element" : [{
      "id" : "GEM-ERP-LOG-MedicationDispense",
      "path" : "GEM-ERP-LOG-MedicationDispense",
      "short" : "Logical Medication Dispense",
      "definition" : "Fachliches Modell zur Beschreibung der Informationen, die bei $close und $dispense in der MedicationDispense-Ressource übermittelt werden."
    },
    {
      "id" : "GEM-ERP-LOG-MedicationDispense.prescriptionId",
      "path" : "GEM-ERP-LOG-MedicationDispense.prescriptionId",
      "short" : "ID des Rezepts",
      "definition" : "ID des Rezepts",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "GEM-ERP-LOG-MedicationDispense.status",
      "path" : "GEM-ERP-LOG-MedicationDispense.status",
      "short" : "Status fixedValue: #completed",
      "definition" : "Status fixedValue: #completed",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "code"
      }]
    },
    {
      "id" : "GEM-ERP-LOG-MedicationDispense.medication",
      "path" : "GEM-ERP-LOG-MedicationDispense.medication",
      "short" : "Medikation",
      "definition" : "Medikation",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "BackboneElement"
      }]
    },
    {
      "id" : "GEM-ERP-LOG-MedicationDispense.medication.medicationArzneimittel",
      "path" : "GEM-ERP-LOG-MedicationDispense.medication.medicationArzneimittel",
      "short" : "Medikation als contained Element",
      "definition" : "Medikation als contained Element",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "BackboneElement"
      }]
    },
    {
      "id" : "GEM-ERP-LOG-MedicationDispense.medication.medicationArzneimittel.extension",
      "path" : "GEM-ERP-LOG-MedicationDispense.medication.medicationArzneimittel.extension",
      "short" : "Erweiterungen",
      "definition" : "Erweiterungen",
      "min" : 0,
      "max" : "*",
      "type" : [{
        "code" : "Extension"
      }]
    },
    {
      "id" : "GEM-ERP-LOG-MedicationDispense.medication.medicationArzneimittel.extension.impfung",
      "path" : "GEM-ERP-LOG-MedicationDispense.medication.medicationArzneimittel.extension.impfung",
      "short" : "Angabe ob Impfstoff nach KBV_EX_ERP_Medication_Vaccine",
      "definition" : "Angabe ob Impfstoff nach KBV_EX_ERP_Medication_Vaccine",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "boolean"
      }]
    },
    {
      "id" : "GEM-ERP-LOG-MedicationDispense.medication.medicationArzneimittel.extension.arzneimittelkategorie",
      "path" : "GEM-ERP-LOG-MedicationDispense.medication.medicationArzneimittel.extension.arzneimittelkategorie",
      "short" : "Arzneimittelkategorie aus KBV_EX_ERP_Medication_Category",
      "definition" : "Arzneimittelkategorie aus KBV_EX_ERP_Medication_Category",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "code"
      }]
    },
    {
      "id" : "GEM-ERP-LOG-MedicationDispense.medication.medicationArzneimittel.extension.kategorie",
      "path" : "GEM-ERP-LOG-MedicationDispense.medication.medicationArzneimittel.extension.kategorie",
      "short" : "Angabe zur Kategorie",
      "definition" : "Angabe zur Kategorie",
      "comment" : "Muss angegeben werden, wenn vorhanden",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "GEM-ERP-LOG-MedicationDispense.medication.medicationArzneimittel.extension.normgroesse",
      "path" : "GEM-ERP-LOG-MedicationDispense.medication.medicationArzneimittel.extension.normgroesse",
      "short" : "Angabe der Normgröße nach KBV_VS_SFHIR_KBV_NORMGROESSE",
      "definition" : "Angabe der Normgröße nach KBV_VS_SFHIR_KBV_NORMGROESSE",
      "comment" : "Muss angegeben werden, wenn vorhanden",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "code"
      }]
    },
    {
      "id" : "GEM-ERP-LOG-MedicationDispense.medication.medicationArzneimittel.extension.herstellungsanweisung",
      "path" : "GEM-ERP-LOG-MedicationDispense.medication.medicationArzneimittel.extension.herstellungsanweisung",
      "short" : "Herstellungsanweisung",
      "definition" : "Herstellungsanweisung",
      "comment" : "Muss angegeben werden, wenn vorhanden",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "GEM-ERP-LOG-MedicationDispense.medication.medicationArzneimittel.extension.verpackung",
      "path" : "GEM-ERP-LOG-MedicationDispense.medication.medicationArzneimittel.extension.verpackung",
      "short" : "Angabe zur Verpackung",
      "definition" : "Angabe zur Verpackung",
      "comment" : "Muss angegeben werden, wenn vorhanden",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "GEM-ERP-LOG-MedicationDispense.medication.medicationArzneimittel.code",
      "path" : "GEM-ERP-LOG-MedicationDispense.medication.medicationArzneimittel.code",
      "short" : "Information und Identifizierung zum Arzneimittel",
      "definition" : "Information und Identifizierung zum Arzneimittel",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "CodeableConcept"
      }]
    },
    {
      "id" : "GEM-ERP-LOG-MedicationDispense.medication.medicationArzneimittel.code.pzn",
      "path" : "GEM-ERP-LOG-MedicationDispense.medication.medicationArzneimittel.code.pzn",
      "short" : "PZN",
      "definition" : "PZN",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "Coding"
      }]
    },
    {
      "id" : "GEM-ERP-LOG-MedicationDispense.medication.medicationArzneimittel.code.pzn.code",
      "path" : "GEM-ERP-LOG-MedicationDispense.medication.medicationArzneimittel.code.pzn.code",
      "short" : "PZN-Code",
      "definition" : "PZN-Code",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "code"
      }]
    },
    {
      "id" : "GEM-ERP-LOG-MedicationDispense.medication.medicationArzneimittel.code.pzn.display",
      "path" : "GEM-ERP-LOG-MedicationDispense.medication.medicationArzneimittel.code.pzn.display",
      "short" : "PZN-Name",
      "definition" : "PZN-Name",
      "comment" : "Muss angegeben werden, wenn vorhanden",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "GEM-ERP-LOG-MedicationDispense.medication.medicationArzneimittel.code.atcDe",
      "path" : "GEM-ERP-LOG-MedicationDispense.medication.medicationArzneimittel.code.atcDe",
      "short" : "atc-de",
      "definition" : "atc-de",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "Coding"
      }]
    },
    {
      "id" : "GEM-ERP-LOG-MedicationDispense.medication.medicationArzneimittel.code.atcDe.code",
      "path" : "GEM-ERP-LOG-MedicationDispense.medication.medicationArzneimittel.code.atcDe.code",
      "short" : "atc-de-Code",
      "definition" : "atc-de-Code",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "code"
      }]
    },
    {
      "id" : "GEM-ERP-LOG-MedicationDispense.medication.medicationArzneimittel.code.atcDe.display",
      "path" : "GEM-ERP-LOG-MedicationDispense.medication.medicationArzneimittel.code.atcDe.display",
      "short" : "atc-de-Name",
      "definition" : "atc-de-Name",
      "comment" : "Muss angegeben werden, wenn vorhanden",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "GEM-ERP-LOG-MedicationDispense.medication.medicationArzneimittel.code.ask",
      "path" : "GEM-ERP-LOG-MedicationDispense.medication.medicationArzneimittel.code.ask",
      "short" : "ask",
      "definition" : "ask",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "Coding"
      }]
    },
    {
      "id" : "GEM-ERP-LOG-MedicationDispense.medication.medicationArzneimittel.code.ask.code",
      "path" : "GEM-ERP-LOG-MedicationDispense.medication.medicationArzneimittel.code.ask.code",
      "short" : "ask-Code",
      "definition" : "ask-Code",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "code"
      }]
    },
    {
      "id" : "GEM-ERP-LOG-MedicationDispense.medication.medicationArzneimittel.code.ask.display",
      "path" : "GEM-ERP-LOG-MedicationDispense.medication.medicationArzneimittel.code.ask.display",
      "short" : "ask-Name",
      "definition" : "ask-Name",
      "comment" : "Muss angegeben werden, wenn vorhanden",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "GEM-ERP-LOG-MedicationDispense.medication.medicationArzneimittel.code.wg14",
      "path" : "GEM-ERP-LOG-MedicationDispense.medication.medicationArzneimittel.code.wg14",
      "short" : "wg14",
      "definition" : "wg14",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "Coding"
      }]
    },
    {
      "id" : "GEM-ERP-LOG-MedicationDispense.medication.medicationArzneimittel.code.wg14.code",
      "path" : "GEM-ERP-LOG-MedicationDispense.medication.medicationArzneimittel.code.wg14.code",
      "short" : "wg14-Code",
      "definition" : "wg14-Code",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "code"
      }]
    },
    {
      "id" : "GEM-ERP-LOG-MedicationDispense.medication.medicationArzneimittel.code.wg14.display",
      "path" : "GEM-ERP-LOG-MedicationDispense.medication.medicationArzneimittel.code.wg14.display",
      "short" : "wg14-Name",
      "definition" : "wg14-Name",
      "comment" : "Muss angegeben werden, wenn vorhanden",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "GEM-ERP-LOG-MedicationDispense.medication.medicationArzneimittel.code.snomed",
      "path" : "GEM-ERP-LOG-MedicationDispense.medication.medicationArzneimittel.code.snomed",
      "short" : "snomed",
      "definition" : "snomed",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "Coding"
      }]
    },
    {
      "id" : "GEM-ERP-LOG-MedicationDispense.medication.medicationArzneimittel.code.snomed.code",
      "path" : "GEM-ERP-LOG-MedicationDispense.medication.medicationArzneimittel.code.snomed.code",
      "short" : "snomed-Code",
      "definition" : "snomed-Code",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "code"
      }]
    },
    {
      "id" : "GEM-ERP-LOG-MedicationDispense.medication.medicationArzneimittel.code.snomed.display",
      "path" : "GEM-ERP-LOG-MedicationDispense.medication.medicationArzneimittel.code.snomed.display",
      "short" : "snomed-Name",
      "definition" : "snomed-Name",
      "comment" : "Muss angegeben werden, wenn vorhanden",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "GEM-ERP-LOG-MedicationDispense.medication.medicationArzneimittel.code.text",
      "path" : "GEM-ERP-LOG-MedicationDispense.medication.medicationArzneimittel.code.text",
      "short" : "Name des Arzneimittels",
      "definition" : "Name des Arzneimittels",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "GEM-ERP-LOG-MedicationDispense.medication.medicationArzneimittel.form",
      "path" : "GEM-ERP-LOG-MedicationDispense.medication.medicationArzneimittel.form",
      "short" : "Darreichungsform",
      "definition" : "Darreichungsform",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "CodeableConcept"
      }]
    },
    {
      "id" : "GEM-ERP-LOG-MedicationDispense.medication.medicationArzneimittel.form.edqm",
      "path" : "GEM-ERP-LOG-MedicationDispense.medication.medicationArzneimittel.form.edqm",
      "short" : "edqm",
      "definition" : "edqm",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "Coding"
      }]
    },
    {
      "id" : "GEM-ERP-LOG-MedicationDispense.medication.medicationArzneimittel.form.edqm.code",
      "path" : "GEM-ERP-LOG-MedicationDispense.medication.medicationArzneimittel.form.edqm.code",
      "short" : "edqm-Code",
      "definition" : "edqm-Code",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "code"
      }]
    },
    {
      "id" : "GEM-ERP-LOG-MedicationDispense.medication.medicationArzneimittel.form.edqm.display",
      "path" : "GEM-ERP-LOG-MedicationDispense.medication.medicationArzneimittel.form.edqm.display",
      "short" : "edqm-Name",
      "definition" : "edqm-Name",
      "comment" : "Muss angegeben werden, wenn vorhanden",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "GEM-ERP-LOG-MedicationDispense.medication.medicationArzneimittel.form.snomed",
      "path" : "GEM-ERP-LOG-MedicationDispense.medication.medicationArzneimittel.form.snomed",
      "short" : "snomed",
      "definition" : "snomed",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "Coding"
      }]
    },
    {
      "id" : "GEM-ERP-LOG-MedicationDispense.medication.medicationArzneimittel.form.snomed.code",
      "path" : "GEM-ERP-LOG-MedicationDispense.medication.medicationArzneimittel.form.snomed.code",
      "short" : "snomed-Code",
      "definition" : "snomed-Code",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "code"
      }]
    },
    {
      "id" : "GEM-ERP-LOG-MedicationDispense.medication.medicationArzneimittel.form.snomed.display",
      "path" : "GEM-ERP-LOG-MedicationDispense.medication.medicationArzneimittel.form.snomed.display",
      "short" : "snomed-Name",
      "definition" : "snomed-Name",
      "comment" : "Muss angegeben werden, wenn vorhanden",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "GEM-ERP-LOG-MedicationDispense.medication.medicationArzneimittel.form.kbvDarreichungsform",
      "path" : "GEM-ERP-LOG-MedicationDispense.medication.medicationArzneimittel.form.kbvDarreichungsform",
      "short" : "kbvDarreichungsform",
      "definition" : "kbvDarreichungsform",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "Coding"
      }]
    },
    {
      "id" : "GEM-ERP-LOG-MedicationDispense.medication.medicationArzneimittel.form.kbvDarreichungsform.code",
      "path" : "GEM-ERP-LOG-MedicationDispense.medication.medicationArzneimittel.form.kbvDarreichungsform.code",
      "short" : "kbvDarreichungsform-Code",
      "definition" : "kbvDarreichungsform-Code",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "code"
      }]
    },
    {
      "id" : "GEM-ERP-LOG-MedicationDispense.medication.medicationArzneimittel.form.kbvDarreichungsform.display",
      "path" : "GEM-ERP-LOG-MedicationDispense.medication.medicationArzneimittel.form.kbvDarreichungsform.display",
      "short" : "kbvDarreichungsform-Name",
      "definition" : "kbvDarreichungsform-Name",
      "comment" : "Muss angegeben werden, wenn vorhanden",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "GEM-ERP-LOG-MedicationDispense.medication.medicationArzneimittel.form.text",
      "path" : "GEM-ERP-LOG-MedicationDispense.medication.medicationArzneimittel.form.text",
      "short" : "Name der Darreichungsform",
      "definition" : "Name der Darreichungsform",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "GEM-ERP-LOG-MedicationDispense.medication.medicationArzneimittel.menge",
      "path" : "GEM-ERP-LOG-MedicationDispense.medication.medicationArzneimittel.menge",
      "short" : "Verordnete Menge des Arzneimittels",
      "definition" : "Verordnete Menge des Arzneimittels",
      "comment" : "Muss angegeben werden, wenn vorhanden",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "Quantity"
      }]
    },
    {
      "id" : "GEM-ERP-LOG-MedicationDispense.medication.medicationArzneimittel.inhaltsstoffe",
      "path" : "GEM-ERP-LOG-MedicationDispense.medication.medicationArzneimittel.inhaltsstoffe",
      "short" : "Inhaltsstoffe",
      "definition" : "Inhaltsstoffe",
      "min" : 0,
      "max" : "*",
      "type" : [{
        "code" : "BackboneElement"
      }]
    },
    {
      "id" : "GEM-ERP-LOG-MedicationDispense.medication.medicationArzneimittel.inhaltsstoffe.extension",
      "path" : "GEM-ERP-LOG-MedicationDispense.medication.medicationArzneimittel.inhaltsstoffe.extension",
      "short" : "Erweiterungen",
      "definition" : "Erweiterungen",
      "min" : 0,
      "max" : "*",
      "type" : [{
        "code" : "Extension"
      }]
    },
    {
      "id" : "GEM-ERP-LOG-MedicationDispense.medication.medicationArzneimittel.inhaltsstoffe.extension.darreichungsform",
      "path" : "GEM-ERP-LOG-MedicationDispense.medication.medicationArzneimittel.inhaltsstoffe.extension.darreichungsform",
      "short" : "Darreichungsform",
      "definition" : "Darreichungsform",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "Coding"
      }]
    },
    {
      "id" : "GEM-ERP-LOG-MedicationDispense.medication.medicationArzneimittel.inhaltsstoffe.inhaltsstoff",
      "path" : "GEM-ERP-LOG-MedicationDispense.medication.medicationArzneimittel.inhaltsstoffe.inhaltsstoff",
      "short" : "Inhaltsstoff",
      "definition" : "Inhaltsstoff",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "BackboneElement"
      }]
    },
    {
      "id" : "GEM-ERP-LOG-MedicationDispense.medication.medicationArzneimittel.inhaltsstoffe.inhaltsstoff.inhaltsstoffCoding",
      "path" : "GEM-ERP-LOG-MedicationDispense.medication.medicationArzneimittel.inhaltsstoffe.inhaltsstoff.inhaltsstoffCoding",
      "short" : "Kodierung des Inhaltsstoffs",
      "definition" : "Kodierung des Inhaltsstoffs",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "CodeableConcept"
      }]
    },
    {
      "id" : "GEM-ERP-LOG-MedicationDispense.medication.medicationArzneimittel.inhaltsstoffe.inhaltsstoff.inhaltsstoffCoding.pzn",
      "path" : "GEM-ERP-LOG-MedicationDispense.medication.medicationArzneimittel.inhaltsstoffe.inhaltsstoff.inhaltsstoffCoding.pzn",
      "short" : "PZN",
      "definition" : "PZN",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "Coding"
      }]
    },
    {
      "id" : "GEM-ERP-LOG-MedicationDispense.medication.medicationArzneimittel.inhaltsstoffe.inhaltsstoff.inhaltsstoffCoding.pzn.code",
      "path" : "GEM-ERP-LOG-MedicationDispense.medication.medicationArzneimittel.inhaltsstoffe.inhaltsstoff.inhaltsstoffCoding.pzn.code",
      "short" : "PZN-Code",
      "definition" : "PZN-Code",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "code"
      }]
    },
    {
      "id" : "GEM-ERP-LOG-MedicationDispense.medication.medicationArzneimittel.inhaltsstoffe.inhaltsstoff.inhaltsstoffCoding.pzn.display",
      "path" : "GEM-ERP-LOG-MedicationDispense.medication.medicationArzneimittel.inhaltsstoffe.inhaltsstoff.inhaltsstoffCoding.pzn.display",
      "short" : "PZN-Name",
      "definition" : "PZN-Name",
      "comment" : "Muss angegeben werden, wenn vorhanden",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "GEM-ERP-LOG-MedicationDispense.medication.medicationArzneimittel.inhaltsstoffe.inhaltsstoff.inhaltsstoffCoding.atcDe",
      "path" : "GEM-ERP-LOG-MedicationDispense.medication.medicationArzneimittel.inhaltsstoffe.inhaltsstoff.inhaltsstoffCoding.atcDe",
      "short" : "atc-de",
      "definition" : "atc-de",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "Coding"
      }]
    },
    {
      "id" : "GEM-ERP-LOG-MedicationDispense.medication.medicationArzneimittel.inhaltsstoffe.inhaltsstoff.inhaltsstoffCoding.atcDe.code",
      "path" : "GEM-ERP-LOG-MedicationDispense.medication.medicationArzneimittel.inhaltsstoffe.inhaltsstoff.inhaltsstoffCoding.atcDe.code",
      "short" : "atc-de-Code",
      "definition" : "atc-de-Code",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "code"
      }]
    },
    {
      "id" : "GEM-ERP-LOG-MedicationDispense.medication.medicationArzneimittel.inhaltsstoffe.inhaltsstoff.inhaltsstoffCoding.atcDe.display",
      "path" : "GEM-ERP-LOG-MedicationDispense.medication.medicationArzneimittel.inhaltsstoffe.inhaltsstoff.inhaltsstoffCoding.atcDe.display",
      "short" : "atc-de-Name",
      "definition" : "atc-de-Name",
      "comment" : "Muss angegeben werden, wenn vorhanden",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "GEM-ERP-LOG-MedicationDispense.medication.medicationArzneimittel.inhaltsstoffe.inhaltsstoff.inhaltsstoffCoding.ask",
      "path" : "GEM-ERP-LOG-MedicationDispense.medication.medicationArzneimittel.inhaltsstoffe.inhaltsstoff.inhaltsstoffCoding.ask",
      "short" : "ask",
      "definition" : "ask",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "Coding"
      }]
    },
    {
      "id" : "GEM-ERP-LOG-MedicationDispense.medication.medicationArzneimittel.inhaltsstoffe.inhaltsstoff.inhaltsstoffCoding.ask.code",
      "path" : "GEM-ERP-LOG-MedicationDispense.medication.medicationArzneimittel.inhaltsstoffe.inhaltsstoff.inhaltsstoffCoding.ask.code",
      "short" : "ask-Code",
      "definition" : "ask-Code",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "code"
      }]
    },
    {
      "id" : "GEM-ERP-LOG-MedicationDispense.medication.medicationArzneimittel.inhaltsstoffe.inhaltsstoff.inhaltsstoffCoding.ask.display",
      "path" : "GEM-ERP-LOG-MedicationDispense.medication.medicationArzneimittel.inhaltsstoffe.inhaltsstoff.inhaltsstoffCoding.ask.display",
      "short" : "ask-Name",
      "definition" : "ask-Name",
      "comment" : "Muss angegeben werden, wenn vorhanden",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "GEM-ERP-LOG-MedicationDispense.medication.medicationArzneimittel.inhaltsstoffe.inhaltsstoff.inhaltsstoffCoding.wg14",
      "path" : "GEM-ERP-LOG-MedicationDispense.medication.medicationArzneimittel.inhaltsstoffe.inhaltsstoff.inhaltsstoffCoding.wg14",
      "short" : "wg14",
      "definition" : "wg14",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "Coding"
      }]
    },
    {
      "id" : "GEM-ERP-LOG-MedicationDispense.medication.medicationArzneimittel.inhaltsstoffe.inhaltsstoff.inhaltsstoffCoding.wg14.code",
      "path" : "GEM-ERP-LOG-MedicationDispense.medication.medicationArzneimittel.inhaltsstoffe.inhaltsstoff.inhaltsstoffCoding.wg14.code",
      "short" : "wg14-Code",
      "definition" : "wg14-Code",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "code"
      }]
    },
    {
      "id" : "GEM-ERP-LOG-MedicationDispense.medication.medicationArzneimittel.inhaltsstoffe.inhaltsstoff.inhaltsstoffCoding.wg14.display",
      "path" : "GEM-ERP-LOG-MedicationDispense.medication.medicationArzneimittel.inhaltsstoffe.inhaltsstoff.inhaltsstoffCoding.wg14.display",
      "short" : "wg14-Name",
      "definition" : "wg14-Name",
      "comment" : "Muss angegeben werden, wenn vorhanden",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "GEM-ERP-LOG-MedicationDispense.medication.medicationArzneimittel.inhaltsstoffe.inhaltsstoff.inhaltsstoffCoding.snomed",
      "path" : "GEM-ERP-LOG-MedicationDispense.medication.medicationArzneimittel.inhaltsstoffe.inhaltsstoff.inhaltsstoffCoding.snomed",
      "short" : "snomed",
      "definition" : "snomed",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "Coding"
      }]
    },
    {
      "id" : "GEM-ERP-LOG-MedicationDispense.medication.medicationArzneimittel.inhaltsstoffe.inhaltsstoff.inhaltsstoffCoding.snomed.code",
      "path" : "GEM-ERP-LOG-MedicationDispense.medication.medicationArzneimittel.inhaltsstoffe.inhaltsstoff.inhaltsstoffCoding.snomed.code",
      "short" : "snomed-Code",
      "definition" : "snomed-Code",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "code"
      }]
    },
    {
      "id" : "GEM-ERP-LOG-MedicationDispense.medication.medicationArzneimittel.inhaltsstoffe.inhaltsstoff.inhaltsstoffCoding.snomed.display",
      "path" : "GEM-ERP-LOG-MedicationDispense.medication.medicationArzneimittel.inhaltsstoffe.inhaltsstoff.inhaltsstoffCoding.snomed.display",
      "short" : "snomed-Name",
      "definition" : "snomed-Name",
      "comment" : "Muss angegeben werden, wenn vorhanden",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "GEM-ERP-LOG-MedicationDispense.medication.medicationArzneimittel.inhaltsstoffe.inhaltsstoff.inhaltsstoffReference",
      "path" : "GEM-ERP-LOG-MedicationDispense.medication.medicationArzneimittel.inhaltsstoffe.inhaltsstoff.inhaltsstoffReference",
      "short" : "Referenz zum Inhaltsstoff",
      "definition" : "Referenz zum Inhaltsstoff",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "Reference"
      }]
    },
    {
      "id" : "GEM-ERP-LOG-MedicationDispense.medication.medicationArzneimittel.inhaltsstoffe.wirkstaerke",
      "path" : "GEM-ERP-LOG-MedicationDispense.medication.medicationArzneimittel.inhaltsstoffe.wirkstaerke",
      "short" : "Wirkstärke des Inhaltsstoffes",
      "definition" : "Wirkstärke des Inhaltsstoffes",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "Ratio"
      }]
    },
    {
      "id" : "GEM-ERP-LOG-MedicationDispense.medication.medicationArzneimittel.inhaltsstoffe.menge",
      "path" : "GEM-ERP-LOG-MedicationDispense.medication.medicationArzneimittel.inhaltsstoffe.menge",
      "short" : "Menge des Inhaltsstoffes",
      "definition" : "Menge des Inhaltsstoffes",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "Quantity"
      }]
    },
    {
      "id" : "GEM-ERP-LOG-MedicationDispense.medication.medicationArzneimittel.inhaltsstoffe.einheit",
      "path" : "GEM-ERP-LOG-MedicationDispense.medication.medicationArzneimittel.inhaltsstoffe.einheit",
      "short" : "Einheit der Menge des Inhaltsstoffes",
      "definition" : "Einheit der Menge des Inhaltsstoffes",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "GEM-ERP-LOG-MedicationDispense.medication.medicationArzneimittel.chargenInformation",
      "path" : "GEM-ERP-LOG-MedicationDispense.medication.medicationArzneimittel.chargenInformation",
      "short" : "Chargeninformation",
      "definition" : "Chargeninformation",
      "comment" : "Da die ePA Medication nur bei der Abgabe verwendet wird ist die Angabe der Chargeninformation verpflichtend.",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "BackboneElement"
      }]
    },
    {
      "id" : "GEM-ERP-LOG-MedicationDispense.medication.medicationArzneimittel.chargenInformation.chargennummer",
      "path" : "GEM-ERP-LOG-MedicationDispense.medication.medicationArzneimittel.chargenInformation.chargennummer",
      "short" : "Chargennummer",
      "definition" : "Chargennummer",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "GEM-ERP-LOG-MedicationDispense.medication.medicationArzneimittel.chargenInformation.ablaufdatum",
      "path" : "GEM-ERP-LOG-MedicationDispense.medication.medicationArzneimittel.chargenInformation.ablaufdatum",
      "short" : "Ablaufdatum der Charge",
      "definition" : "Ablaufdatum der Charge",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "dateTime"
      }]
    },
    {
      "id" : "GEM-ERP-LOG-MedicationDispense.medication.medicationArzneimittel.darreichungsform",
      "path" : "GEM-ERP-LOG-MedicationDispense.medication.medicationArzneimittel.darreichungsform",
      "short" : "Darreichungsform",
      "definition" : "Darreichungsform",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "Coding"
      }]
    },
    {
      "id" : "GEM-ERP-LOG-MedicationDispense.patientKVNR",
      "path" : "GEM-ERP-LOG-MedicationDispense.patientKVNR",
      "short" : "KVNR des Patienten",
      "definition" : "KVNR des Patienten",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "GEM-ERP-LOG-MedicationDispense.angabeAbgebendeInstutition",
      "path" : "GEM-ERP-LOG-MedicationDispense.angabeAbgebendeInstutition",
      "short" : "Telematik-ID der abgebenden Institution",
      "definition" : "Telematik-ID der abgebenden Institution",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "Extension",
        "profile" : ["http://hl7.org/fhir/StructureDefinition/elementdefinition-identifier"]
      }]
    },
    {
      "id" : "GEM-ERP-LOG-MedicationDispense.menge",
      "path" : "GEM-ERP-LOG-MedicationDispense.menge",
      "short" : "Abgegebene Menge des Arzneimittels.",
      "definition" : "Abgegebene Menge des Arzneimittels.",
      "comment" : "Muss angegeben werden, wenn vorhanden",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "Quantity"
      }]
    },
    {
      "id" : "GEM-ERP-LOG-MedicationDispense.abgabeDatum",
      "path" : "GEM-ERP-LOG-MedicationDispense.abgabeDatum",
      "short" : "Abgabedatum im Format YYYY-MM-DD",
      "definition" : "Abgabedatum im Format YYYY-MM-DD",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "dateTime"
      }]
    },
    {
      "id" : "GEM-ERP-LOG-MedicationDispense.dosieranweisung",
      "path" : "GEM-ERP-LOG-MedicationDispense.dosieranweisung",
      "short" : "Dosieranweisung,",
      "definition" : "Dosieranweisung,",
      "comment" : "Muss angegeben werden, wenn vorhanden",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "GEM-ERP-LOG-MedicationDispense.verweisZumTask",
      "path" : "GEM-ERP-LOG-MedicationDispense.verweisZumTask",
      "short" : "Verweis auf den Task, der die Abgabe enthält. Wird vom E-Rezept-Fachdienst gesetzt.",
      "definition" : "Verweis auf den Task, der die Abgabe enthält. Wird vom E-Rezept-Fachdienst gesetzt.",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "Reference"
      }]
    },
    {
      "id" : "GEM-ERP-LOG-MedicationDispense.substituierung",
      "path" : "GEM-ERP-LOG-MedicationDispense.substituierung",
      "short" : "Substituierung",
      "definition" : "Substituierung",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "BackboneElement"
      }]
    },
    {
      "id" : "GEM-ERP-LOG-MedicationDispense.substituierung.wurdeSubstituiert",
      "path" : "GEM-ERP-LOG-MedicationDispense.substituierung.wurdeSubstituiert",
      "short" : "Angabe, ob substituiert wurde",
      "definition" : "Angabe, ob substituiert wurde",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "boolean"
      }]
    },
    {
      "id" : "GEM-ERP-LOG-MedicationDispense.abgabeHinweise",
      "path" : "GEM-ERP-LOG-MedicationDispense.abgabeHinweise",
      "short" : "Hinweise zur Abgabe, wenn vorhanden",
      "definition" : "Hinweise zur Abgabe, wenn vorhanden",
      "min" : 0,
      "max" : "*",
      "type" : [{
        "code" : "Annotation"
      }]
    }]
  }
}

```
