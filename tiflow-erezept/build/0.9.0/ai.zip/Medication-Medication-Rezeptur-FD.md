# Medication-Rezeptur-FD - TIFlow - Verordnungen für Arzneimittel v0.9.0

TIFlow - Verordnungen für Arzneimittel

Version 0.9.0 - ci-build 

* [**Table of Contents**](toc.md)
* [**FHIR-Artefakte**](artifacts.md)
* **Medication-Rezeptur-FD**

## Example Medication: Medication-Rezeptur-FD



## Resource Content

```json
{
  "resourceType" : "Medication",
  "id" : "Medication-Rezeptur-FD",
  "meta" : {
    "profile" : ["https://gematik.de/fhir/tiflow/erezept/StructureDefinition/GEM-ERP-PR-Medication"]
  },
  "contained" : [{
    "resourceType" : "Medication",
    "id" : "MedicationHydrocortison-FD",
    "meta" : {
      "profile" : ["https://gematik.de/fhir/epa-medication/StructureDefinition/epa-medication-pzn-ingredient"]
    },
    "extension" : [{
      "url" : "https://gematik.de/fhir/epa-medication/StructureDefinition/epa-medication-type-extension",
      "valueCoding" : {
        "system" : "http://snomed.info/sct",
        "code" : "781405001",
        "display" : "Medicinal product package (product)"
      }
    }],
    "code" : {
      "coding" : [{
        "system" : "http://fhir.de/CodeSystem/ifa/pzn",
        "code" : "03424249",
        "display" : "Hydrocortison 1% Creme"
      }],
      "text" : "Hydrocortison 1% Creme"
    }
  },
  {
    "resourceType" : "Medication",
    "id" : "MedicationDexpanthenol-FD",
    "meta" : {
      "profile" : ["https://gematik.de/fhir/epa-medication/StructureDefinition/epa-medication-pzn-ingredient"]
    },
    "extension" : [{
      "url" : "https://gematik.de/fhir/epa-medication/StructureDefinition/epa-medication-type-extension",
      "valueCoding" : {
        "system" : "http://snomed.info/sct",
        "code" : "781405001",
        "display" : "Medicinal product package (product)"
      }
    }],
    "code" : {
      "coding" : [{
        "system" : "http://fhir.de/CodeSystem/ifa/pzn",
        "code" : "16667195",
        "display" : "Dexpanthenol 5% Creme"
      }],
      "text" : "Dexpanthenol 5% Creme"
    }
  }],
  "extension" : [{
    "url" : "https://gematik.de/fhir/epa-medication/StructureDefinition/drug-category-extension",
    "valueCoding" : {
      "system" : "https://gematik.de/fhir/epa-medication/CodeSystem/epa-drug-category-cs",
      "code" : "00"
    }
  },
  {
    "url" : "https://gematik.de/fhir/epa-medication/StructureDefinition/medication-manufacturing-instructions-extension",
    "valueString" : "Bitte kühl zubereiten und lagern."
  },
  {
    "url" : "https://gematik.de/fhir/epa-medication/StructureDefinition/medication-formulation-packaging-extension",
    "valueString" : "Tube"
  },
  {
    "url" : "https://gematik.de/fhir/epa-medication/StructureDefinition/medication-id-vaccine-extension",
    "valueBoolean" : false
  },
  {
    "url" : "https://gematik.de/fhir/epa-medication/StructureDefinition/epa-medication-type-extension",
    "valueCoding" : {
      "system" : "http://snomed.info/sct",
      "code" : "1208954007",
      "display" : "Extemporaneous preparation (product)"
    }
  }],
  "code" : {
    "text" : "Hydrocortison-Dexpanthenol-Salbe"
  },
  "form" : {
    "text" : "Salbe"
  },
  "amount" : {
    "numerator" : {
      "extension" : [{
        "url" : "https://gematik.de/fhir/epa-medication/StructureDefinition/medication-total-quantity-formulation-extension",
        "valueString" : "100"
      }],
      "value" : 20,
      "unit" : "ml"
    },
    "denominator" : {
      "value" : 1
    }
  },
  "ingredient" : [{
    "extension" : [{
      "url" : "https://gematik.de/fhir/epa-medication/StructureDefinition/medication-ingredient-darreichungsform-extension",
      "valueString" : "Salbe"
    }],
    "itemReference" : {
      "reference" : "#MedicationHydrocortison-FD"
    },
    "isActive" : true,
    "strength" : {
      "numerator" : {
        "value" : 50,
        "unit" : "g"
      },
      "denominator" : {
        "value" : 100,
        "unit" : "g"
      }
    }
  },
  {
    "extension" : [{
      "url" : "https://gematik.de/fhir/epa-medication/StructureDefinition/medication-ingredient-darreichungsform-extension",
      "valueString" : "Salbe"
    }],
    "itemReference" : {
      "reference" : "#MedicationDexpanthenol-FD"
    },
    "isActive" : true,
    "strength" : {
      "numerator" : {
        "value" : 50,
        "unit" : "g"
      },
      "denominator" : {
        "value" : 100,
        "unit" : "g"
      }
    }
  }]
}

```
