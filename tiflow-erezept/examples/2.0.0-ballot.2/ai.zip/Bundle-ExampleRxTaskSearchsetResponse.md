# Antwortbundle für GET /Task (Rx) - Implementation Guide TIFlow - Verordnungen für Arzneimittel v2.0.0-ballot.2

Implementation Guide

TIFlow - Verordnungen für Arzneimittel

Version 2.0.0-ballot.2 - ci-build 

* [**Table of Contents**](toc.md)
* [**FHIR-Artefakte**](artifacts.md)
* **Antwortbundle für GET /Task (Rx)**

## Example Bundle: Antwortbundle für GET /Task (Rx)



## Resource Content

```json
{
  "resourceType" : "Bundle",
  "id" : "ExampleRxTaskSearchsetResponse",
  "type" : "searchset",
  "total" : 6,
  "link" : [{
    "relation" : "self",
    "url" : "https://erp-ref.zentral.erp.splitdns.ti-dienste.de/Task"
  }],
  "entry" : [{
    "fullUrl" : "https://erp-ref.zentral.erp.splitdns.ti-dienste.de/Task/b12eb5f7-91ce-4887-93c7-800454601377",
    "resource" : {
      "resourceType" : "Task",
      "id" : "b12eb5f7-91ce-4887-93c7-800454601377",
      "meta" : {
        "profile" : ["https://gematik.de/fhir/erp/StructureDefinition/GEM_ERP_PR_Task|2.0"],
        "tag" : [{
          "display" : "Task in DRAFT state just created by Fachdienst via $create operation"
        }]
      },
      "extension" : [{
        "url" : "https://gematik.de/fhir/erp/StructureDefinition/GEM_ERP_EX_PrescriptionType",
        "valueCoding" : {
          "system" : "https://gematik.de/fhir/erp/CodeSystem/GEM_ERP_CS_FlowType",
          "code" : "160",
          "display" : "Flowtype für Apothekenpflichtige Arzneimittel"
        }
      },
      {
        "url" : "https://gematik.de/fhir/erp/StructureDefinition/GEM_ERP_EX_AcceptDate",
        "valueDate" : "2028-10-01"
      },
      {
        "url" : "https://gematik.de/fhir/erp/StructureDefinition/GEM_ERP_EX_ExpiryDate",
        "valueDate" : "2028-10-01"
      }],
      "identifier" : [{
        "system" : "https://gematik.de/fhir/erp/NamingSystem/GEM_ERP_NS_PrescriptionId",
        "value" : "160.000.033.491.280.78"
      },
      {
        "system" : "https://gematik.de/fhir/erp/NamingSystem/GEM_ERP_NS_AccessCode",
        "value" : "777bea0e13cc9c42ceec14aec3ddee2263325dc2c6c699db115f58fe423607ea"
      }],
      "status" : "draft",
      "intent" : "order",
      "authoredOn" : "2028-10-01T15:29:00+00:00",
      "performerType" : [{
        "coding" : [{
          "system" : "https://gematik.de/fhir/erp/CodeSystem/GEM_ERP_CS_OrganizationType",
          "code" : "urn:oid:1.2.276.0.76.4.54",
          "display" : "Öffentliche Apotheke"
        }]
      }]
    },
    "search" : {
      "mode" : "match"
    }
  },
  {
    "fullUrl" : "https://erp-ref.zentral.erp.splitdns.ti-dienste.de/Task/TaskInReadyState",
    "resource" : {
      "resourceType" : "Task",
      "id" : "TaskInReadyState",
      "meta" : {
        "profile" : ["https://gematik.de/fhir/erp/StructureDefinition/GEM_ERP_PR_Task|2.0"],
        "tag" : [{
          "display" : "Task in READY state activated by (Z)PVS/KIS via $activate operation"
        }]
      },
      "extension" : [{
        "url" : "https://gematik.de/fhir/erp/StructureDefinition/GEM_ERP_EX_PrescriptionType",
        "valueCoding" : {
          "system" : "https://gematik.de/fhir/erp/CodeSystem/GEM_ERP_CS_FlowType",
          "code" : "160",
          "display" : "Flowtype für Apothekenpflichtige Arzneimittel"
        }
      },
      {
        "url" : "https://gematik.de/fhir/erp/StructureDefinition/GEM_ERP_EX_AcceptDate",
        "valueDate" : "2028-10-01"
      },
      {
        "url" : "https://gematik.de/fhir/erp/StructureDefinition/GEM_ERP_EX_ExpiryDate",
        "valueDate" : "2028-10-01"
      }],
      "identifier" : [{
        "system" : "https://gematik.de/fhir/erp/NamingSystem/GEM_ERP_NS_PrescriptionId",
        "value" : "160.000.033.491.280.78"
      },
      {
        "system" : "https://gematik.de/fhir/erp/NamingSystem/GEM_ERP_NS_AccessCode",
        "value" : "777bea0e13cc9c42ceec14aec3ddee2263325dc2c6c699db115f58fe423607ea"
      }],
      "status" : "ready",
      "intent" : "order",
      "for" : {
        "identifier" : {
          "system" : "http://fhir.de/sid/gkv/kvid-10",
          "value" : "X123456789"
        }
      },
      "authoredOn" : "2028-10-01T15:29:00+00:00",
      "lastModified" : "2028-10-01T16:44:00.434+00:00",
      "performerType" : [{
        "coding" : [{
          "system" : "https://gematik.de/fhir/erp/CodeSystem/GEM_ERP_CS_OrganizationType",
          "code" : "urn:oid:1.2.276.0.76.4.54",
          "display" : "Öffentliche Apotheke"
        }]
      }],
      "input" : [{
        "type" : {
          "coding" : [{
            "system" : "https://gematik.de/fhir/erp/CodeSystem/GEM_ERP_CS_DocumentType",
            "code" : "1",
            "display" : "Health Care Provider Prescription"
          }]
        },
        "valueReference" : {
          "reference" : "281a985c-f25b-4aae-91a6-41ad744080b0"
        }
      },
      {
        "type" : {
          "coding" : [{
            "system" : "https://gematik.de/fhir/erp/CodeSystem/GEM_ERP_CS_DocumentType",
            "code" : "2",
            "display" : "Patient Confirmation"
          }]
        },
        "valueReference" : {
          "reference" : "f8c2298f-7c00-4a68-af29-8a2862d55d43"
        }
      }]
    },
    "search" : {
      "mode" : "match"
    }
  },
  {
    "fullUrl" : "https://erp-ref.zentral.erp.splitdns.ti-dienste.de/Task/d70932d1-9e1c-483c-b2d4-b7dced09b35e",
    "resource" : {
      "resourceType" : "Task",
      "id" : "d70932d1-9e1c-483c-b2d4-b7dced09b35e",
      "meta" : {
        "profile" : ["https://gematik.de/fhir/erp/StructureDefinition/GEM_ERP_PR_Task|2.0"],
        "tag" : [{
          "display" : "Task in IN-PROGRESS state claimed by pharmacy via $accept operation"
        }]
      },
      "extension" : [{
        "url" : "https://gematik.de/fhir/erp/StructureDefinition/GEM_ERP_EX_PrescriptionType",
        "valueCoding" : {
          "system" : "https://gematik.de/fhir/erp/CodeSystem/GEM_ERP_CS_FlowType",
          "code" : "160",
          "display" : "Flowtype für Apothekenpflichtige Arzneimittel"
        }
      },
      {
        "url" : "https://gematik.de/fhir/erp/StructureDefinition/GEM_ERP_EX_AcceptDate",
        "valueDate" : "2028-10-01"
      },
      {
        "url" : "https://gematik.de/fhir/erp/StructureDefinition/GEM_ERP_EX_ExpiryDate",
        "valueDate" : "2028-10-01"
      }],
      "identifier" : [{
        "system" : "https://gematik.de/fhir/erp/NamingSystem/GEM_ERP_NS_PrescriptionId",
        "value" : "160.000.033.491.280.78"
      },
      {
        "system" : "https://gematik.de/fhir/erp/NamingSystem/GEM_ERP_NS_AccessCode",
        "value" : "777bea0e13cc9c42ceec14aec3ddee2263325dc2c6c699db115f58fe423607ea"
      }],
      "status" : "in-progress",
      "intent" : "order",
      "for" : {
        "identifier" : {
          "system" : "http://fhir.de/sid/gkv/kvid-10",
          "value" : "X123456789"
        }
      },
      "authoredOn" : "2028-10-01T15:29:00+00:00",
      "lastModified" : "2028-10-01T16:44:00.434+00:00",
      "performerType" : [{
        "coding" : [{
          "system" : "https://gematik.de/fhir/erp/CodeSystem/GEM_ERP_CS_OrganizationType",
          "code" : "urn:oid:1.2.276.0.76.4.54",
          "display" : "Öffentliche Apotheke"
        }]
      }],
      "input" : [{
        "type" : {
          "coding" : [{
            "system" : "https://gematik.de/fhir/erp/CodeSystem/GEM_ERP_CS_DocumentType",
            "code" : "1",
            "display" : "Health Care Provider Prescription"
          }]
        },
        "valueReference" : {
          "reference" : "Binary/PrescriptionBinary"
        }
      }]
    },
    "search" : {
      "mode" : "match"
    }
  },
  {
    "fullUrl" : "https://erp-ref.zentral.erp.splitdns.ti-dienste.de/Task/9b48f82c-9c11-4a57-aa72-a805f9537a82",
    "resource" : {
      "resourceType" : "Task",
      "id" : "9b48f82c-9c11-4a57-aa72-a805f9537a82",
      "meta" : {
        "profile" : ["https://gematik.de/fhir/erp/StructureDefinition/GEM_ERP_PR_Task|2.0"],
        "tag" : [{
          "display" : "Task in IN-PROGRESS state claimed by pharmacy via $accept operation"
        }]
      },
      "extension" : [{
        "url" : "https://gematik.de/fhir/erp/StructureDefinition/GEM_ERP_EX_PrescriptionType",
        "valueCoding" : {
          "system" : "https://gematik.de/fhir/erp/CodeSystem/GEM_ERP_CS_FlowType",
          "code" : "160",
          "display" : "Flowtype für Apothekenpflichtige Arzneimittel"
        }
      },
      {
        "url" : "https://gematik.de/fhir/erp/StructureDefinition/GEM_ERP_EX_AcceptDate",
        "valueDate" : "2028-10-01"
      },
      {
        "url" : "https://gematik.de/fhir/erp/StructureDefinition/GEM_ERP_EX_ExpiryDate",
        "valueDate" : "2028-10-01"
      },
      {
        "url" : "https://gematik.de/fhir/erp/StructureDefinition/GEM_ERP_EX_LastMedicationDispense",
        "valueInstant" : "2028-10-01T16:44:00.434+00:00"
      }],
      "identifier" : [{
        "system" : "https://gematik.de/fhir/erp/NamingSystem/GEM_ERP_NS_PrescriptionId",
        "value" : "160.000.033.491.280.78"
      },
      {
        "system" : "https://gematik.de/fhir/erp/NamingSystem/GEM_ERP_NS_AccessCode",
        "value" : "777bea0e13cc9c42ceec14aec3ddee2263325dc2c6c699db115f58fe423607ea"
      }],
      "status" : "in-progress",
      "intent" : "order",
      "for" : {
        "identifier" : {
          "system" : "http://fhir.de/sid/gkv/kvid-10",
          "value" : "X123456789"
        }
      },
      "authoredOn" : "2028-10-01T15:29:00+00:00",
      "lastModified" : "2028-10-01T16:44:00.434+00:00",
      "performerType" : [{
        "coding" : [{
          "system" : "https://gematik.de/fhir/erp/CodeSystem/GEM_ERP_CS_OrganizationType",
          "code" : "urn:oid:1.2.276.0.76.4.54",
          "display" : "Öffentliche Apotheke"
        }]
      }],
      "input" : [{
        "type" : {
          "coding" : [{
            "system" : "https://gematik.de/fhir/erp/CodeSystem/GEM_ERP_CS_DocumentType",
            "code" : "1",
            "display" : "Health Care Provider Prescription"
          }]
        },
        "valueReference" : {
          "reference" : "281a985c-f25b-4aae-91a6-41ad744080b0"
        }
      },
      {
        "type" : {
          "coding" : [{
            "system" : "https://gematik.de/fhir/erp/CodeSystem/GEM_ERP_CS_DocumentType",
            "code" : "2",
            "display" : "Patient Confirmation"
          }]
        },
        "valueReference" : {
          "reference" : "f8c2298f-7c00-4a68-af29-8a2862d55d43"
        }
      }]
    },
    "search" : {
      "mode" : "match"
    }
  },
  {
    "fullUrl" : "https://erp-ref.zentral.erp.splitdns.ti-dienste.de/Task/f5c21409-b84b-4125-8649-5630a00906b1",
    "resource" : {
      "resourceType" : "Task",
      "id" : "f5c21409-b84b-4125-8649-5630a00906b1",
      "meta" : {
        "profile" : ["https://gematik.de/fhir/erp/StructureDefinition/GEM_ERP_PR_Task|2.0"],
        "tag" : [{
          "display" : "Task in IN-PROGRESS state claimed by pharmacy via $accept operation"
        }]
      },
      "extension" : [{
        "url" : "https://gematik.de/fhir/erp/StructureDefinition/GEM_ERP_EX_PrescriptionType",
        "valueCoding" : {
          "system" : "https://gematik.de/fhir/erp/CodeSystem/GEM_ERP_CS_FlowType",
          "code" : "160",
          "display" : "Flowtype für Apothekenpflichtige Arzneimittel"
        }
      },
      {
        "url" : "https://gematik.de/fhir/erp/StructureDefinition/GEM_ERP_EX_AcceptDate",
        "valueDate" : "2028-10-01"
      },
      {
        "url" : "https://gematik.de/fhir/erp/StructureDefinition/GEM_ERP_EX_ExpiryDate",
        "valueDate" : "2028-10-01"
      },
      {
        "url" : "https://gematik.de/fhir/erp/StructureDefinition/GEM_ERP_EX_LastMedicationDispense",
        "valueInstant" : "2028-10-01T16:44:00.434+00:00"
      }],
      "identifier" : [{
        "system" : "https://gematik.de/fhir/erp/NamingSystem/GEM_ERP_NS_PrescriptionId",
        "value" : "160.000.033.491.280.78"
      },
      {
        "system" : "https://gematik.de/fhir/erp/NamingSystem/GEM_ERP_NS_AccessCode",
        "value" : "777bea0e13cc9c42ceec14aec3ddee2263325dc2c6c699db115f58fe423607ea"
      }],
      "status" : "in-progress",
      "intent" : "order",
      "for" : {
        "identifier" : {
          "system" : "http://fhir.de/sid/gkv/kvid-10",
          "value" : "X123456789"
        }
      },
      "authoredOn" : "2028-10-01T15:29:00+00:00",
      "lastModified" : "2028-10-01T16:44:00.434+00:00",
      "performerType" : [{
        "coding" : [{
          "system" : "https://gematik.de/fhir/erp/CodeSystem/GEM_ERP_CS_OrganizationType",
          "code" : "urn:oid:1.2.276.0.76.4.54",
          "display" : "Öffentliche Apotheke"
        }]
      }],
      "input" : [{
        "type" : {
          "coding" : [{
            "system" : "https://gematik.de/fhir/erp/CodeSystem/GEM_ERP_CS_DocumentType",
            "code" : "1",
            "display" : "Health Care Provider Prescription"
          }]
        },
        "valueReference" : {
          "reference" : "281a985c-f25b-4aae-91a6-41ad744080b0"
        }
      },
      {
        "type" : {
          "coding" : [{
            "system" : "https://gematik.de/fhir/erp/CodeSystem/GEM_ERP_CS_DocumentType",
            "code" : "2",
            "display" : "Patient Confirmation"
          }]
        },
        "valueReference" : {
          "reference" : "f8c2298f-7c00-4a68-af29-8a2862d55d43"
        }
      }]
    },
    "search" : {
      "mode" : "match"
    }
  },
  {
    "fullUrl" : "https://erp-ref.zentral.erp.splitdns.ti-dienste.de/Task/TaskInClosedState",
    "resource" : {
      "resourceType" : "Task",
      "id" : "TaskInClosedState",
      "meta" : {
        "profile" : ["https://gematik.de/fhir/erp/StructureDefinition/GEM_ERP_PR_Task|2.0"],
        "tag" : [{
          "display" : "Task in COMPLETED state dispensed by pharmacy via $closed operation"
        }]
      },
      "extension" : [{
        "url" : "https://gematik.de/fhir/erp/StructureDefinition/GEM_ERP_EX_PrescriptionType",
        "valueCoding" : {
          "system" : "https://gematik.de/fhir/erp/CodeSystem/GEM_ERP_CS_FlowType",
          "code" : "160",
          "display" : "Flowtype für Apothekenpflichtige Arzneimittel"
        }
      },
      {
        "url" : "https://gematik.de/fhir/erp/StructureDefinition/GEM_ERP_EX_AcceptDate",
        "valueDate" : "2028-10-01"
      },
      {
        "url" : "https://gematik.de/fhir/erp/StructureDefinition/GEM_ERP_EX_ExpiryDate",
        "valueDate" : "2028-10-01"
      }],
      "identifier" : [{
        "system" : "https://gematik.de/fhir/erp/NamingSystem/GEM_ERP_NS_PrescriptionId",
        "value" : "160.000.033.491.280.78"
      },
      {
        "system" : "https://gematik.de/fhir/erp/NamingSystem/GEM_ERP_NS_AccessCode",
        "value" : "777bea0e13cc9c42ceec14aec3ddee2263325dc2c6c699db115f58fe423607ea"
      }],
      "status" : "completed",
      "intent" : "order",
      "for" : {
        "identifier" : {
          "system" : "http://fhir.de/sid/gkv/kvid-10",
          "value" : "X123456789"
        }
      },
      "authoredOn" : "2028-10-01T15:29:00+00:00",
      "lastModified" : "2028-10-01T16:44:00.434+00:00",
      "performerType" : [{
        "coding" : [{
          "system" : "https://gematik.de/fhir/erp/CodeSystem/GEM_ERP_CS_OrganizationType",
          "code" : "urn:oid:1.2.276.0.76.4.54",
          "display" : "Öffentliche Apotheke"
        }]
      }],
      "input" : [{
        "type" : {
          "coding" : [{
            "system" : "https://gematik.de/fhir/erp/CodeSystem/GEM_ERP_CS_DocumentType",
            "code" : "1",
            "display" : "Health Care Provider Prescription"
          }]
        },
        "valueReference" : {
          "reference" : "281a985c-f25b-4aae-91a6-41ad744080b0"
        }
      },
      {
        "type" : {
          "coding" : [{
            "system" : "https://gematik.de/fhir/erp/CodeSystem/GEM_ERP_CS_DocumentType",
            "code" : "2",
            "display" : "Patient Confirmation"
          }]
        },
        "valueReference" : {
          "reference" : "f8c2298f-7c00-4a68-af29-8a2862d55d43"
        }
      }],
      "output" : [{
        "type" : {
          "coding" : [{
            "system" : "https://gematik.de/fhir/erp/CodeSystem/GEM_ERP_CS_DocumentType",
            "code" : "3",
            "display" : "Receipt"
          }]
        },
        "valueReference" : {
          "reference" : "dffbfd6a-5712-4798-bdc8-07201eb77ab8"
        }
      }]
    },
    "search" : {
      "mode" : "match"
    }
  }]
}

```
