# Fehlermeldung BfArM Webdienst - Datenaustausch E-Rezept-Fachdienst und BfArM Webdienst v1.0.0

Datenaustausch E-Rezept-Fachdienst und BfArM Webdienst

Version 1.0.0 - ci-build 

* [**Table of Contents**](toc.md)
* [**FHIR-Artefakte**](artifacts.md)
* **Fehlermeldung BfArM Webdienst**

## Example OperationOutcome: Fehlermeldung BfArM Webdienst

> **issue****severity**: Error**code**: Invalid Content**details**: Invalid request payload**diagnostics**: This field is required**expression**: parameter[rxPrescription].part[prescriptionId].value

> **issue****severity**: Error**code**: Element value invalid**details**: Invalid format for field**diagnostics**: Value must be a date**expression**: parameter[rxPrescription].part[medicationRequest].resource.authoredOn



## Resource Content

```json
{
  "resourceType" : "OperationOutcome",
  "id" : "ERP-TPrescription-OperationOutcome-1",
  "issue" : [{
    "severity" : "error",
    "code" : "invalid",
    "details" : {
      "text" : "Invalid request payload"
    },
    "diagnostics" : "This field is required",
    "expression" : ["parameter[rxPrescription].part[prescriptionId].value"]
  },
  {
    "severity" : "error",
    "code" : "value",
    "details" : {
      "text" : "Invalid format for field"
    },
    "diagnostics" : "Value must be a date",
    "expression" : ["parameter[rxPrescription].part[medicationRequest].resource.authoredOn"]
  }]
}

```
