# null (Bundle) - Datenaustausch E-Rezept-Fachdienst und BfArM Webdienst v1.0.0

Datenaustausch E-Rezept-Fachdienst und BfArM Webdienst

Version 1.0.0 - ci-build 

* [**Table of Contents**](toc.md)
* [**FHIR-Artefakte**](artifacts.md)
* **null (Bundle)**

## Bundle: null (Bundle)



## Resource Content

```json
{
  "resourceType" : "Bundle",
  "id" : "example-case-04-mapping-bundle",
  "type" : "collection",
  "entry" : [{
    "fullUrl" : "urn:uuid:7d871b93-e18c-4865-bad0-6b55196be46b",
    "resource" : {
      "resourceType" : "MedicationRequest",
      "id" : "7d871b93-e18c-4865-bad0-6b55196be46b",
      "meta" : {
        "versionId" : "1",
        "profile" : ["https://fhir.kbv.de/StructureDefinition/KBV_PR_ERP_Prescription|1.4"]
      },
      "extension" : [{
        "url" : "https://fhir.kbv.de/StructureDefinition/KBV_EX_FOR_StatusCoPayment",
        "valueCoding" : {
          "system" : "https://fhir.kbv.de/CodeSystem/KBV_CS_FOR_StatusCoPayment",
          "code" : "1"
        }
      },
      {
        "url" : "https://fhir.kbv.de/StructureDefinition/KBV_EX_ERP_EmergencyServicesFee",
        "valueBoolean" : false
      },
      {
        "url" : "https://fhir.kbv.de/StructureDefinition/KBV_EX_FOR_SER",
        "valueBoolean" : true
      },
      {
        "extension" : [{
          "url" : "Kennzeichen",
          "valueBoolean" : false
        }],
        "url" : "https://fhir.kbv.de/StructureDefinition/KBV_EX_ERP_Multiple_Prescription"
      },
      {
        "extension" : [{
          "url" : "Off-Label",
          "valueBoolean" : true
        },
        {
          "url" : "GebaerfaehigeFrau",
          "valueBoolean" : false
        },
        {
          "url" : "EinhaltungSicherheitsmassnahmen",
          "valueBoolean" : true
        },
        {
          "url" : "AushaendigungInformationsmaterialien",
          "valueBoolean" : true
        },
        {
          "url" : "ErklaerungSachkenntnis",
          "valueBoolean" : true
        }],
        "url" : "https://fhir.kbv.de/StructureDefinition/KBV_EX_ERP_Teratogenic"
      },
      {
        "url" : "https://fhir.kbv.de/StructureDefinition/KBV_EX_ERP_DosageFlag",
        "valueBoolean" : true
      },
      {
        "url" : "http://hl7.org/fhir/5.0/StructureDefinition/extension-MedicationRequest.renderedDosageInstruction",
        "valueMarkdown" : "0-0-1-0 Stück"
      },
      {
        "extension" : [{
          "url" : "algorithmVersion",
          "valueString" : "1.0.0"
        },
        {
          "url" : "language",
          "valueCode" : "de-DE"
        }],
        "url" : "http://ig.fhir.de/igs/medication/StructureDefinition/GeneratedDosageInstructionsMeta"
      }],
      "status" : "active",
      "intent" : "order",
      "medicationReference" : {
        "reference" : "urn:uuid:a3ca01a4-92c1-422a-87d9-ef046e94527f"
      },
      "subject" : {
        "reference" : "urn:uuid:30635f5d-c233-4500-94e8-6414940236aa"
      },
      "authoredOn" : "2025-05-20",
      "requester" : {
        "reference" : "urn:uuid:0c4e1a54-8a42-4d3d-a12c-0bbf2db48570"
      },
      "insurance" : [{
        "reference" : "urn:uuid:e51239e1-ba74-48e0-97fb-9754d2b05c60"
      }],
      "dosageInstruction" : [{
        "timing" : {
          "repeat" : {
            "frequency" : 1,
            "period" : 1,
            "periodUnit" : "d",
            "when" : ["EVE"]
          }
        },
        "doseAndRate" : [{
          "doseQuantity" : {
            "value" : 1,
            "unit" : "Stück",
            "system" : "https://fhir.kbv.de/CodeSystem/KBV_CS_SFHIR_BMP_DOSIEREINHEIT",
            "code" : "1"
          }
        }]
      }],
      "dispenseRequest" : {
        "quantity" : {
          "value" : 1,
          "unit" : "Packung"
        },
        "expectedSupplyDuration" : {
          "value" : 3,
          "unit" : "Woche(n)"
        }
      },
      "substitution" : {
        "allowedBoolean" : true
      }
    }
  },
  {
    "fullUrl" : "urn:uuid:a3ca01a4-92c1-422a-87d9-ef046e94527f",
    "resource" : {
      "resourceType" : "Medication",
      "id" : "a3ca01a4-92c1-422a-87d9-ef046e94527f",
      "meta" : {
        "versionId" : "1",
        "profile" : ["https://fhir.kbv.de/StructureDefinition/KBV_PR_ERP_Medication_PZN|1.4"]
      },
      "extension" : [{
        "url" : "https://fhir.kbv.de/StructureDefinition/KBV_EX_Base_Medication_Type",
        "valueCodeableConcept" : {
          "coding" : [{
            "system" : "http://snomed.info/sct",
            "version" : "http://snomed.info/sct/11000274103/version/20240515",
            "code" : "763158003",
            "display" : "Medicinal product (product)"
          }]
        }
      },
      {
        "url" : "https://fhir.kbv.de/StructureDefinition/KBV_EX_ERP_Medication_Category",
        "valueCoding" : {
          "system" : "https://fhir.kbv.de/CodeSystem/KBV_CS_ERP_Medication_Category",
          "code" : "02"
        }
      },
      {
        "url" : "https://fhir.kbv.de/StructureDefinition/KBV_EX_ERP_Medication_Vaccine",
        "valueBoolean" : false
      },
      {
        "url" : "http://fhir.de/StructureDefinition/normgroesse",
        "valueCode" : "N1"
      }],
      "code" : {
        "coding" : [{
          "system" : "http://fhir.de/CodeSystem/ifa/pzn",
          "code" : "19201712"
        }],
        "text" : "Pomalidomid Accord 1 mg 21 x 1 Hartkapseln"
      },
      "form" : {
        "coding" : [{
          "system" : "https://fhir.kbv.de/CodeSystem/KBV_CS_SFHIR_KBV_DARREICHUNGSFORM",
          "code" : "HKP"
        }]
      },
      "amount" : {
        "numerator" : {
          "extension" : [{
            "url" : "https://fhir.kbv.de/StructureDefinition/KBV_EX_ERP_Medication_PackagingSize",
            "valueString" : "21"
          }],
          "unit" : "Stück"
        },
        "denominator" : {
          "value" : 1
        }
      },
      "ingredient" : [{
        "itemCodeableConcept" : {
          "text" : "Pomalidomid"
        },
        "strength" : {
          "numerator" : {
            "value" : 1,
            "unit" : "mg"
          },
          "denominator" : {
            "value" : 1,
            "unit" : "Stück"
          }
        }
      }]
    }
  },
  {
    "fullUrl" : "urn:uuid:a7e1d25f-0b0a-40f7-b529-afda48e51b46",
    "resource" : {
      "resourceType" : "MedicationDispense",
      "id" : "a7e1d25f-0b0a-40f7-b529-afda48e51b46",
      "meta" : {
        "profile" : ["https://gematik.de/fhir/erp/StructureDefinition/GEM_ERP_PR_MedicationDispense|1.6"]
      },
      "identifier" : [{
        "system" : "https://gematik.de/fhir/erp/NamingSystem/GEM_ERP_NS_PrescriptionId",
        "value" : "166.100.000.000.001.39"
      }],
      "status" : "completed",
      "medicationReference" : {
        "reference" : "urn:uuid:8e2e5e65-4c5d-49f2-8efc-c30e40838273"
      },
      "subject" : {
        "identifier" : {
          "system" : "http://fhir.de/sid/gkv/kvid-10",
          "value" : "X234567890"
        }
      },
      "performer" : [{
        "actor" : {
          "identifier" : {
            "system" : "https://gematik.de/fhir/sid/telematik-id",
            "value" : "3-07.2.1234560000.10.789"
          }
        }
      }],
      "quantity" : {
        "value" : 1,
        "unit" : "Packung"
      },
      "whenHandedOver" : "2025-10-30",
      "substitution" : {
        "wasSubstituted" : true
      }
    }
  },
  {
    "fullUrl" : "urn:uuid:8e2e5e65-4c5d-49f2-8efc-c30e40838273",
    "resource" : {
      "resourceType" : "Medication",
      "id" : "8e2e5e65-4c5d-49f2-8efc-c30e40838273",
      "meta" : {
        "profile" : ["https://gematik.de/fhir/erp/StructureDefinition/GEM_ERP_PR_Medication|1.6"]
      },
      "code" : {
        "coding" : [{
          "system" : "http://fhir.de/CodeSystem/ifa/pzn",
          "code" : "19201712"
        }],
        "text" : "Pomalidomid Accord 1 mg 21 x 1 Hartkapseln"
      },
      "form" : {
        "coding" : [{
          "system" : "https://fhir.kbv.de/CodeSystem/KBV_CS_SFHIR_KBV_DARREICHUNGSFORM",
          "code" : "TAB",
          "display" : "Tabletten"
        }]
      },
      "amount" : {
        "numerator" : {
          "extension" : [{
            "url" : "https://gematik.de/fhir/epa-medication/StructureDefinition/medication-packaging-size-extension",
            "valueString" : "21"
          }],
          "unit" : "St"
        },
        "denominator" : {
          "value" : 1
        }
      },
      "ingredient" : [{
        "itemCodeableConcept" : {
          "text" : "Pomalidomid"
        },
        "strength" : {
          "numerator" : {
            "value" : 1,
            "unit" : "mg"
          },
          "denominator" : {
            "value" : 1,
            "unit" : "Tbl."
          }
        }
      }],
      "batch" : {
        "lotNumber" : "A123456789-1"
      }
    }
  },
  {
    "fullUrl" : "urn:uuid:09330307-16ce-4cdc-810a-ca24ef80dde3",
    "resource" : {
      "resourceType" : "Task",
      "id" : "09330307-16ce-4cdc-810a-ca24ef80dde3",
      "meta" : {
        "profile" : ["https://gematik.de/fhir/erp/StructureDefinition/GEM_ERP_PR_Task|1.5"],
        "tag" : [{
          "display" : "Task in COMPLETED state dispensed by pharmacy via $closed operation"
        }]
      },
      "extension" : [{
        "url" : "https://gematik.de/fhir/erp/StructureDefinition/GEM_ERP_EX_PrescriptionType",
        "valueCoding" : {
          "system" : "https://gematik.de/fhir/erp/CodeSystem/GEM_ERP_CS_FlowType",
          "code" : "166",
          "display" : "Flowtype für Arzneimittel nach § 3a AMVV"
        }
      },
      {
        "url" : "https://gematik.de/fhir/erp/StructureDefinition/GEM_ERP_EX_AcceptDate",
        "valueDate" : "2025-10-01"
      },
      {
        "url" : "https://gematik.de/fhir/erp/StructureDefinition/GEM_ERP_EX_ExpiryDate",
        "valueDate" : "2025-10-01"
      }],
      "identifier" : [{
        "system" : "https://gematik.de/fhir/erp/NamingSystem/GEM_ERP_NS_PrescriptionId",
        "value" : "166.100.000.000.001.39"
      },
      {
        "system" : "https://gematik.de/fhir/erp/NamingSystem/GEM_ERP_NS_AccessCode",
        "value" : "777bea0e13cc9c42ceec14aec3ddee2263325dc2c6c699db115f58fe423607ea"
      }],
      "status" : "completed",
      "intent" : "order",
      "for" : {
        "identifier" : {
          "system" : "http://fhir.de/sid/gkv/kvid-10",
          "value" : "X123456789"
        }
      },
      "authoredOn" : "2025-10-01T15:29:00+00:00",
      "lastModified" : "2025-10-01T16:44:00.434+00:00",
      "performerType" : [{
        "coding" : [{
          "system" : "https://gematik.de/fhir/erp/CodeSystem/GEM_ERP_CS_OrganizationType",
          "code" : "urn:oid:1.2.276.0.76.4.54",
          "display" : "Öffentliche Apotheke"
        }]
      }],
      "input" : [{
        "type" : {
          "coding" : [{
            "system" : "https://gematik.de/fhir/erp/CodeSystem/GEM_ERP_CS_DocumentType",
            "code" : "1",
            "display" : "Health Care Provider Prescription"
          }]
        },
        "valueReference" : {
          "reference" : "281a985c-f25b-4aae-91a6-41ad744080b0"
        }
      },
      {
        "type" : {
          "coding" : [{
            "system" : "https://gematik.de/fhir/erp/CodeSystem/GEM_ERP_CS_DocumentType",
            "code" : "2",
            "display" : "Patient Confirmation"
          }]
        },
        "valueReference" : {
          "reference" : "f8c2298f-7c00-4a68-af29-8a2862d55d43"
        }
      }],
      "output" : [{
        "type" : {
          "coding" : [{
            "system" : "https://gematik.de/fhir/erp/CodeSystem/GEM_ERP_CS_DocumentType",
            "code" : "3",
            "display" : "Receipt"
          }]
        },
        "valueReference" : {
          "reference" : "dffbfd6a-5712-4798-bdc8-07201eb77ab8"
        }
      }]
    }
  },
  {
    "fullUrl" : "urn:uuid:VZD-SearchSet-Bundle",
    "resource" : {
      "resourceType" : "Bundle",
      "id" : "VZD-SearchSet-Bundle",
      "meta" : {
        "lastUpdated" : "2025-06-19T08:42:40.732+02:00"
      },
      "type" : "searchset",
      "total" : 3,
      "entry" : [{
        "fullUrl" : "https://fhir-directory-ref.vzd.ti-dienste.de/search/HealthcareService/a4f1b52e-c5de-47eb-874c-990c2b39bb77",
        "resource" : {
          "resourceType" : "HealthcareService",
          "id" : "a4f1b52e-c5de-47eb-874c-990c2b39bb77",
          "meta" : {
            "versionId" : "2",
            "lastUpdated" : "2024-03-27T17:49:37.898+01:00",
            "profile" : ["http://hl7.org/fhir/StructureDefinition/HealthcareService",
            "https://gematik.de/fhir/directory/StructureDefinition/HealthcareServiceDirectory"],
            "tag" : [{
              "system" : "https://gematik.de/fhir/directory/CodeSystem/Origin",
              "code" : "owner"
            }]
          },
          "identifier" : [{
            "system" : "http://hl7.org/fhir/sid/us-npi",
            "value" : "1b9b1767-5496-4c20-bfc1-32ad6d96adbc"
          }],
          "providedBy" : {
            "reference" : "Organization/4f5a9754-2a9d-486d-9eec-a5c6b5f95016"
          },
          "location" : [{
            "reference" : "Location/9514f96e-897d-492d-950f-aea11d6f2bb4"
          }],
          "telecom" : [{
            "system" : "phone",
            "value" : "1234",
            "use" : "work"
          }],
          "endpoint" : [{
            "reference" : "Endpoint/11d91987-d31e-468f-962e-845bb0c743c3"
          }]
        },
        "search" : {
          "mode" : "match"
        }
      },
      {
        "fullUrl" : "https://fhir-directory-ref.vzd.ti-dienste.de/search/Organization/4f5a9754-2a9d-486d-9eec-a5c6b5f95016",
        "resource" : {
          "resourceType" : "Organization",
          "id" : "4f5a9754-2a9d-486d-9eec-a5c6b5f95016",
          "meta" : {
            "versionId" : "1",
            "lastUpdated" : "2023-03-23T14:14:28.492+01:00",
            "profile" : ["http://hl7.org/fhir/StructureDefinition/Organization",
            "https://gematik.de/fhir/directory/StructureDefinition/OrganizationDirectory"],
            "tag" : [{
              "system" : "https://gematik.de/fhir/directory/CodeSystem/Origin",
              "code" : "owner"
            }]
          },
          "identifier" : [{
            "system" : "http://hl7.org/fhir/sid/us-npi",
            "value" : "44bb2f53-cdd7-4098-9d52-a6c5ac0ddc8d"
          },
          {
            "type" : {
              "coding" : [{
                "system" : "http://terminology.hl7.org/CodeSystem/v2-0203",
                "code" : "PRN"
              }]
            },
            "system" : "https://gematik.de/fhir/sid/telematik-id",
            "value" : "3-07.2.1234560000.10.789"
          }],
          "active" : true,
          "type" : [{
            "coding" : [{
              "system" : "https://gematik.de/fhir/directory/CodeSystem/OrganizationProfessionOID",
              "code" : "1.2.276.0.76.4.54",
              "display" : "Öffentliche Apotheke"
            }]
          }],
          "name" : "Schwarzwald Apotheke",
          "alias" : ["Schwarzwald Apotheke"]
        },
        "search" : {
          "mode" : "include"
        }
      },
      {
        "fullUrl" : "https://fhir-directory-ref.vzd.ti-dienste.de/search/Location/9514f96e-897d-492d-950f-aea11d6f2bb4",
        "resource" : {
          "resourceType" : "Location",
          "id" : "9514f96e-897d-492d-950f-aea11d6f2bb4",
          "meta" : {
            "versionId" : "1",
            "lastUpdated" : "2023-03-23T14:14:28.492+01:00",
            "profile" : ["http://hl7.org/fhir/StructureDefinition/Location",
            "https://gematik.de/fhir/directory/StructureDefinition/LocationDirectory"],
            "tag" : [{
              "system" : "https://gematik.de/fhir/directory/CodeSystem/Origin",
              "code" : "owner"
            }]
          },
          "identifier" : [{
            "system" : "http://hl7.org/fhir/sid/us-npi",
            "value" : "995d8a48-f7fc-4ffb-a676-feb18c7c052c"
          }],
          "name" : "Location of Organisation 3-07.2.1234560000.10.789",
          "address" : {
            "use" : "work",
            "type" : "postal",
            "text" : "Schwarzwaldstr. 18&#13;&#10;63762&#13;&#10;Großostheim&#13;&#10;Bayern&#13;&#10;DE",
            "line" : ["Schwarzwaldstr. 18"],
            "city" : "Großostheim",
            "state" : "Bayern",
            "postalCode" : "63762",
            "country" : "DE"
          }
        },
        "search" : {
          "mode" : "include"
        }
      }]
    }
  }]
}

```
