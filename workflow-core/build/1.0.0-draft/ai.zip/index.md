# Implementation Guide E-Rezept-Workflow Core - Implementation Guide E-Rezept-Workflow Core v1.0.0-draft

Implementation Guide

E-Rezept-Workflow Core

Version 1.0.0-draft - ci-build 

* [**Table of Contents**](toc.md)
* **Implementation Guide E-Rezept-Workflow Core**

## Implementation Guide E-Rezept-Workflow Core

| | |
| :--- | :--- |
| *Official URL*:https://gematik.de/fhir/workflow/core/ImplementationGuide/de.gematik.workflow.core | *Version*:1.0.0-draft |
| Draft as of 2026-03-16 | *Computable Name*:gemIG_TIFlow_core |

Dieser IG beschreibt die zentralen, IG-übergreifenden Anforderungen an den E-Rezept-Fachdienst. Er fasst grundlegende Sicherheits-, Protokollierungs- und Validierungsvorgaben zusammen, die in allen nachgelagerten IGs wiederverwendet werden.

## Zweck und Geltungsbereich

Der Core-IG fokussiert auf die technische Basisschicht des Fachdienstes:

* Zugriffs- und Systemprotokollierung (AuditEvent)
* Datenschutz und Sicherheit, insbesondere Anforderungen an die VAU
* Validierung von FHIR-Ressourcen und Bundles
* Löschfristen und automatisches Löschen
* Modulübergreifende Operationen auf Task ($create, $activate, $abort, …)

### Anforderungen zur Umsetzung des IGs

Der E-Rezept-Fachdienst MUSS den Implementation Guide "E-Rezept-Workflow Core" umsetzen.

Der E-Rezept-Fachdienst MUSS zur Umsetzung des Implementation Guides "E-Rezept-Workflow Core" alle Anforderungen und FHIR-Artefakte umsetzen, die in diesem IG definiert sind.
## Aufbau

* [Zugriffsprotokollierung](./audit-service.md)
* [Datenschutz und Sicherheit](./data-security.md)
* [FHIR-Validierung](./fhir-validate.md)
* [Löschfristen](./ttl.md)
* [Verbindungsaufbau Clientsysteme (über IDP-Dienst)](./verbindungsaufbau-client.md)
* [Query API (modulübergreifend)](./query-api.md)
* [Operation API (modulübergreifend)](./operation-api.md)
* [FHIR-Artefakte](./artifacts.md)

## Bezug zu weiteren IGs

Dieser IG enthält nur die gemeinsamen Vorgaben. Fachliche und prozessspezifische Details werden in den jeweiligen IGs dokumentiert.

