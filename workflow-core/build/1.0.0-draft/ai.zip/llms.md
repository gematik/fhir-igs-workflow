# de.gematik.workflow.core#1.0.0-draft: Implementation Guide E-Rezept-Workflow Core

## Pages

* [](index.md)
* [Client-Anforderungen $activate](op-activate-req-pvs.md)
* [Client-Anforderungen $accept](op-accept-req-avs.md)
* [Client-Anforderungen $abort](op-abort-client-requirements.md)
* [Client-Anforderungen: Communication-Query](query-api-communication-client-requirements.md)
* [FHIR-Ressource validieren](fhir-validate.md)
* [Server-Anforderungen $close](op-close-req-fd.md)
* [Server-Anforderungen $accept](op-accept-req-fd.md)
* [Operation $abort (Task abbrechen)](op-abort.md)
* [Client-Anforderungen: Device-Query](query-api-device-client-requirements.md)
* [Datenschutz und Sicherheit](data-security.md)
* [FD-Anforderungen: AuditEvent-Query](query-api-auditevent-req-fd.md)
* [FD-Anforderungen: Device-Query](query-api-device-req-fd.md)
* [Operation $accept (Task akzeptieren)](op-accept.md)
* [Server-Anforderungen $activate](op-activate-req-fd.md)
* [Client-Anforderungen: Consent-Query](query-api-consent-req-fdv.md)
* [Server-Anforderungen $create](op-create-req-fd.md)
* [Client-Anforderungen $close](op-close-req-avs.md)
* [Server-Anforderungen $reject](op-reject-req-fd.md)
* [Query API](menu-schnittstellen-query-api.md)
* [FHIR-Artefakte](artifacts.md)
* [Query API: Communication](query-api-communication.md)
* [Client-Anforderungen: AuditEvent-Query](query-api-auditevent-req-fdv.md)
* [FD-Anforderungen: Consent-Query](query-api-consent-req-fd.md)
* [Operation $activate (Task aktivieren)](op-activate.md)
* [FD-Anforderungen: Communication-Query](query-api-communication-req-fd.md)
* [Zugriffsprotokollierung](audit-service.md)
* [Operation $reject (Task zurückweisen)](op-reject.md)
* [Operation $create (Task erzeugen)](op-create.md)
* [Operation $close (Task schließen)](op-close.md)
* [Operation API](menu-schnittstellen-operation-api.md)
* [Client-Anforderungen $reject](op-reject-client-requirements.md)
* [Query API: AuditEvent](query-api-auditevent.md)
* [Query API: Consent](query-api-consent.md)
* [Client-Anforderungen $create](op-create-req-pvs.md)
* [Query API: Device](query-api-device.md)
* [Löschfristen](ttl.md)
* [Server-Anforderungen $abort](op-abort-req-fd.md)

## Resources

### CapabilityStatements

* [ERP Capability Statement für Clients des E-Rezept-Fachdienst](CapabilityStatement-erp-fachdienst-client.md)
* [ERP CapabilityStatement für den E-Rezept-Fachdienst](CapabilityStatement-erp-fachdienst-server.md)

### ImplementationGuides

* [Implementation Guide E-Rezept-Workflow Core](index.md)
