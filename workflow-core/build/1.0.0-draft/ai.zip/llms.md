# de.gematik.workflow.core#1.0.0-draft: Implementation Guide E-Rezept-Workflow Core

## Pages

* [](index.md)
* [Client-Anforderungen: AuditEvent-Query](query-api-auditevent-client-requirements.md)
* [FD-Anforderungen: Communication-Query](query-api-communication-fd-requirements.md)
* [Server-Anforderungen $close](op-close-fd-requirements.md)
* [Server-Anforderungen $activate](op-activate-fd-requirements.md)
* [Client-Anforderungen $abort](op-abort-client-requirements.md)
* [Client-Anforderungen: Communication-Query](query-api-communication-client-requirements.md)
* [FHIR-Ressource validieren](fhir-validate.md)
* [Server-Anforderungen $accept](op-accept-fd-requirements.md)
* [Operation $abort (Task abbrechen)](op-abort.md)
* [Client-Anforderungen: Device-Query](query-api-device-client-requirements.md)
* [Datenschutz und Sicherheit](data-security.md)
* [Operation $accept (Task akzeptieren)](op-accept.md)
* [Client-Anforderungen $close](op-close-client-requirements.md)
* [Query API](menu-schnittstellen-query-api.md)
* [FHIR-Artefakte](artifacts.md)
* [Client-Anforderungen $create](op-create-client-requirements.md)
* [FD-Anforderungen: AuditEvent-Query](query-api-auditevent-fd-requirements.md)
* [Query API: Communication](query-api-communication.md)
* [Client-Anforderungen $accept](op-accept-client-requirements.md)
* [Operation $activate (Task aktivieren)](op-activate.md)
* [Zugriffsprotokollierung](audit-service.md)
* [Server-Anforderungen $create](op-create-fd-requirements.md)
* [Operation $reject (Task zurückweisen)](op-reject.md)
* [Operation $create (Task erzeugen)](op-create.md)
* [Server-Anforderungen $reject](op-reject-fd-requirements.md)
* [Server-Anforderungen $abort](op-abort-fd-requirements.md)
* [Operation $close (Task schließen)](op-close.md)
* [Operation API](menu-schnittstellen-operation-api.md)
* [Client-Anforderungen $reject](op-reject-client-requirements.md)
* [Query API: AuditEvent](query-api-auditevent.md)
* [FD-Anforderungen: Device-Query](query-api-device-fd-requirements.md)
* [Client-Anforderungen $activate](op-activate-client-requirements.md)
* [Query API: Device](query-api-device.md)
* [Loeschfristen](ttl.md)

## Resources

### CapabilityStatements

* [ERP Capability Statement für Clients des E-Rezept-Fachdienst](CapabilityStatement-erp-fachdienst-client.md)
* [ERP CapabilityStatement für den E-Rezept-Fachdienst](CapabilityStatement-erp-fachdienst-server.md)

### ImplementationGuides

* [Implementation Guide E-Rezept-Workflow Core](index.md)
