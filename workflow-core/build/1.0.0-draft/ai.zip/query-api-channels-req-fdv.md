# FdV-Anforderungen: channels-Query - Implementation Guide E-Rezept-Workflow Core v1.0.0-draft

Implementation Guide

E-Rezept-Workflow Core

Version 1.0.0-draft - ci-build 

* [**Table of Contents**](toc.md)
* [**Query API**](menu-schnittstellen-query-api.md)
* [**Query API: channels**](query-api-channels.md)
* **FdV-Anforderungen: channels-Query**

## FdV-Anforderungen: channels-Query

Diese Seite beschreibt Anforderungen an das E-Rezept-FdV zur Nutzung der `Channels`-Query-Endpunkte.

Die Funktionalität zu Push Notification für FdVs ist anwendungsübergreifend in [gemF_PushNotification] beschrieben. In diesem Kapitel werden die zusätzlichen E-Rezept spezifischen Anforderungen beschrieben.

Das E-Rezept-FdV MUSS, wenn es den Anwendungsfall "Push Notifications" umsetzt, für die Registrierung und Verwaltung der Channels für die FdV-Instanzen des Versicherten am E-Rezept-Fachdienst die Operationen gemäß [OpenAPI_FD] verwenden.

