# de.gematik.tiflow#2.0.0-ballot.2: Implementation Guide TIFlow - Kernfunktionalitäten

## Pages

* [Implementation Guide TI-Flow Kernfunktionaliten](index.md)
* [Operation $abort (Task abbrechen)](op-abort.md)
* [Architekturmöglichkeiten TI-Flow-Fachdienst](architecture.md)
* [Server-Anforderungen: Device-Query](query-api-device-req-fd.md)
* [Client-Anforderungen $activate](op-activate-req-pvs.md)
* [KTR-Anforderungen $accept](op-accept-req-ktr.md)
* [Fehlercodes](error-codes.md)
* [Server-Anforderungen: MedicationDispense-Query](query-api-medicationdispense-req-fd.md)
* [Technische Umsetzung - Systemüberblick](menu-technische-umsetzung-systemueberblick.md)
* [FdV-Anforderungen: MedicationDispense-Query](query-api-medicationdispense-req-fdv.md)
* [Query API: MedicationDispense](query-api-medicationdispense.md)
* [Query API: Communication](query-api-communication.md)
* [Datenschutz und Sicherheit](menu-schnittstellen-datenschutz-und-sicherheit.md)
* [FdV-Anforderungen $abort](op-abort-req-fdv.md)
* [Zugriffsprotokollierung](audit-service.md)
* [Operation API](menu-schnittstellen-operation-api.md)
* [Data Matrix Code](datamatrix-code-client.md)
* [KTR-Anforderungen $close](op-close-req-ktr.md)
* [KTR-Anforderungen $reject](op-reject-req-ktr.md)
* [FdV-Anforderungen: Communication-Query](query-api-communication-req-fdv.md)
* [Anforderungen zur Fehlerbehandlung](error-codes-req-fd.md)
* [Query API: Channels](query-api-channels.md)
* [Server-Anforderungen: Communication-Query](query-api-communication-req-fd.md)
* [Query API](menu-schnittstellen-query-api.md)
* [Release Notes](release-notes.md)
* [AVS-Anforderungen $accept](op-accept-req-avs.md)
* [Operation $close (Task schließen)](op-close.md)
* [Server-Anforderungen $accept](op-accept-req-fd.md)
* [Server-Anforderungen: Task-Query](query-api-task-req-fd.md)
* [Nutzung ZETA durch Clientsystme](zeta-client.md)
* [Query API: Consent](query-api-consent.md)
* [AVS-Anforderungen: Subscription](query-api-subscription-req-avs.md)
* [Server-Anforderungen $activate](op-activate-req-fd.md)
* [Operation $create (Task erzeugen)](op-create.md)
* [Server-Anforderungen: Channels-Query](query-api-channels-req-fd.md)
* [Operation $accept (Task akzeptieren)](op-accept.md)
* [Kommunikation zu Diensten der TI](kommunikation-dienste-ti.md)
* [Server-Anforderungen: AuditEvent-Query](query-api-auditevent-req-fd.md)
* [Health Check](health-check.md)
* [Server-Anforderungen $reject](op-reject-req-fd.md)
* [FdV-Anforderungen: Pushers-Query](query-api-pushers-req-fdv.md)
* [Generelle Prinzipien](menu-schnittstellen-generelle-prinzipien.md)
* [Mapping alter Anforderungen auf FHIR-IG Anforderungen](requirement-mapping-0_9_0-to-2_0_0.md)
* [FHIR-Artefakte](artifacts.md)
* [KTR-Anforderungen: Subscription](query-api-subscription-req-ktr.md)
* [Client-Anforderungen: Consent-Query](query-api-consent-req-fdv.md)
* [Konfiguration des TI-Flow-Fachdienst](capability-statement-extensions.md)
* [Query API: Pushers](query-api-pushers.md)
* [Query API: Device](query-api-device.md)
* [Client-Anforderungen $create](op-create-req-pvs.md)
* [AVS-Anforderungen $close](op-close-req-avs.md)
* [Fehlerbehandlung Clientsysteme](fehlerbehandlung-client.md)
* [Query API: AuditEvent](query-api-auditevent.md)
* [Anforderungslisten](requirements.md)
* [Server-Anforderungen $close](op-close-req-fd.md)
* [Server-Anforderungen: Subscription](query-api-subscription-req-fd.md)
* [Server-Anforderungen: Consent-Query](query-api-consent-req-fd.md)
* [FdV-Anforderungen: Task-Query](query-api-task-req-fdv.md)
* [Server-Anforderungen $create](op-create-req-fd.md)
* [Technische Umsetzung - Notifications für Clientsysteme](menu-technische-umsetzung-subscription.md)
* [Additional API](menu-schnittstellen-additional-api.md)
* [Technische Umsetzung - Push Notification](menu-technische-umsetzung-push.md)
* [AVS-Anforderungen: Communication-Query](query-api-communication-req-avs.md)
* [Operation $reject (Task zurückweisen)](op-reject.md)
* [FdV-Anforderungen: Device-Query](query-api-device-req-fdv.md)
* [Apache License](license.md)
* [FHIR-Ressource validieren](fhir-validate.md)
* [Additional API: Subscription](query-api-subscription.md)
* [FdV-Anforderungen: AuditEvent-Query](query-api-auditevent-req-fdv.md)
* [Query API: Task](query-api-task.md)
* [AVS-Anforderungen $reject](op-reject-req-avs.md)
* [Löschfristen](ttl.md)
* [PVS-Anforderungen $abort](op-abort-req-pvs.md)
* [AVS-Anforderungen: Task-Query](query-api-task-req-avs.md)
* [AVS-Anforderungen $abort](op-abort-req-avs.md)
* [KTR-Anforderungen: Communication-Query](query-api-communication-req-ktr.md)
* [Technische Umsetzung - ePA Medication Service](menu-technische-umsetzung-epa-ms.md)
* [Operation $activate (Task aktivieren)](op-activate.md)
* [FdV-Anforderungen: Channels-Query](query-api-channels-req-fdv.md)
* [Zertifikatsprüfung](pki-zertifikatspruefung.md)
* [Technische Umsetzung - Zero Trust Access (ZETA)](menu-technische-umsetzung-zeta.md)
* [KTR-Anforderungen: Task-Query](query-api-task-req-ktr.md)
* [Server-Anforderungen: Pushers-Query](query-api-pushers-req-fd.md)
* [Server-Anforderungen $abort](op-abort-req-fd.md)

## Resources

### CodeSystems

* [CodeSystem des Verfügbarkeitsstatus](CodeSystem-GEM-ERP-CS-AvailabilityStatus.md)
* [CodeSystem der Dokumententypen](CodeSystem-GEM-ERP-CS-DocumentType.md)
* [CodeSystem der Flowtypes in TIFlow Anwendungen](CodeSystem-GEM-ERP-CS-FlowType.md)
* [TIFLOW Operation Outcome Details CS](CodeSystem-tiflow-operation-outcome-details-cs.md)

### ValueSets

* [ValueSet der Verfügbarkeitsstatus-Codes](ValueSet-GEM-ERP-VS-AvailabilityStatus.md)
* [ValueSet der Dokumenttyp-Codes](ValueSet-GEM-ERP-VS-DocumentType.md)
* [ValueSet der Flowtypes in TIFlow Anwendungen](ValueSet-GEM-ERP-VS-FlowType.md)
* [TIFlow AuditEvent Agent Type ValueSet](ValueSet-tiflow-audit-event-agent-type-vs.md)
* [TIFLOW Operation Outcome Details VS](ValueSet-tiflow-operation-outcome-details-vs.md)
* [TIFlow Order Task ValueSet](ValueSet-tiflow-order-task-status-vs.md)

### Logicals

* [TI Feature Definition](StructureDefinition-ti-feature-definition.md)
* [Feature: WF160 - Flowtype für Apothekenpflichtige Arzneimittel](StructureDefinition-ti-flow-feature-wf160.md)
* [Feature: WF169 - Flowtype für Apothekenpflichtige Arzneimittel mit Steuerung durch den Leistungserbringer](StructureDefinition-ti-flow-feature-wf169.md)

### Complex-type Profiles

* [GEM_ERP_PR_Signature](StructureDefinition-GEM-ERP-PR-Signature.md)

### Resource Profiles

* [GEM ERP PR Binary](StructureDefinition-GEM-ERP-PR-Binary.md)
* [TIFlow Receipt Bundle](StructureDefinition-GEM-ERP-PR-Bundle.md)
* [GEM ERP PR Composition](StructureDefinition-GEM-ERP-PR-Composition.md)
* [GEM ERP PR Device](StructureDefinition-GEM-ERP-PR-Device.md)
* [GEM ERP PR Digest](StructureDefinition-GEM-ERP-PR-Digest.md)
* [TI Audit Event Rest](StructureDefinition-audit-event-rest.md)
* [Generische TIFlow Communication](StructureDefinition-tiflow-communication.md)
* [Bundle der $accept Operation](StructureDefinition-tiflow-op-accept-bundle.md)
* [TIFlow OperationOutcome](StructureDefinition-tiflow-operation-outcome.md)
* [Task für TIFlow Verordnungen](StructureDefinition-tiflow-order-task.md)

### Extensions

* [TI Flow AcceptDate](StructureDefinition-GEM-ERP-EX-AcceptDate.md)
* [TIFlow Beneficiary](StructureDefinition-GEM-ERP-EX-Beneficiary.md)
* [TI Flow ExpiryDate](StructureDefinition-GEM-ERP-EX-ExpiryDate.md)
* [TI Flow Type](StructureDefinition-GEM-ERP-EX-PrescriptionType.md)

### CapabilityStatements

* [CapabilityStatement für den TI-Flow-Fachdienst](CapabilityStatement-ti-flow-fachdienst-server.md)

### ConceptMaps

* [Telemetry Data Status Codes Concept Map](ConceptMap-TIFLOW-CM-TelemetryDataStatusCodes.md)

### ImplementationGuides

* [Implementation Guide TIFlow - Kernfunktionalitäten](index.md)

### SearchParameters

* [TaskAcceptDateSP](SearchParameter-TaskAcceptDateSP.md)
* [TaskExpiryDateSP](SearchParameter-TaskExpiryDateSP.md)

### Examples

* [ExampleCapabilityStatementServerPU (CapabilityStatement)](CapabilityStatement-ExampleCapabilityStatementServerPU.md)
* [erp-notification-avs-01-request-PostSubscriptionPseudo (Subscription)](Subscription-erp-notification-avs-01-request-PostSubscriptionPseudo.md)
* [erp-notification-avs-02-response-PostSubscriptionPseudo (Subscription)](Subscription-erp-notification-avs-02-response-PostSubscriptionPseudo.md)
