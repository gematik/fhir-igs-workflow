# Operation API - TIFlow - Kernfunktionalitäten v2.0.0-ballot.1

TIFlow - Kernfunktionalitäten

Version 2.0.0-ballot.1 - ci-build 

* [**Table of Contents**](toc.md)
* **Operation API**

## Operation API

Die folgenden Operation APIs stellt der TI-Flow-Fachdienst zur verfügung

* Primärsystem: [Operation API: E-Rezept erstellen](./op-create.md)
* Primärsystem: [Operation API: E-Rezept aktivieren](./op-activate.md)
* Primärsystem: [Operation API: Task abrufen](./op-accept.md)
* Primärsystem: [Operation API: Task zurückweisen](./op-reject.md)
* Primärsystem: [Operation API: Task schließen](./op-close.md)
* Primärsystem / E-Rezept-FdV: [Operation API: E-Rezept löschen](./op-abort.md)

