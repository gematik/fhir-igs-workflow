# Implementation Guide TI-Flow Core - TIFlow - Kernfunktionalitäten v1.0.0-draft

TIFlow - Kernfunktionalitäten

Version 1.0.0-draft - ci-build 

* [**Table of Contents**](toc.md)
* **Implementation Guide TI-Flow Core**

## Implementation Guide TI-Flow Core

| | |
| :--- | :--- |
| *Official URL*:https://gematik.de/fhir/tiflow/core/ImplementationGuide/de.gematik.tiflow.core | *Version*:1.0.0-draft |
| Draft as of 2026-03-26 | *Computable Name*:gemIG_TIFlow_core |

Dieser IG beschreibt die zentralen, IG-übergreifenden Anforderungen an den TI-Flow-Fachdienst. Er fasst grundlegende Sicherheits-, Protokollierungs- und Validierungsvorgaben zusammen, die in allen nachgelagerten IGs wiederverwendet werden.

## Zweck und Geltungsbereich

Der Core-IG fokussiert auf die technische Basisschicht des Fachdienstes:

* Verbindungsaufbau der Clientsysteme zum TI-Flow-Fachdienst
* Validierung von FHIR-Ressourcen und Bundles
* Modulübergreifende Operationen auf Task ($create, $activate, $abort, …)
* Zugriffs- und Systemprotokollierung (AuditEvent)
* Löschfristen und automatisches Löschen

### Anforderungen zur Umsetzung des IGs

funkt. Eignung: HerstellererklärungDer TI-Flow-Fachdienst MUSS den Implementation Guide "E-Rezept-Workflow Core" umsetzen.

funkt. Eignung: HerstellererklärungDer TI-Flow-Fachdienst MUSS zur Umsetzung des Implementation Guides "E-Rezept-Workflow Core" alle Anforderungen und FHIR-Artefakte umsetzen, die in diesem IG definiert sind.
## Aufbau

* [FHIR-Artefakte](./artifacts.md)
* [FHIR-Validierung](./fhir-validate.md)
* [Query API (modulübergreifend)](./query-api.md)
* [Operation API (modulübergreifend)](./operation-api.md)
* [Zugriffsprotokollierung](./audit-service.md)
* [Löschfristen](./ttl.md)

## Bezug zu weiteren IGs

Dieser IG enthält nur die gemeinsamen Vorgaben. Fachliche und prozessspezifische Details werden in den jeweiligen IGs dokumentiert.

