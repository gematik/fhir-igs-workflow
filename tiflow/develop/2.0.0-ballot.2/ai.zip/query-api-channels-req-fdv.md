# FdV-Anforderungen: Channels-Query - TIFlow - Kernfunktionalitäten v2.0.0-ballot.2

TIFlow - Kernfunktionalitäten

Version 2.0.0-ballot.2 - ci-build 

* [**Table of Contents**](toc.md)
* [**Additional API**](menu-schnittstellen-additional-api.md)
* [**Query API: Channels**](query-api-channels.md)
* **FdV-Anforderungen: Channels-Query**

## FdV-Anforderungen: Channels-Query

Diese Seite beschreibt Anforderungen an das E-Rezept-FdV zur Nutzung der `Channels`-Query-Endpunkte.

Die Funktionalität zu Push Notification für FdVs ist anwendungsübergreifend in [gemF_PushNotification] beschrieben. In diesem Kapitel werden die zusätzlichen E-Rezept spezifischen Anforderungen beschrieben.

funkt. Eignung: Test Produkt/FADas E-Rezept-FdV MUSS, wenn es den Anwendungsfall "Push Notifications" umsetzt, für die Registrierung und Verwaltung der Channels für die FdV-Instanzen des Versicherten am TI-Flow-Fachdienst die Operationen gemäß [OpenAPI_FD] verwenden.

