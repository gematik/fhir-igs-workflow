# FHIR-Artefakte - Implementation Guide TIFlow - Kernfunktionalitäten v2.0.0-ballot.3

Implementation Guide

TIFlow - Kernfunktionalitäten

Version 2.0.0-ballot.3 - ballot 

* [**Table of Contents**](toc.md)
* **FHIR-Artefakte**

## FHIR-Artefakte

Diese Seite enthält eine Übersicht aller FHIR-Artefakte, die im Rahmen dieses Implementation Guide definiert werden. Sie bilden die Grundlage für die strukturierte Abbildung und Verarbeitung von Daten. Dazu gehören Profile zur Spezifizierung von Ressourcen, ein **Capability Statement** zur Beschreibung der unterstützten Funktionen sowie **Operation Definitions**, die spezielle FHIR-Operationen für den Abruf und die Verwaltung der Daten festlegen.

### Terminologien: Value Sets

Die folgenden Value Sets sind für die TIFlow-Funktionalitäten festgelegt.

| | |
| :--- | :--- |
| [ TIFlow Order Task ValueSet ](ValueSet-tiflow-order-task-status-vs.md) | TIFlow Order Task ValueSet |

**Tabelle:**Value Sets

### Terminologien: Code Systems

| | |
| :--- | :--- |
| [ TIFLOW Operation Outcome Details CS ](CodeSystem-tiflow-operation-outcome-details-cs.md) | Codes, die im Rahmen des TIFlow in den OperationOutcomes.details angegeben werden können |

**Tabelle:**Code Systems

### Logical Models

| | |
| :--- | :--- |
| [ TI Feature Definition ](StructureDefinition-ti-feature-definition.md) | Logical Model zur Beschreibung eines aktivierbaren Features. |

**Tabelle:**Logical Models

### Funktions Definition

| | |
| :--- | :--- |
| [ Implementation Guide TIFlow - Kernfunktionalitäten ](index.md) | - |
| [ - ](CapabilityStatement-ExampleCapabilityStatementServerPU.md) | - |
| [ CapabilityStatement für den TI-Flow-Fachdienst ](CapabilityStatement-ti-flow-fachdienst-server.md) | CapabilityStatement für den TI-Flow-Fachdienst |
| [ CodeSystem des Verfügbarkeitsstatus ](CodeSystem-GEM-ERP-CS-AvailabilityStatus.md) | Typ des Verfügbarkeitsstatus für die Anfrage zur Medikamentenverfügbarkeit. |
| [ CodeSystem der Dokumententypen ](CodeSystem-GEM-ERP-CS-DocumentType.md) | Dokumententyp abhängig vom Empfänger des Bundles. |
| [ CodeSystem der Flowtypes in TIFlow Anwendungen ](CodeSystem-GEM-ERP-CS-FlowType.md) | Zeigt die verschiedenen Typen der TI Workflows entsprechend der Verordnungsformulare. WICHTIG: Der Codebereich 9xx ist reserviert für Abrechnungsprozesse in Apotheken wie z.B. Pharmazeutische Dienstleistungen! |
| [ TIFLOW Operation Outcome Details CS ](CodeSystem-tiflow-operation-outcome-details-cs.md) | Codes, die im Rahmen des TIFlow in den OperationOutcomes.details angegeben werden können |
| [ Telemetry Data Status Codes Concept Map ](ConceptMap-TIFLOW-CM-TelemetryDataStatusCodes.md) | Maps operation outcome codes to the telemetry data status codes |
| [ Validieren einer FHIR-Ressource ](OperationDefinition-tiflow-core-validate-op.md) | Diese Operation validiert eine FHIR-Ressource gegen eine konfigurierbare FHIR-Konfiguration. Sie erweitert die standardisierte FHIR $validate-Operation (http://hl7.org/fhir/OperationDefinition/Resource-validate) um einen gematik-spezifischen `fhir_config` Parameter zur Auswahl der Validierungskonfiguration. Mit dem Parameter `returnBoolean` kann wahlweise ein kompaktes boolesches Ergebnis (`true`/`false`) angefordert werden, anstelle eines vollständigen OperationOutcome. |
| [ TaskAcceptDateSP ](SearchParameter-TaskAcceptDateSP.md) | Das Einlösedatum eines E-Rezeptes. Nach Ablaufen dieses Datums darf ein E-Rezept nicht mehr zu Lasten des Kostenträgers abgegeben werden. |
| [ TaskExpiryDateSP ](SearchParameter-TaskExpiryDateSP.md) | Das Ablaufdatum eines E-Rezepzes. Nach ablauf dieses Datums darf ein E-Rezept nicht mehr beliefert werden. |
| [ TI Flow AcceptDate ](StructureDefinition-GEM-ERP-EX-AcceptDate.md) | Diese Extension sollte in der Task-Ressource verwendet werden. Sie speichert das Datum, bis zu dem eine Krankenkasse die Verschreibung akzeptiert und bezahlt. |
| [ TIFlow Beneficiary ](StructureDefinition-GEM-ERP-EX-Beneficiary.md) | Der Begünstigte (z. B. Apotheke) der Quittung eines TIFlow Vorgangs, der erstellt wird, wenn der Workflow abgeschlossen ist. |
| [ TI Flow ExpiryDate ](StructureDefinition-GEM-ERP-EX-ExpiryDate.md) | Diese Erweiterung sollte in der Task-Ressource verwendet werden. Sie zeigt das Ablaufdatum des Rezepts an. |
| [ TI Flow Type ](StructureDefinition-GEM-ERP-EX-PrescriptionType.md) | Definiert den Typ eines Workflows im TIFlow. |
| [ GEM ERP PR Binary ](StructureDefinition-GEM-ERP-PR-Binary.md) | PKCS7 signiertes Bundle im enveloping style |
| [ TIFlow Receipt Bundle ](StructureDefinition-GEM-ERP-PR-Bundle.md) | Dokumentenbündel für Quittung |
| [ GEM ERP PR Composition ](StructureDefinition-GEM-ERP-PR-Composition.md) | Composition für die Quittung für die Einlösung eines E-Rezepts |
| [ GEM ERP PR Device ](StructureDefinition-GEM-ERP-PR-Device.md) | Statische Informationen auf dem TI-Flow-Fachdienst |
| [ GEM ERP PR Digest ](StructureDefinition-GEM-ERP-PR-Digest.md) | QES-Digest in Binary |
| [ GEM_ERP_PR_Signature ](StructureDefinition-GEM-ERP-PR-Signature.md) | Profil für die Signatur von Bundles im E-Rezept-Kontext |
| [ TI Audit Event Rest ](StructureDefinition-audit-event-rest.md) | Das AuditEvent-Profil für die Protokollierung des Zugriffs auf einen FHIR Data Service der Telematikinfrastruktur (TI) |
| [ TI Feature Definition ](StructureDefinition-ti-feature-definition.md) | Logical Model zur Beschreibung eines aktivierbaren Features. |
| [ TIFlow CORE Validate Operation Input ](StructureDefinition-ti-flow-core-validate-operation-input.md) | Dieses Profil definiert die Eingabeparameter für die $validate-Operation des TI-Flow-Fachdienstes. |
| [ TIFlow CORE Validate Operation Output ](StructureDefinition-ti-flow-core-validate-operation-output.md) | Dieses Profil definiert die Ausgabeparameter für die $validate-Operation des TI-Flow-Fachdienstes. |
| [ Generische TIFlow Communication ](StructureDefinition-tiflow-communication.md) | Generische TIFlow Workflow-Communication |
| [ Bundle der $accept Operation ](StructureDefinition-tiflow-op-accept-bundle.md) | Antwort des TI-Flow-Fachdienst auf die $accept-Operation |
| [ TIFlow OperationOutcome ](StructureDefinition-tiflow-operation-outcome.md) | OperationOutcome für Angabe von Fehlermeldungen vom TI-Flow-Fachdienst |
| [ Task für TIFlow Verordnungen ](StructureDefinition-tiflow-order-task.md) | Task für die Verwaltung von Workflows der TIFlow Verordnungen |
| [ - ](Subscription-erp-notification-avs-01-request-PostSubscriptionPseudo.md) | - |
| [ - ](Subscription-erp-notification-avs-02-response-PostSubscriptionPseudo.md) | - |
| [ ValueSet der Verfügbarkeitsstatus-Codes ](ValueSet-GEM-ERP-VS-AvailabilityStatus.md) | Art des Verfügbarkeitsstatus für die Verfügbarkeitsanfrage von Medikamenten |
| [ ValueSet der Dokumenttyp-Codes ](ValueSet-GEM-ERP-VS-DocumentType.md) | Art der Dokumente je nach Empfänger. |
| [ ValueSet der Flowtypes in TIFlow Anwendungen ](ValueSet-GEM-ERP-VS-FlowType.md) | Zeigt die verschiedenen Typen der TI Workflows entsprechend der Verordnungsformulare. |
| [ TIFlow AuditEvent Agent Type ValueSet ](ValueSet-tiflow-audit-event-agent-type-vs.md) | AuditEvent agent type (client) |
| [ TIFLOW Operation Outcome Details VS ](ValueSet-tiflow-operation-outcome-details-vs.md) | Codes, die im Rahmen des TIFlow in den OperationOutcomes.details angegeben werden können |
| [ TIFlow Order Task ValueSet ](ValueSet-tiflow-order-task-status-vs.md) | TIFlow Order Task ValueSet |

**Tabelle:**Funktions Definition

### Systemverhalten

#### Capability Statements

Das **Capability** **Statement** beschreibt die Anforderungen und Fähigkeiten, die ein Server für die konforme Implementierung des TIFlow Fachdienstes umsetzen muss. Es handelt sich um eine Konformitätserklärung, die spezifiziert, welche Ressourcen, Interaktionen und Suchparameter das der TIFlow Fachdienste unterstützen muss.

| | |
| :--- | :--- |
| [ - ](CapabilityStatement-ExampleCapabilityStatementServerPU.md) | - |
| [ CapabilityStatement für den TI-Flow-Fachdienst ](CapabilityStatement-ti-flow-fachdienst-server.md) | CapabilityStatement für den TI-Flow-Fachdienst |

**Tabelle:**Capability Statements

#### Operation Outcomes

| | |
| :--- | :--- |
| [ TIFLOW Operation Outcome Details CS ](CodeSystem-tiflow-operation-outcome-details-cs.md) | Codes, die im Rahmen des TIFlow in den OperationOutcomes.details angegeben werden können |
| [ TIFlow OperationOutcome ](StructureDefinition-tiflow-operation-outcome.md) | OperationOutcome für Angabe von Fehlermeldungen vom TI-Flow-Fachdienst |
| [ TIFLOW Operation Outcome Details VS ](ValueSet-tiflow-operation-outcome-details-vs.md) | Codes, die im Rahmen des TIFlow in den OperationOutcomes.details angegeben werden können |

**Tabelle:**Operation Outcomes

### Telemetriedaten

| | |
| :--- | :--- |
| [ Telemetry Data Status Codes Concept Map ](ConceptMap-TIFLOW-CM-TelemetryDataStatusCodes.md) | Maps operation outcome codes to the telemetry data status codes |

**Tabelle:**Telemetriedaten Status Codes

### Ressourcenprofile

| | |
| :--- | :--- |
| [ Generische TIFlow Communication ](StructureDefinition-tiflow-communication.md) | Generische TIFlow Workflow-Communication |
| [ Bundle der $accept Operation ](StructureDefinition-tiflow-op-accept-bundle.md) | Antwort des TI-Flow-Fachdienst auf die $accept-Operation |
| [ Task für TIFlow Verordnungen ](StructureDefinition-tiflow-order-task.md) | Task für die Verwaltung von Workflows der TIFlow Verordnungen |

**Tabelle:**Ressourcenprofile

### Legacy-Artefakte

Diese Sektion enthält FHIR-Artefakte, deren kanonische URL bewusst auf einem vorherigen Stand belassen wurde. Dadurch bleibt die Rückwärtskompatibilität für bestehende Implementierungen erhalten.

#### Legacy Terminologien: Code Systems

| | |
| :--- | :--- |
| [ CodeSystem des Verfügbarkeitsstatus ](CodeSystem-GEM-ERP-CS-AvailabilityStatus.md) | Typ des Verfügbarkeitsstatus für die Anfrage zur Medikamentenverfügbarkeit. |
| [ CodeSystem der Dokumententypen ](CodeSystem-GEM-ERP-CS-DocumentType.md) | Dokumententyp abhängig vom Empfänger des Bundles. |
| [ CodeSystem der Flowtypes in TIFlow Anwendungen ](CodeSystem-GEM-ERP-CS-FlowType.md) | Zeigt die verschiedenen Typen der TI Workflows entsprechend der Verordnungsformulare. WICHTIG: Der Codebereich 9xx ist reserviert für Abrechnungsprozesse in Apotheken wie z.B. Pharmazeutische Dienstleistungen! |

**Tabelle:**Legacy Code Systems

#### Legacy Terminologien: Value Sets

| | |
| :--- | :--- |
| [ ValueSet der Verfügbarkeitsstatus-Codes ](ValueSet-GEM-ERP-VS-AvailabilityStatus.md) | Art des Verfügbarkeitsstatus für die Verfügbarkeitsanfrage von Medikamenten |
| [ ValueSet der Dokumenttyp-Codes ](ValueSet-GEM-ERP-VS-DocumentType.md) | Art der Dokumente je nach Empfänger. |
| [ ValueSet der Flowtypes in TIFlow Anwendungen ](ValueSet-GEM-ERP-VS-FlowType.md) | Zeigt die verschiedenen Typen der TI Workflows entsprechend der Verordnungsformulare. |

**Tabelle:**Legacy Value Sets

#### Legacy Suchparameter

| | |
| :--- | :--- |
| [ TaskAcceptDateSP ](SearchParameter-TaskAcceptDateSP.md) | Das Einlösedatum eines E-Rezeptes. Nach Ablaufen dieses Datums darf ein E-Rezept nicht mehr zu Lasten des Kostenträgers abgegeben werden. |
| [ TaskExpiryDateSP ](SearchParameter-TaskExpiryDateSP.md) | Das Ablaufdatum eines E-Rezepzes. Nach ablauf dieses Datums darf ein E-Rezept nicht mehr beliefert werden. |

**Tabelle:**Legacy Suchparameter

#### Legacy Ressourcenprofile

| | |
| :--- | :--- |
| [ GEM ERP PR Binary ](StructureDefinition-GEM-ERP-PR-Binary.md) | PKCS7 signiertes Bundle im enveloping style |
| [ TIFlow Receipt Bundle ](StructureDefinition-GEM-ERP-PR-Bundle.md) | Dokumentenbündel für Quittung |
| [ GEM ERP PR Composition ](StructureDefinition-GEM-ERP-PR-Composition.md) | Composition für die Quittung für die Einlösung eines E-Rezepts |
| [ GEM ERP PR Device ](StructureDefinition-GEM-ERP-PR-Device.md) | Statische Informationen auf dem TI-Flow-Fachdienst |
| [ GEM ERP PR Digest ](StructureDefinition-GEM-ERP-PR-Digest.md) | QES-Digest in Binary |

**Tabelle:**Legacy Ressourcenprofile

#### Legacy Erweiterungen (Extension) Definitions

| | |
| :--- | :--- |
| [ TI Flow AcceptDate ](StructureDefinition-GEM-ERP-EX-AcceptDate.md) | Diese Extension sollte in der Task-Ressource verwendet werden. Sie speichert das Datum, bis zu dem eine Krankenkasse die Verschreibung akzeptiert und bezahlt. |
| [ TIFlow Beneficiary ](StructureDefinition-GEM-ERP-EX-Beneficiary.md) | Der Begünstigte (z. B. Apotheke) der Quittung eines TIFlow Vorgangs, der erstellt wird, wenn der Workflow abgeschlossen ist. |
| [ TI Flow ExpiryDate ](StructureDefinition-GEM-ERP-EX-ExpiryDate.md) | Diese Erweiterung sollte in der Task-Ressource verwendet werden. Sie zeigt das Ablaufdatum des Rezepts an. |
| [ TI Flow Type ](StructureDefinition-GEM-ERP-EX-PrescriptionType.md) | Definiert den Typ eines Workflows im TIFlow. |

**Tabelle:**Extension Definitions

#### Legacy Datentypen

| | |
| :--- | :--- |
| [ GEM_ERP_PR_Signature ](StructureDefinition-GEM-ERP-PR-Signature.md) | Profil für die Signatur von Bundles im E-Rezept-Kontext |

**Tabelle:**Legacy Datentypen

### Beispielinstanzen

**CapabilityStatement**

* [Example CapabilityStatement Server PU - RX](CapabilityStatement-ExampleCapabilityStatementServerPU.md)

**Subscription**

* [erp-notification-avs-01-request-PostSubscriptionPseudo](Subscription-erp-notification-avs-01-request-PostSubscriptionPseudo.md)

* [erp-notification-avs-02-response-PostSubscriptionPseudo](Subscription-erp-notification-avs-02-response-PostSubscriptionPseudo.md)

