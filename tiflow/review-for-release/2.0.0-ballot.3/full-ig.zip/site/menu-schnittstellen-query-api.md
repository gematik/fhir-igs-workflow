# Query API - Implementation Guide TIFlow - Kernfunktionalitäten v2.0.0-ballot.3

Implementation Guide

TIFlow - Kernfunktionalitäten

Version 2.0.0-ballot.3 - ballot 

* [**Table of Contents**](toc.md)
* **Query API**

## Query API

Die folgenden Query APIs stellt der TI-Flow-Fachdienst den Clientsystemen zur Verfügung, um FHIR-Daten gezielt abrufen zu können.

Im Core-IG werden sowohl Endpunkte beschrieben, die in allen Modulen verwendet werden, wie auch Endpunkte die in mehreren IGs verwendet werden.

### Ressourcen in allen Modul IGs

Die folgenden Endpunkte und Ressourcen sind in allen Anwendungsmodulen des TI-Flow-Fachdienst verfügbar.

* [Aufgabenverwaltung: Task](./query-api-task.md)
* [Protokollierung: AuditEvent](./query-api-auditevent.md)
* [Gerät: Device](./query-api-device.md)

### Push-Notification APIs

* [Push: Pushers-API](./query-api-pushers.md)
* [Push: Channels-API](./query-api-channels.md)

### Ressourcen in mehreren Modul IGs

Die folgenden Endpunkte und Ressourcen sind in mehreren Anwendungsmodulen des TI-Flow-Fachdienst verfügbar, die jeweiligen IGs enthalten die konkrete Ausgestaltung der API.

* [Einwilligung: Consent](./query-api-consent.md)
* [Nachrichten: Communication](./query-api-communication.md)
* [Nachrichten Benachrichtigung: Subscription](./query-api-subscription.md)
* [Dispensierinformationen: MedicationDispense](./query-api-medicationdispense.md)

