# TaskAcceptDateSP - Implementation Guide TIFlow - Kernfunktionalitäten v2.0.0-ballot.2

Implementation Guide

TIFlow - Kernfunktionalitäten

Version 2.0.0-ballot.2 - ballot 

* [**Table of Contents**](toc.md)
* [**FHIR-Artefakte**](artifacts.md)
* **TaskAcceptDateSP**

## SearchParameter: TaskAcceptDateSP 

| | |
| :--- | :--- |
| *Official URL*:https://gematik.de/fhir/tiflow/SearchParameter/TaskAcceptDateSP | *Version*:2.0.0-ballot.2 |
| Active as of 2026-06-30 | *Computable Name*:TaskAcceptDateSP |
| **Copyright/Legal**: gematik GmbH / Dieser Implementation Guide ist lizenziert unter [Apache License](./license.md), Version 2.0. | |

 
Das Einlösedatum eines E-Rezeptes. Nach Ablaufen dieses Datums darf ein E-Rezept nicht mehr zu Lasten des Kostenträgers abgegeben werden. 



## Resource Content

```json
{
  "resourceType" : "SearchParameter",
  "id" : "TaskAcceptDateSP",
  "url" : "https://gematik.de/fhir/tiflow/SearchParameter/TaskAcceptDateSP",
  "version" : "2.0.0-ballot.2",
  "name" : "TaskAcceptDateSP",
  "status" : "active",
  "date" : "2026-06-30",
  "publisher" : "gematik GmbH",
  "contact" : [{
    "name" : "gematik GmbH",
    "telecom" : [{
      "system" : "url",
      "value" : "https://gematik.de"
    },
    {
      "system" : "email",
      "value" : "erp-umsetzung@gematik.de"
    }]
  }],
  "description" : "Das Einlösedatum eines E-Rezeptes. Nach Ablaufen dieses Datums darf ein E-Rezept nicht mehr zu Lasten des Kostenträgers abgegeben werden.",
  "jurisdiction" : [{
    "coding" : [{
      "system" : "urn:iso:std:iso:3166",
      "code" : "DE",
      "display" : "Germany"
    }]
  }],
  "code" : "accept-date",
  "base" : ["Task"],
  "type" : "date",
  "expression" : "Task.extension('https://gematik.de/fhir/erp/StructureDefinition/GEM_ERP_EX_AcceptDate').value.as(date)",
  "multipleOr" : false,
  "multipleAnd" : true
}

```
