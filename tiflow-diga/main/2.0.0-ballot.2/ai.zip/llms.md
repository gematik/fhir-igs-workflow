# de.gematik.tiflow.diga#2.0.0-ballot.2: Implementation Guide TIFlow - Verordnungen für Digitale Gesundheitsanwendungen (DiGA)

## Pages

* [Implementation Guide elektronische Verordnung von DiGAs](index.md)
* [Anforderungen an den TI-Flow-Fachdienst für die $close-Operation](op-close-req-fd.md)
* [Operation: $reject](op-reject.md)
* [Anforderungen an das Clientsystem des Kostenträger für die $close-Operation](op-close-req-ktr.md)
* [Downloads](downloads.md)
* [Release Notes](release-notes.md)
* [Anforderungen an den verordnende Primärsystem für die $create-Operation](op-create-req-pvs.md)
* [Additional APIs](menu-schnittstellen-additional-api.md)
* [Query API: MedicationDispense](query-api-medicationdispense.md)
* [Verarbeitungsregeln](menu-technische-umsetzung-verarbeitungsregeln.md)
* [FdV-Anforderungen: Communication-Query](query-api-communication-req-fdv.md)
* [Anforderungen an den TI-Flow-Fachdienst für die $activate-Operation](op-activate-req-fd.md)
* [Referenzen](referenced.md)
* [Anforderungen an den TI-Flow-Fachdienst für die $reject-Operation](op-reject-req-fd.md)
* [Operation: $close](op-close.md)
* [FHIR-Artefakte](artifacts.md)
* [Query API](query-api.md)
* [Systemüberblick](menu-technische-umsetzung-systemueberblick.md)
* [FdV-Anforderungen: MedicationDispense-Query](query-api-medicationdispense-req-fdv.md)
* [KTR-Anforderungen: Task-Query](query-api-task-req-ktr.md)
* [Elektronische Verordnung von DiGAs](menu-fachlichkeit-diga.md)
* [Datenschutz und Informationssicherheit](menu-datenschutz-und-sicherheit.md)
* [Anforderungen an den verordnende Primärsystem für die $activate-Operation](op-activate-req-pvs.md)
* [Operation API](operation-api.md)
* [Operation: $create](op-create.md)
* [Anforderungen an den TI-Flow-Fachdienst für die $accept-Operation](op-accept-req-fd.md)
* [Anforderungen an den TI-Flow-Fachdienst für die $abort-Operation](op-abort-req-fd.md)
* [FdV-Anforderungen: Task-Query](query-api-task-req-fdv.md)
* [Apache Licence](license.md)
* [FD-Anforderungen: MedicationDispense-Query](query-api-medicationdispense-req-fd.md)
* [Anforderungen an das E-Rezept-FdV für die $abort-Operation](op-abort-req-fdv.md)
* [Operation: $abort](op-abort.md)
* [Query API: Task](query-api-task.md)
* [API FHIR-VZD](api-add-fhirvzd.md)
* [Zugriffsprotokollierung mit AuditEvent](menu-technische-umsetzung-audit-service.md)
* [Anforderungen an das Clientsystem des Kostenträger für die $accept-Operation](op-accept-req-ktr.md)
* [Anforderungen an den TI-Flow-Fachdienst für die $create-Operation](op-create-req-fd.md)
* [Generelle Prinzipien](menu-schnittstellen-generelle-prinzipien.md)
* [Operation: $activate](op-activate.md)
* [FD-Anforderungen: Communication-Query](query-api-communication-req-fd.md)
* [FD-Anforderungen: Task-Query](query-api-task-req-fd.md)
* [Query API: Communication](query-api-communication.md)
* [KTR-Anforderungen: Communication-Query](query-api-communication-req-ktr.md)
* [Anforderungen an den verordnende Primärsystem für die $abort-Operation](op-abort-req-pvs.md)
* [Operation: $accept](op-accept.md)
* [Anforderungen an das Clientsystem des Kostenträger für die $reject-Operation](op-reject-req-ktr.md)
* [Technische Anwendungsfälle](menu-technische-umsetzung-anwendungsfaelle.md)

## Resources

### ValueSets

* [Bearbeiter eines E-Rezeptes](ValueSet-tiflow-diga-task-organizations-vs.md)

### Logicals

* [Logical DiGA Medication Dispense](StructureDefinition-GEM-ERP-LOG-MedicationDispense-DiGA.md)

### Resource Profiles

* [GEM ERP PR Communication DiGA](StructureDefinition-GEM-ERP-PR-Communication-DiGA.md)
* [GEM ERP PR MedicationDispense DiGA](StructureDefinition-GEM-ERP-PR-MedicationDispense-DiGA.md)
* [TIFlow DiGA Accept Operation Output](StructureDefinition-ti-flow-di-ga-accept-operation-output.md)
* [TIFlow DiGA Activate Operation Input](StructureDefinition-ti-flow-di-ga-activate-operation-input.md)
* [TIFlow DiGA Activate Operation Output](StructureDefinition-ti-flow-di-ga-activate-operation-output.md)
* [TIFlow DiGA Close Operation Input](StructureDefinition-ti-flow-di-ga-close-operation-input.md)
* [TIFlow DiGA Close Operation Output](StructureDefinition-ti-flow-di-ga-close-operation-output.md)
* [TIFlow DiGA Create Operation Input](StructureDefinition-ti-flow-di-ga-create-operation-input.md)
* [TIFlow DiGA Create Operation Output](StructureDefinition-ti-flow-di-ga-create-operation-output.md)
* [TIFlow - DiGA - Binary](StructureDefinition-tiflow-diga-binary.md)
* [DiGA Quittungsbundle](StructureDefinition-tiflow-diga-receipt-bundle.md)
* [DiGA QuittungsComposition](StructureDefinition-tiflow-diga-receipt-composition.md)
* [TIFlow - DiGA - Task](StructureDefinition-tiflow-diga-task.md)

### Extensions

* [GEM ERP EX DeepLink](StructureDefinition-GEM-ERP-EX-DeepLink.md)
* [GEM ERP EX RedeemCode](StructureDefinition-GEM-ERP-EX-RedeemCode.md)

### CapabilityStatements

* [ERP DiGA CapabilityStatement für den E-Rezept-Fachdienst](CapabilityStatement-ti-flow-fachdienst-server-diga.md)

### ImplementationGuides

* [Implementation Guide TIFlow - Verordnungen für Digitale Gesundheitsanwendungen (DiGA)](index.md)

### OperationDefinitions

* [E-Rezept abbrechen](OperationDefinition-tiflow-diga-abort-op.md)
* [E-Rezept abrufen](OperationDefinition-tiflow-diga-accept-op.md)
* [E-Rezept aktivieren](OperationDefinition-tiflow-diga-activate-op.md)
* [E-Rezept Abgabe vollziehen](OperationDefinition-tiflow-diga-close-op.md)
* [E-Rezept erstellen](OperationDefinition-tiflow-diga-create-op.md)
* [E-Rezept zurückgeben](OperationDefinition-tiflow-diga-reject-op.md)

### Examples

* [ExampleDiGACommunicationSearchset (Bundle)](Bundle-ExampleDiGACommunicationSearchset.md)
* [ExampleDiGAMedicationDispenseSearchset (Bundle)](Bundle-ExampleDiGAMedicationDispenseSearchset.md)
* [ExampleDiGATaskSearchset (Bundle)](Bundle-ExampleDiGATaskSearchset.md)
* [140f716f-f649-44fe-9a4e-157eb3c8adf3 (Communication)](Communication-140f716f-f649-44fe-9a4e-157eb3c8adf3.md)
* [Example-MedicationDispense-DiGA-DeepLink (MedicationDispense)](MedicationDispense-Example-MedicationDispense-DiGA-DeepLink.md)
* [Example-MedicationDispense-DiGA-Name-And-PZN (MedicationDispense)](MedicationDispense-Example-MedicationDispense-DiGA-Name-And-PZN.md)
* [Example-MedicationDispense-DiGA-NoRedeemCode (MedicationDispense)](MedicationDispense-Example-MedicationDispense-DiGA-NoRedeemCode.md)
* [ExampleDiGAOperationOutcomeError (OperationOutcome)](OperationOutcome-ExampleDiGAOperationOutcomeError.md)
* [ExampleOperationAbortErrorAVS (OperationOutcome)](OperationOutcome-ExampleOperationAbortErrorAVS.md)
* [ExampleOperationAbortErrorPVS (OperationOutcome)](OperationOutcome-ExampleOperationAbortErrorPVS.md)
* [ExampleOperationAcceptError (OperationOutcome)](OperationOutcome-ExampleOperationAcceptError.md)
* [ExampleOperationActivateError (OperationOutcome)](OperationOutcome-ExampleOperationActivateError.md)
* [ExampleOperationCloseError (OperationOutcome)](OperationOutcome-ExampleOperationCloseError.md)
* [ExampleOperationCreateError (OperationOutcome)](OperationOutcome-ExampleOperationCreateError.md)
* [ExampleOperationRejectError (OperationOutcome)](OperationOutcome-ExampleOperationRejectError.md)
* [ExampleCloseInputParametersDiGA (Parameters)](Parameters-ExampleCloseInputParametersDiGA.md)
* [ExampleDiGAOperationRequestParameters (Parameters)](Parameters-ExampleDiGAOperationRequestParameters.md)
* [ExampleOperationActivateParametersInput (Parameters)](Parameters-ExampleOperationActivateParametersInput.md)
* [OperationCreateParametersInputExample (Parameters)](Parameters-OperationCreateParametersInputExample.md)
* [ExampleDiGATaskInReadyState (Task)](Task-ExampleDiGATaskInReadyState.md)
