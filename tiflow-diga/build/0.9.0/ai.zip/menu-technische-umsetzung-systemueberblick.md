# Systemüberblick - TIFlow - Verordnungen für Digitale Gesundheitsanwendungen (DiGA) v0.9.0

TIFlow - Verordnungen für Digitale Gesundheitsanwendungen (DiGA)

Version 0.9.0 - ci-build 

* [**Table of Contents**](toc.md)
* **Systemüberblick**

## Systemüberblick

### Einordnung in die Telematikinfrastruktur

Die Verordnung von DiGAs setzt auf der bestehenden E-Rezept-Infrastruktur auf.

Psychotherapeuten sind eine neue Benutzergruppe. Ihr Primarsystem nutzt die bestehende Anbindung an das zentrale Netz der TI.

Gesetzliche Krankenkassen sind eine neue Benutzergruppe und greifen über einen Basis-Consumer auf den IDP-Dienst und den TI-Flow-Fachdienst zu.

**Abbildung: **Systemüberblick


### Akteure und Rollen

* Verordnende Leistungserbringer (Arzt/Zahnarzt/Psychotherapeut)
* Versicherte
* Kostenträger

