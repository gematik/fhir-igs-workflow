# MedicationDispense searchset response for DiGA - TIFlow - Verordnungen für Digitale Gesundheitsanwendungen (DiGA) v0.9.0

TIFlow - Verordnungen für Digitale Gesundheitsanwendungen (DiGA)

Version 0.9.0 - ci-build 

* [**Table of Contents**](toc.md)
* [**FHIR-Artefakte**](artifacts.md)
* **MedicationDispense searchset response for DiGA**

## Example Bundle: MedicationDispense searchset response for DiGA



## Resource Content

```json
{
  "resourceType" : "Bundle",
  "id" : "ExampleDiGAMedicationDispenseSearchset",
  "type" : "searchset",
  "total" : 1,
  "link" : [{
    "relation" : "self",
    "url" : "https://erp-ref.example.org/MedicationDispense?whenhandedover=ge2026-03-01"
  }],
  "entry" : [{
    "fullUrl" : "https://erp-ref.example.org/MedicationDispense/Example-MedicationDispense-DiGA-Name-And-PZN",
    "resource" : {
      "resourceType" : "MedicationDispense",
      "id" : "Example-MedicationDispense-DiGA-Name-And-PZN",
      "meta" : {
        "profile" : ["https://gematik.de/fhir/tiflow/diga/StructureDefinition/GEM_ERP_PR_MedicationDispense_DiGA"]
      },
      "text" : {
        "status" : "extensions",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"MedicationDispense_Example-MedicationDispense-DiGA-Name-And-PZN\"> </a><p class=\"res-header-id\"><b>Generated Narrative: MedicationDispense Example-MedicationDispense-DiGA-Name-And-PZN</b></p><a name=\"Example-MedicationDispense-DiGA-Name-And-PZN\"> </a><a name=\"hcExample-MedicationDispense-DiGA-Name-And-PZN\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"StructureDefinition-GEM-ERP-PR-MedicationDispense-DiGA.html\">GEM ERP PR MedicationDispense DiGA</a></p></div><p><b>GEM ERP EX RedeemCode</b>: DE12345678901234</p><p><b>identifier</b>: <code>https://gematik.de/fhir/erp/NamingSystem/GEM_ERP_NS_PrescriptionId</code>/162.000.033.491.280.78</p><p><b>status</b>: Completed</p><p><b>medication</b>: Gematico Diabetestherapie (Identifier: <code>http://fhir.de/CodeSystem/ifa/pzn</code>/12345678)</p><p><b>subject</b>: Identifier: NamingSystemKVID/X123456789</p><h3>Performers</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Actor</b></td></tr><tr><td style=\"display: none\">*</td><td>Identifier: <code>https://gematik.de/fhir/sid/telematik-id</code>/8-SMC-B-Testkarte-883110000095957</td></tr></table><p><b>whenHandedOver</b>: 2026-07-01</p></div>"
      },
      "extension" : [{
        "url" : "https://gematik.de/fhir/tiflow/diga/StructureDefinition/GEM_ERP_EX_RedeemCode",
        "valueString" : "DE12345678901234"
      }],
      "identifier" : [{
        "system" : "https://gematik.de/fhir/erp/NamingSystem/GEM_ERP_NS_PrescriptionId",
        "value" : "162.000.033.491.280.78"
      }],
      "status" : "completed",
      "medicationReference" : {
        "identifier" : {
          "system" : "http://fhir.de/CodeSystem/ifa/pzn",
          "value" : "12345678"
        },
        "display" : "Gematico Diabetestherapie"
      },
      "subject" : {
        "identifier" : {
          "system" : "http://fhir.de/sid/gkv/kvid-10",
          "value" : "X123456789"
        }
      },
      "performer" : [{
        "actor" : {
          "identifier" : {
            "system" : "https://gematik.de/fhir/sid/telematik-id",
            "value" : "8-SMC-B-Testkarte-883110000095957"
          }
        }
      }],
      "whenHandedOver" : "2026-07-01"
    },
    "search" : {
      "mode" : "match"
    }
  }]
}

```
