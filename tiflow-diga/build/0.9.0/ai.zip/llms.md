# de.gematik.tiflow.diga#0.9.0: TIFlow - Verordnungen für Digitale Gesundheitsanwendungen (DiGA)

## Pages

* [Implementation Guide elektronische Verordnung von DiGAs](index.md)
* [Anforderungen an den verordnende Primärsystem für die $activate-Operation](op-activate-req-pvs.md)
* [Anforderungen an den verordnende Primärsystem für die $abort-Operation](op-abort-req-pvs.md)
* [FdV-Anforderungen: MedicationDispense-Query](query-api-medicationdispense-req-fdv.md)
* [Operation API](operation-api.md)
* [KTR-Anforderungen: Communication-Query](query-api-communication-req-ktr.md)
* [Anforderungen an den TI-Flow-Fachdienst für die $close-Operation](op-close-req-fd.md)
* [Anforderungen an den TI-Flow-Fachdienst für die $accept-Operation](op-accept-req-fd.md)
* [Generelle Prinzipien](menu-schnittstellen-generelle-prinzipien.md)
* [KTR-Anforderungen: Task-Query](query-api-task-req-ktr.md)
* [Operation: $abort](op-abort.md)
* [FD-Anforderungen: Task-Query](query-api-task-req-fd.md)
* [Query API: MedicationDispense](query-api-medicationdispense.md)
* [Operation: $accept](op-accept.md)
* [Anforderungen an den TI-Flow-Fachdienst für die $activate-Operation](op-activate-req-fd.md)
* [Anforderungen an den TI-Flow-Fachdienst für die $create-Operation](op-create-req-fd.md)
* [Anforderungen an den TI-Flow-Fachdienst für die $reject-Operation](op-reject-req-fd.md)
* [Anforderungen an das E-Rezept-FdV für die $abort-Operation](op-abort-req-fdv.md)
* [Release Notes](release-notes.md)
* [Referenzen](referenced.md)
* [FHIR-Artefakte](artifacts.md)
* [API FHIR-VZD](api-add-fhirvzd.md)
* [Query API](query-api.md)
* [Query API: Communication](query-api-communication.md)
* [Anforderungen an das Clientsystem des Kostenträger für die $reject-Operation](op-reject-req-ktr.md)
* [Downloads](downloads.md)
* [Operation: $activate](op-activate.md)
* [Verarbeitungsregeln](menu-technische-umsetzung-verarbeitungsregeln.md)
* [FD-Anforderungen: Communication-Query](query-api-communication-req-fd.md)
* [Apache Licence](license.md)
* [FdV-Anforderungen: Communication-Query](query-api-communication-req-fdv.md)
* [Operation: $reject](op-reject.md)
* [Operation: $create](op-create.md)
* [FD-Anforderungen: MedicationDispense-Query](query-api-medicationdispense-req-fd.md)
* [Anforderungen an das Clientsystem des Kostenträger für die $close-Operation](op-close-req-ktr.md)
* [Systemüberblick](menu-technische-umsetzung-systemueberblick.md)
* [Operation: $close](op-close.md)
* [FdV-Anforderungen: Task-Query](query-api-task-req-fdv.md)
* [Elektronische Verordnung von DiGAs](menu-fachlichkeit-diga.md)
* [Additional APIs](menu-schnittstellen-additional-api.md)
* [Technische Anwendungsfälle](menu-technische-umsetzung-anwendungsfaelle.md)
* [Anforderungen an das Clientsystem des Kostenträger für die $accept-Operation](op-accept-req-ktr.md)
* [Anforderungen an den verordnende Primärsystem für die $create-Operation](op-create-req-pvs.md)
* [Query API: Task](query-api-task.md)
* [Datenschutz und Informationssicherheit](menu-datenschutz-und-sicherheit.md)
* [Anforderungen an den TI-Flow-Fachdienst für die $abort-Operation](op-abort-req-fd.md)

## Resources

### Logicals

* [Logical DiGA Medication Dispense](StructureDefinition-GEM-ERP-LOG-MedicationDispense-DiGA.md)

### Resource Profiles

* [GEM ERP PR Communication DiGA](StructureDefinition-GEM-ERP-PR-Communication-DiGA.md)
* [GEM ERP PR MedicationDispense DiGA](StructureDefinition-GEM-ERP-PR-MedicationDispense-DiGA.md)

### Extensions

* [GEM ERP EX DeepLink](StructureDefinition-GEM-ERP-EX-DeepLink.md)
* [GEM ERP EX RedeemCode](StructureDefinition-GEM-ERP-EX-RedeemCode.md)

### CapabilityStatements

* [ERP DiGA CapabilityStatement für den E-Rezept-Fachdienst](CapabilityStatement-erp-fachdienst-server-diga.md)

### ImplementationGuides

* [TIFlow - Verordnungen für Digitale Gesundheitsanwendungen (DiGA)](index.md)

### Examples

* [ExampleDiGACommunicationSearchset (Bundle)](Bundle-ExampleDiGACommunicationSearchset.md)
* [ExampleDiGAMedicationDispenseSearchset (Bundle)](Bundle-ExampleDiGAMedicationDispenseSearchset.md)
* [ExampleDiGATaskSearchset (Bundle)](Bundle-ExampleDiGATaskSearchset.md)
* [140f716f-f649-44fe-9a4e-157eb3c8adf3 (Communication)](Communication-140f716f-f649-44fe-9a4e-157eb3c8adf3.md)
* [Example-MedicationDispense-DiGA-DeepLink (MedicationDispense)](MedicationDispense-Example-MedicationDispense-DiGA-DeepLink.md)
* [Example-MedicationDispense-DiGA-Name-And-PZN (MedicationDispense)](MedicationDispense-Example-MedicationDispense-DiGA-Name-And-PZN.md)
* [Example-MedicationDispense-DiGA-NoRedeemCode (MedicationDispense)](MedicationDispense-Example-MedicationDispense-DiGA-NoRedeemCode.md)
* [ExampleDiGAOperationOutcomeError (OperationOutcome)](OperationOutcome-ExampleDiGAOperationOutcomeError.md)
* [ExampleCloseInputParametersDiGA (Parameters)](Parameters-ExampleCloseInputParametersDiGA.md)
* [ExampleDiGAOperationRequestParameters (Parameters)](Parameters-ExampleDiGAOperationRequestParameters.md)
* [ExampleDiGATaskInReadyState (Task)](Task-ExampleDiGATaskInReadyState.md)
