# Task searchset response for DiGA - Implementation Guide TIFlow - Verordnungen für Digitale Gesundheitsanwendungen (DiGA) v2.0.0-ballot.2

Implementation Guide

TIFlow - Verordnungen für Digitale Gesundheitsanwendungen (DiGA)

Version 2.0.0-ballot.2 - ballot 

* [**Table of Contents**](toc.md)
* [**FHIR-Artefakte**](artifacts.md)
* **Task searchset response for DiGA**

## Example Bundle: Task searchset response for DiGA



## Resource Content

```json
{
  "resourceType" : "Bundle",
  "id" : "ExampleDiGATaskSearchset",
  "type" : "searchset",
  "total" : 1,
  "link" : [{
    "relation" : "self",
    "url" : "https://erp-ref.example.org/Task?status=ready&_count=1"
  }],
  "entry" : [{
    "fullUrl" : "https://erp-ref.example.org/Task/ExampleDiGATaskInReadyState",
    "resource" : {
      "resourceType" : "Task",
      "id" : "ExampleDiGATaskInReadyState",
      "meta" : {
        "profile" : ["https://gematik.de/fhir/tiflow-diga/StructureDefinition/tiflow-diga-task"]
      },
      "extension" : [{
        "url" : "https://gematik.de/fhir/erp/StructureDefinition/GEM_ERP_EX_PrescriptionType",
        "valueCoding" : {
          "system" : "https://gematik.de/fhir/erp/CodeSystem/GEM_ERP_CS_FlowType",
          "code" : "162",
          "display" : "Muster 16 (Digitale Gesundheitsanwendungen)"
        }
      },
      {
        "url" : "https://gematik.de/fhir/erp/StructureDefinition/GEM_ERP_EX_AcceptDate",
        "valueDate" : "2028-10-09"
      },
      {
        "url" : "https://gematik.de/fhir/erp/StructureDefinition/GEM_ERP_EX_ExpiryDate",
        "valueDate" : "2028-10-09"
      }],
      "identifier" : [{
        "use" : "official",
        "system" : "https://gematik.de/fhir/erp/NamingSystem/GEM_ERP_NS_PrescriptionId",
        "value" : "162.000.000.000.000.01"
      },
      {
        "use" : "official",
        "system" : "https://gematik.de/fhir/erp/NamingSystem/GEM_ERP_NS_AccessCode",
        "value" : "777bea0e13cc9c42ceec14aec3ddee2263325dc2c6c699db115f58fe423607ea"
      }],
      "status" : "ready",
      "intent" : "order",
      "for" : {
        "identifier" : {
          "system" : "http://fhir.de/sid/gkv/kvid-10",
          "value" : "X123456789"
        }
      },
      "authoredOn" : "2028-10-01T15:29:00+00:00",
      "lastModified" : "2028-10-01T15:29:00.434+00:00",
      "performerType" : [{
        "coding" : [{
          "system" : "https://gematik.de/fhir/erp/CodeSystem/GEM_ERP_CS_OrganizationType",
          "code" : "urn:oid:1.2.276.0.76.4.59",
          "display" : "Kostenträger"
        }],
        "text" : "Kostenträger"
      }],
      "input" : [{
        "type" : {
          "coding" : [{
            "system" : "https://gematik.de/fhir/erp/CodeSystem/GEM_ERP_CS_DocumentType",
            "code" : "2"
          }]
        },
        "valueReference" : {
          "reference" : "3ebd56b4-5cdf-42bc-b26a-738d0b08068a"
        }
      }]
    },
    "search" : {
      "mode" : "match"
    }
  },
  {
    "fullUrl" : "urn:uuid:3ebd56b4-5cdf-42bc-b26a-738d0b08068a",
    "resource" : {
      "resourceType" : "Bundle",
      "id" : "3ebd56b4-5cdf-42bc-b26a-738d0b08068a",
      "meta" : {
        "profile" : ["$evdga-bundle|1.2"],
        "tag" : [{
          "display" : "Unvollständiges Beispiel eines DiGA-Rezept-Bundles"
        }]
      },
      "type" : "document"
    }
  }]
}

```
