# Verarbeitungsregeln - Implementation Guide TIFlow - Verordnungen für Digitale Gesundheitsanwendungen (DiGA) v2.0.0-ballot.3

Implementation Guide

TIFlow - Verordnungen für Digitale Gesundheitsanwendungen (DiGA)

Version 2.0.0-ballot.3 - ballot 

* [**Table of Contents**](toc.md)
* [**Systemüberblick**](menu-technische-umsetzung-systemueberblick.md)
* **Verarbeitungsregeln**

## Verarbeitungsregeln

### Verordnen durch Psychotherapeuten

Für die Verordnung von DiGAs durch Psychotherapeuten gelten die gleichen technischen Voraussetzungen wie für Ärzte und Zahnärzte. Der Psychotherapeut muss die Verordnung mit seinem Heilberufsausweis (HBA) qualifiziert elektronisch signieren. Es muss ein HBA verwendet werden, welcher einer der folgenden Berufsgruppe zugeordnet ist:

* Psychotherapeut/-in (oid_psychotherapeut)
* Psychologische/-r Psychotherapeut/-in (oid_ps_psychotherapeut)
* Kinder- und Jugendlichenpsychotherapeut/-in (oid_kuj_psychotherapeut)

Das Primärsystem der Psychotherapeuten Praxis verbindet sich über das Internet unter Nutzung von ZETA mit dem TI-Flow-Fachdienst.

Für die Authentisierung nutzt die Psychotherapeuten Praxis ihre SMC-B mit der Rolle oid_praxis_psychotherapeut, bzw. in einer Gemeinschaftspraxis mit Ärzten die Rolle oid_praxis_arzt.

### Authentisierung Kostenträger

Das Clientsystem eines Kostenträgers verbindet sich über das Internet unter Nutzung von ZETA mit dem TI-Flow-Fachdienst.

Für die Authentisierung nutzt der Kostenträger seine SM-B KTR mit der Rolle oid_kostentraeger.

### Workflow mit Flowtype 162

Für Übermittlungen von DiGA Verordnungen werden Workflows mit **Flowtype 162** verwendet.

### Löschfristen

Die Löschfristen für Workflows mit Flowtype 162 entsprechen denen des Workflows mit Flowtype 160.

### Zugriff auf FHIR-VZD

Zur Prüfung der IKNR muss der TI-Flow-Fachdienst die Telematik-ID des Kostenträgers auflösen. Das Mapping zwischen IKNR und Telematik-ID erfolgt über das FHIR-VZD und kann bis zu 24 Stunden gecacht werden.

### eVDGA FHIR Profile

Zur Verordnung von DiGA werden die KBV-Profile der elektronischen Verordnung Digitaler Gesundheitsanwendungen verwendet (https://simplifier.net/evdga). Die Workflowprofile des E-Rezept-Workflows werden um diese Profile ergänzt.

