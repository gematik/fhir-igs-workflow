# Example Close Parameters - Implementation Guide TIFlow - Verordnungen für Digitale Gesundheitsanwendungen (DiGA) v2.0.0-ballot.3

Implementation Guide

TIFlow - Verordnungen für Digitale Gesundheitsanwendungen (DiGA)

Version 2.0.0-ballot.3 - ballot 

* [**Table of Contents**](toc.md)
* [**FHIR-Artefakte**](artifacts.md)
* **Example Close Parameters**

## Example Parameters: Example Close Parameters



## Resource Content

```json
{
  "resourceType" : "Parameters",
  "id" : "ExampleCloseOutputParametersDiGA",
  "meta" : {
    "profile" : ["https://gematik.de/fhir/tiflow-diga/StructureDefinition/ti-flow-di-ga-close-operation-output"]
  },
  "parameter" : [{
    "name" : "return",
    "resource" : {
      "resourceType" : "Bundle",
      "id" : "ExampleOperationCloseOutput",
      "meta" : {
        "profile" : ["https://gematik.de/fhir/tiflow-diga/StructureDefinition/tiflow-diga-receipt-bundle"],
        "tag" : [{
          "display" : "Receipt Bundle 'Quittung' for completed dispensation of a prescription"
        }]
      },
      "identifier" : {
        "system" : "https://gematik.de/fhir/erp/NamingSystem/GEM_ERP_NS_PrescriptionId",
        "value" : "162.000.033.491.280.78"
      },
      "type" : "document",
      "timestamp" : "2028-10-01T15:29:00+00:00",
      "entry" : [{
        "fullUrl" : "urn:uuid:c624cf47-e235-4624-af71-0a09dc9254dc",
        "resource" : {
          "resourceType" : "Composition",
          "id" : "c624cf47-e235-4624-af71-0a09dc9254dc",
          "meta" : {
            "profile" : ["https://gematik.de/fhir/tiflow-diga/StructureDefinition/tiflow-diga-receipt-composition"]
          },
          "extension" : [{
            "url" : "https://gematik.de/fhir/erp/StructureDefinition/GEM_ERP_EX_Beneficiary",
            "valueIdentifier" : {
              "system" : "https://gematik.de/fhir/sid/telematik-id",
              "value" : "8-SMC-B-Testkarte-883110000129070"
            }
          }],
          "status" : "final",
          "type" : {
            "coding" : [{
              "system" : "https://gematik.de/fhir/erp/CodeSystem/GEM_ERP_CS_DocumentType",
              "code" : "3",
              "display" : "Receipt"
            }]
          },
          "date" : "2028-10-01T15:29:00+00:00",
          "author" : [{
            "reference" : "urn:uuid:1413b38d-81a6-432a-a801-98d7307a422b"
          }],
          "title" : "Quittung",
          "event" : [{
            "period" : {
              "start" : "2028-10-01T15:29:00+00:00",
              "end" : "2028-10-01T15:29:00+00:00"
            }
          }],
          "section" : [{
            "entry" : [{
              "reference" : "urn:uuid:b939a82a-9c23-4b6d-a139-f468d1b9d652"
            }]
          }]
        }
      },
      {
        "fullUrl" : "urn:uuid:1413b38d-81a6-432a-a801-98d7307a422b",
        "resource" : {
          "resourceType" : "Device",
          "id" : "ReceiptBundleDevice",
          "meta" : {
            "profile" : ["https://gematik.de/fhir/erp/StructureDefinition/GEM_ERP_PR_Device"]
          },
          "status" : "active",
          "serialNumber" : "2.0.0",
          "deviceName" : [{
            "name" : "TI-Flow-Fachdienst",
            "type" : "user-friendly-name"
          }],
          "version" : [{
            "value" : "2.0.0"
          }],
          "contact" : [{
            "system" : "email",
            "value" : "betrieb@gematik.de"
          }]
        }
      },
      {
        "fullUrl" : "urn:uuid:b939a82a-9c23-4b6d-a139-f468d1b9d652",
        "resource" : {
          "resourceType" : "Binary",
          "id" : "b939a82a-9c23-4b6d-a139-f468d1b9d652",
          "meta" : {
            "profile" : ["https://gematik.de/fhir/tiflow-diga/StructureDefinition/tiflow-diga-binary"]
          },
          "contentType" : "application/octet-stream",
          "data" : "tJg8c5ZtdhzEEhJ0ZpAsUVFx5dKuYgQFs5oKgthi17M="
        }
      }],
      "signature" : {
        "type" : [{
          "system" : "urn:iso-astm:E1762-95:2013",
          "code" : "1.2.840.10065.1.12.1.1"
        }],
        "when" : "2028-10-01T15:29:00+00:00",
        "who" : {
          "reference" : "urn:uuid:1413b38d-81a6-432a-a801-98d7307a422b"
        },
        "sigFormat" : "application/pkcs7-mime",
        "data" : "dGhpcyBibG9iIGlzIHNuaXBwZWQ="
      }
    }
  }]
}

```
