# Operation API - TIFlow - Verordnungen für Digitale Gesundheitsanwendungen (DiGA) v2.0.0-ballot.1

TIFlow - Verordnungen für Digitale Gesundheitsanwendungen (DiGA)

Version 2.0.0-ballot.1 - ci-build 

* [**Table of Contents**](toc.md)
* **Operation API**

## Operation API

Diese Seite bietet einen Einstieg in die Operationen des DiGA-Workflows. Die Operationen entsprechen dem Basis-Workflow des TI-Flow-Fachdienstes.

### Operationen

* [$create](./op-create.md)
* [$activate](./op-activate.md)
* [$accept](./op-accept.md)
* [$reject](./op-reject.md)
* [$close](./op-close.md)
* [$abort](./op-abort.md)

