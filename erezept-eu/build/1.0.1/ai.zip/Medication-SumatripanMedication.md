# Sample Medication Sumatripan - E-Rezept Workflow EU v1.0.1

E-Rezept Workflow EU

Version 1.0.1 - release 

* [**Table of Contents**](toc.md)
* [**FHIR-Artefakte**](artifacts.md)
* **Sample Medication Sumatripan**

## Example Medication: Sample Medication Sumatripan

Profile: [EU-Medication](StructureDefinition-GEM-ERPEU-PR-Medication.md)

**DrugCategoryExtension**: [EPA Code System für Arzneimittelkategorien: 00](https://simplifier.net/resolve?scope=de.gematik.epa.medication@1.3.0&canonical=https://gematik.de/fhir/epa-medication/CodeSystem/epa-drug-category-cs#epa-drug-category-cs-00) (Arzneimittel oder in die Arzneimittelversorgung nach § 31 SGB V einbezogenes Produkt)

**MedicationIsVaccineExtension**: false

**ExtensionNormgroesseDeBasis**: N1

**code**: Sumatriptan-1a Pharma 100 mg Tabletten

**form**: TAB

**amount**: 20 St/1

### Batches

| | |
| :--- | :--- |
| - | **LotNumber** |
| * | 1234567890 |

