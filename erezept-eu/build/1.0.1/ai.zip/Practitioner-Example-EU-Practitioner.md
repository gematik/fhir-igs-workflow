# Example-EU-Practitioner - E-Rezept Workflow EU v1.0.1

E-Rezept Workflow EU

Version 1.0.1 - release 

* [**Table of Contents**](toc.md)
* [**FHIR-Artefakte**](artifacts.md)
* **Example-EU-Practitioner**

## Example Practitioner: Example-EU-Practitioner

Profile: [Practitioner Information Received from the EU](StructureDefinition-GEM-ERPEU-PR-Practitioner.md)

**identifier**: EU-1234567890

**name**: Pedro Sanches

