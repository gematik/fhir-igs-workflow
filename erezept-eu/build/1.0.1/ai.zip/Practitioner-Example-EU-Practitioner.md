# Example-EU-Practitioner - EU Zugriff E-Rezept v1.0.1

EU Zugriff E-Rezept

Version 1.0.1 - ci-build 

* [**Table of Contents**](toc.md)
* [**FHIR-Artefakte**](artifacts.md)
* **Example-EU-Practitioner**

## Example Practitioner: Example-EU-Practitioner

Profile: [Practitioner Information Received from the EU](StructureDefinition-GEM-ERPEU-PR-Practitioner.md)

**identifier**: EU-1234567890

**name**: Pedro Sanches

