# GEM_ERPEU_PR_PAR_Access_Authorization_Response - E-Rezept Workflow EU v1.0.1

E-Rezept Workflow EU

Version 1.0.1 - release 

* [**Table of Contents**](toc.md)
* [**FHIR-Artefakte**](artifacts.md)
* **GEM_ERPEU_PR_PAR_Access_Authorization_Response**

## Example Parameters: GEM_ERPEU_PR_PAR_Access_Authorization_Response

