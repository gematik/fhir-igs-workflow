# GEM_ERPEU_PR_PAR_Access_Authorization_Response - EU Zugriff E-Rezept v1.0.1

EU Zugriff E-Rezept

Version 1.0.1 - ci-build 

* [**Table of Contents**](toc.md)
* [**FHIR-Artefakte**](artifacts.md)
* **GEM_ERPEU_PR_PAR_Access_Authorization_Response**

## Example Parameters: GEM_ERPEU_PR_PAR_Access_Authorization_Response

