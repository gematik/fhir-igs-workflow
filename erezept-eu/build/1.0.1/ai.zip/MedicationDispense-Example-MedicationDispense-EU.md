# Example Medication Dispense - EU Zugriff E-Rezept v1.0.1

EU Zugriff E-Rezept

Version 1.0.1 - ci-build 

* [**Table of Contents**](toc.md)
* [**FHIR-Artefakte**](artifacts.md)
* **Example Medication Dispense**

## Example MedicationDispense: Example Medication Dispense

Profile: [Dispensation of the Prescription from the EU](StructureDefinition-GEM-ERPEU-PR-MedicationDispense.md)

**identifier**: `https://gematik.de/fhir/erp/NamingSystem/GEM_ERP_NS_PrescriptionId`/160.000.033.491.280.78

**status**: Completed

**medication**: [Medication 06313728](Medication-SumatripanMedication.md)

**subject**: Identifier: NamingSystemKVID/X123456789

### Performers

| | |
| :--- | :--- |
| - | **Actor** |
| * | [PractitionerRole](PractitionerRole-Example-EU-PractitionerRole.md) |

**quantity**: 2 pkg

**whenHandedOver**: 2026-10-01

