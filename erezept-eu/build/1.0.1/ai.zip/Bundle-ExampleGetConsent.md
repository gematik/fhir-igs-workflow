# Example for a Bundle with a Consent - EU Zugriff E-Rezept v1.0.1

EU Zugriff E-Rezept

Version 1.0.1 - ci-build 

* [**Table of Contents**](toc.md)
* [**FHIR-Artefakte**](artifacts.md)
* **Example for a Bundle with a Consent**

## Example Bundle: Example for a Bundle with a Consent

