# Example for a Bundle with a Consent - E-Rezept Workflow EU v1.0.1

E-Rezept Workflow EU

Version 1.0.1 - release 

* [**Table of Contents**](toc.md)
* [**FHIR-Artefakte**](artifacts.md)
* **Example for a Bundle with a Consent**

## Example Bundle: Example for a Bundle with a Consent

