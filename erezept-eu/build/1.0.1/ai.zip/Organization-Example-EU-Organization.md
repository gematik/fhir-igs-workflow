# Example-EU-Organization - EU Zugriff E-Rezept v1.0.1

EU Zugriff E-Rezept

Version 1.0.1 - ci-build 

* [**Table of Contents**](toc.md)
* [**FHIR-Artefakte**](artifacts.md)
* **Example-EU-Organization**

## Example Organization: Example-EU-Organization

Profile: [Organization Information Received from the EU](StructureDefinition-GEM-ERPEU-PR-Organization.md)

**identifier**: 1234567890, EU-136ad69f

**type**: Öffentliche Apotheke

**name**: Pharmacia de Santa Maria

**address**: Rua da Alegria, 123 Lisbon Estremadura 1234-567 Portugal 

