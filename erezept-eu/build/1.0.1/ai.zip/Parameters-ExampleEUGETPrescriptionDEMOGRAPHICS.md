# Example EU-GET Prescription Parameters - E-Rezept Workflow EU v1.0.1

E-Rezept Workflow EU

Version 1.0.1 - release 

* [**Table of Contents**](toc.md)
* [**FHIR-Artefakte**](artifacts.md)
* **Example EU-GET Prescription Parameters**

## Example Parameters: Example EU-GET Prescription Parameters

