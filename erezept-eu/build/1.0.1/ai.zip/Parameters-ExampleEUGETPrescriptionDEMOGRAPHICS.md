# Example EU-GET Prescription Parameters - EU Zugriff E-Rezept v1.0.1

EU Zugriff E-Rezept

Version 1.0.1 - ci-build 

* [**Table of Contents**](toc.md)
* [**FHIR-Artefakte**](artifacts.md)
* **Example EU-GET Prescription Parameters**

## Example Parameters: Example EU-GET Prescription Parameters

