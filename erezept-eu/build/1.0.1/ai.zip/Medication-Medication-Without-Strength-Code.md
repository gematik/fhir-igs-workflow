# Medication Without code or system for Strength - EU Zugriff E-Rezept v1.0.1

EU Zugriff E-Rezept

Version 1.0.1 - ci-build 

* [**Table of Contents**](toc.md)
* [**FHIR-Artefakte**](artifacts.md)
* **Medication Without code or system for Strength**

## Example Medication: Medication Without code or system for Strength

Profile: [EU-Medication](StructureDefinition-GEM-ERPEU-PR-Medication.md)

**code**: Infusion bestehend aus 85mg Doxorubicin aufgeloest zur Verabreichung in 250ml 5-%iger (50 mg/ml) Glucose-Infusionsloesung

**form**: Solution for infusion

### Ingredients

| | | | |
| :--- | :--- | :--- | :--- |
| - | **Item[x]** | **IsActive** | **Strength** |
| * | Doxorubicin | true | 85 mg/250 Milliliter |

