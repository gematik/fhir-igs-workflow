# Medication Without code or system for Strength - E-Rezept Workflow EU v1.0.1

E-Rezept Workflow EU

Version 1.0.1 - release 

* [**Table of Contents**](toc.md)
* [**FHIR-Artefakte**](artifacts.md)
* **Medication Without code or system for Strength**

## Example Medication: Medication Without code or system for Strength

Profile: [EU-Medication](StructureDefinition-GEM-ERPEU-PR-Medication.md)

**code**: Infusion bestehend aus 85mg Doxorubicin aufgeloest zur Verabreichung in 250ml 5-%iger (50 mg/ml) Glucose-Infusionsloesung

**form**: Solution for infusion

**Exception Generating Narrative: Cannot invoke "String.equals(Object)" because the return value of "org.hl7.fhir.r5.renderers.utils.ResourceWrapper.primitiveValue(String)" is null **

