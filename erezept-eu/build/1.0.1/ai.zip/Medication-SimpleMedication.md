# Sample Simple Medication - E-Rezept Workflow EU v1.0.1

E-Rezept Workflow EU

Version 1.0.1 - release 

* [**Table of Contents**](toc.md)
* [**FHIR-Artefakte**](artifacts.md)
* **Sample Simple Medication**

## Example Medication: Sample Simple Medication

Profile: [EU-Medication](StructureDefinition-GEM-ERPEU-PR-Medication.md)

**code**: 06313728

### Batches

| | |
| :--- | :--- |
| - | **LotNumber** |
| * | 1234567890 |

