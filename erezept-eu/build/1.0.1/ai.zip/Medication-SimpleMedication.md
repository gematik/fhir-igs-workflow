# Sample Simple Medication - EU Zugriff E-Rezept v1.0.1

EU Zugriff E-Rezept

Version 1.0.1 - ci-build 

* [**Table of Contents**](toc.md)
* [**FHIR-Artefakte**](artifacts.md)
* **Sample Simple Medication**

## Example Medication: Sample Simple Medication

Profile: [EU-Medication](StructureDefinition-GEM-ERPEU-PR-Medication.md)

**code**: 06313728

### Batches

| | |
| :--- | :--- |
| - | **LotNumber** |
| * | 1234567890 |

