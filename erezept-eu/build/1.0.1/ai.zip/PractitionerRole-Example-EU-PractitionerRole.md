# Example-EU-PractitionerRole - EU Zugriff E-Rezept v1.0.1

EU Zugriff E-Rezept

Version 1.0.1 - ci-build 

* [**Table of Contents**](toc.md)
* [**FHIR-Artefakte**](artifacts.md)
* **Example-EU-PractitionerRole**

## Example PractitionerRole: Example-EU-PractitionerRole

Profile: [PractitionerRole Information Received from the EU](StructureDefinition-GEM-ERPEU-PR-PractitionerRole.md)

**practitioner**: [Practitioner Pedro Sanches](Practitioner-Example-EU-Practitioner.md)

**organization**: [Organization Pharmacia de Santa Maria](Organization-Example-EU-Organization.md)

