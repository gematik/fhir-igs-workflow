# FD-Anforderungen $create - E-Rezept für Arzneimittel v1.0.0-draft

E-Rezept für Arzneimittel

Version 1.0.0-draft - ci-build 

* [**Table of Contents**](toc.md)
* [**Operation API**](menu-schnittstellen-operation-api.md)
* [**Operation $create (Task erzeugen)**](op-create.md)
* **FD-Anforderungen $create**

## FD-Anforderungen $create

# FD-Anforderungen: Operation $create

Die Operation `$create` baut fuer die normativen Basisanforderungen auf der Core-Spezifikation auf.

* [Core: Operation `$create`](https://gemspec.gematik.de/ig/fhir/eflow-core/latest/op-create.html)

RX-spezifische Zusatzanforderungen gegenueber Core sind fuer `$create` derzeit nicht festgelegt.

