## Provide Prescription Mapping Tables

Automatisch generiert am 2026-02-02.

Die folgenden Seiten beschreiben das Mapping von KBV Bundles zu Provide Parameters.

### Bundles

- [Bundle input-example-1](comparison-Bundle-input-example-1.html)
- [Bundle input-example-2](comparison-Bundle-input-example-2.html)
- [Bundle input-example-3](comparison-Bundle-input-example-3.html)
- [Bundle input-example-4](comparison-Bundle-input-example-4.html)
- [Bundle input-example-5](comparison-Bundle-input-example-5.html)

> Diese Datei wird automatisch durch scripts/testscripts/generate-provide-prescription-docs.py erzeugt.
