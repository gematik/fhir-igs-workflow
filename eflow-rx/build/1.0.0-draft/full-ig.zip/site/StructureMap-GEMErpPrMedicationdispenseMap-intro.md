*(Keine bedeutsamen Transformationen gefunden - nur direkte Kopien)*
