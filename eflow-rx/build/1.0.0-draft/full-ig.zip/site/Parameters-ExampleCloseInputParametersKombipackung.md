# Beispiel Close-Parameter für Kombipackung - E-Rezept für Arzneimittel v1.0.0-draft

E-Rezept für Arzneimittel

Version 1.0.0-draft - ci-build 

* [**Table of Contents**](toc.md)
* [**FHIR-Artefakte**](artifacts.md)
* **Beispiel Close-Parameter für Kombipackung**

## Example Parameters: Beispiel Close-Parameter für Kombipackung



## Resource Content

```json
{
  "resourceType" : "Parameters",
  "id" : "ExampleCloseInputParametersKombipackung",
  "meta" : {
    "profile" : ["https://gematik.de/fhir/erp/StructureDefinition/eflow-rx-close-operation-input-parameters"]
  },
  "parameter" : [{
    "name" : "rxDispensation",
    "part" : [{
      "name" : "medicationDispense",
      "resource" : {
        "resourceType" : "MedicationDispense",
        "id" : "Example-MedicationDispense-Kombipackung",
        "meta" : {
          "profile" : ["https://gematik.de/fhir/erp/StructureDefinition/GEM-ERP-PR-MedicationDispense"]
        },
        "identifier" : [{
          "system" : "https://gematik.de/fhir/erp/NamingSystem/GEM_ERP_NS_PrescriptionId",
          "value" : "160.000.033.491.280.78"
        }],
        "status" : "completed",
        "medicationReference" : {
          "reference" : "Medication/Medication-Kombipackung"
        },
        "subject" : {
          "identifier" : {
            "system" : "http://fhir.de/sid/gkv/kvid-10",
            "value" : "X123456789"
          }
        },
        "performer" : [{
          "actor" : {
            "identifier" : {
              "system" : "https://gematik.de/fhir/sid/telematik-id",
              "value" : "3-SMC-B-Testkarte-883110000095957"
            }
          }
        }],
        "whenHandedOver" : "2026-07-01"
      }
    },
    {
      "name" : "medication",
      "resource" : {
        "resourceType" : "Medication",
        "id" : "Medication-Kombipackung",
        "meta" : {
          "profile" : ["https://gematik.de/fhir/erp/StructureDefinition/GEM-ERP-PR-Medication"]
        },
        "contained" : [{
          "resourceType" : "Medication",
          "id" : "Augentropfen",
          "meta" : {
            "profile" : ["https://gematik.de/fhir/epa-medication/StructureDefinition/epa-medication-pharmaceutical-product"]
          },
          "extension" : [{
            "url" : "https://gematik.de/fhir/epa-medication/StructureDefinition/epa-medication-type-extension",
            "valueCoding" : {
              "system" : "http://snomed.info/sct",
              "code" : "373873005",
              "display" : "Pharmaceutical / biologic product (product)"
            }
          }],
          "ingredient" : [{
            "itemCodeableConcept" : {
              "coding" : [{
                "system" : "http://fhir.de/CodeSystem/bfarm/atc",
                "version" : "1.4.0",
                "code" : "R01AC01",
                "display" : "Natriumcromoglicat"
              }]
            },
            "strength" : {
              "numerator" : {
                "value" : 20,
                "unit" : "mg",
                "system" : "http://unitsofmeasure.org",
                "code" : "mg"
              },
              "denominator" : {
                "value" : 1,
                "unit" : "ml",
                "system" : "http://unitsofmeasure.org",
                "code" : "ml"
              }
            }
          }]
        },
        {
          "resourceType" : "Medication",
          "id" : "NasenSpray",
          "meta" : {
            "profile" : ["https://gematik.de/fhir/epa-medication/StructureDefinition/epa-medication-pharmaceutical-product"]
          },
          "extension" : [{
            "url" : "https://gematik.de/fhir/epa-medication/StructureDefinition/epa-medication-type-extension",
            "valueCoding" : {
              "system" : "http://snomed.info/sct",
              "code" : "373873005",
              "display" : "Pharmaceutical / biologic product (product)"
            }
          }],
          "ingredient" : [{
            "itemCodeableConcept" : {
              "coding" : [{
                "system" : "http://fhir.de/CodeSystem/bfarm/atc",
                "version" : "1.4.0",
                "code" : "R01AC01",
                "display" : "Natriumcromoglicat"
              }]
            },
            "strength" : {
              "numerator" : {
                "value" : 2.8,
                "unit" : "mg",
                "system" : "http://unitsofmeasure.org",
                "code" : "mg"
              },
              "denominator" : {
                "value" : 1,
                "unit" : "Sprühstoß",
                "system" : "http://unitsofmeasure.org",
                "code" : "1"
              }
            }
          }]
        }],
        "extension" : [{
          "url" : "https://gematik.de/fhir/epa-medication/StructureDefinition/medication-id-vaccine-extension",
          "valueBoolean" : false
        },
        {
          "url" : "https://gematik.de/fhir/epa-medication/StructureDefinition/drug-category-extension",
          "valueCoding" : {
            "system" : "https://gematik.de/fhir/epa-medication/CodeSystem/epa-drug-category-cs",
            "code" : "00",
            "display" : "Arzneimittel oder in die Arzneimittelversorgung nach § 31 SGB V einbezogenes Produkt"
          }
        }],
        "code" : {
          "coding" : [{
            "system" : "http://fhir.de/CodeSystem/ifa/pzn",
            "code" : "1746517",
            "display" : "CROMO-RATIOPHARM Kombipackung"
          }]
        },
        "status" : "active",
        "form" : {
          "coding" : [{
            "system" : "https://fhir.kbv.de/CodeSystem/KBV_CS_SFHIR_KBV_DARREICHUNGSFORM",
            "code" : "KPG"
          }],
          "text" : "Kombipackung"
        },
        "ingredient" : [{
          "itemReference" : {
            "reference" : "#NasenSpray"
          }
        },
        {
          "itemReference" : {
            "reference" : "#Augentropfen"
          }
        }],
        "batch" : {
          "lotNumber" : "56498416854"
        }
      }
    }]
  }]
}

```
