# Anbindung an den ePA MedicationService - E-Rezept für Arzneimittel v1.0.0-draft

E-Rezept für Arzneimittel

Version 1.0.0-draft - ci-build 

* [**Table of Contents**](toc.md)
* [**Systemüberblick**](menu-technische-umsetzung-systemueberblick.md)
* **Anbindung an den ePA MedicationService**

## Anbindung an den ePA MedicationService

Beschreibung übertragung von daten an den ePA MedicationService

