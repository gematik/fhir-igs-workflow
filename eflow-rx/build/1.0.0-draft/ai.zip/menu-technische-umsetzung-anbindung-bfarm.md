# Anbindung an den BfArM Webdienst - E-Rezept für Arzneimittel v1.0.0-draft

E-Rezept für Arzneimittel

Version 1.0.0-draft - ci-build 

* [**Table of Contents**](toc.md)
* [**Systemüberblick**](menu-technische-umsetzung-systemueberblick.md)
* **Anbindung an den BfArM Webdienst**

## Anbindung an den BfArM Webdienst

Beschreibung übertragung von daten an den BfArM Webdienst

