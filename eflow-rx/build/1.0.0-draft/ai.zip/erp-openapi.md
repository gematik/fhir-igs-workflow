# OpenAPI: E-Rezept Produkttypen - E-Rezept für Arzneimittel v1.0.0-draft

E-Rezept für Arzneimittel

Version 1.0.0-draft - ci-build 

* [**Table of Contents**](toc.md)
* **OpenAPI: E-Rezept Produkttypen**

## OpenAPI: E-Rezept Produkttypen

Die bereitgestellte OpenAPI-Definition dient
**ausschließlich**als Hilfestellung bei der Implementierung. Sie enthält nicht alle möglichen Fehlercodes oder Rückgabewerte und kann daher nicht als normativ betrachtet werden. Für eine vollständige und korrekte Implementierung sind die offiziellen Spezifikationen und begleitenden Dokumentationen maßgeblich.

