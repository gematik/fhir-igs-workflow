# OpenAPI: E-Rezept Produkttypen - E-Rezept für Arzneimittel v1.0.0-draft

E-Rezept für Arzneimittel

Version 1.0.0-draft - ci-build 

* [**Table of Contents**](toc.md)
* **OpenAPI: E-Rezept Produkttypen**

## OpenAPI: E-Rezept Produkttypen

### OpenAPI: E-Rezept Produkttypen

Die OpenAPI-Artefakte dienen als **Implementierungshilfe**. Die normative Definition der Anforderungen bleibt in den Spezifikationen und Requirement-Bloecken dieses IG.

* [OpenAPI JSON des eRp Fachdienst Servers](erp-fachdienst-server.openapi.json)
* [OpenAPI JSON des eRp Fachdienst Clients](erp-fachdienst-client.openapi.json)

