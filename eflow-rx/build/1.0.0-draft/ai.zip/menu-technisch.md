# Technische Aspekte zur Arzneimittelverordnung - E-Rezept für Arzneimittel v1.0.0-draft

E-Rezept für Arzneimittel

Version 1.0.0-draft - ci-build 

* [**Table of Contents**](toc.md)
* **Technische Aspekte zur Arzneimittelverordnung**

## Technische Aspekte zur Arzneimittelverordnung

Dieser IG beschreibt folgende technischen Aspekte für die Arzneimittelverordnung:

* [Technische Anwendungsfälle](./menu-technische-umsetzung-anwendungsfaelle.md)
* [Validierung von Dosierinformationen](./menu-technische-umsetzung-dosierung.md)

