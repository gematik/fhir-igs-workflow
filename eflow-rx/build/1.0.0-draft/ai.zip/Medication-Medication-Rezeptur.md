# Medikament-Rezeptur - E-Rezept für Arzneimittel v1.0.0-draft

E-Rezept für Arzneimittel

Version 1.0.0-draft - ci-build 

* [**Table of Contents**](toc.md)
* [**FHIR-Artefakte**](artifacts.md)
* **Medikament-Rezeptur**

## Example Medication: Medikament-Rezeptur



## Resource Content

```json
{
  "resourceType" : "Medication",
  "id" : "Medication-Rezeptur",
  "meta" : {
    "profile" : ["https://gematik.de/fhir/erp/StructureDefinition/GEM-ERP-PR-Medication"]
  },
  "contained" : [{
    "resourceType" : "Medication",
    "id" : "MedicationHydrocortison",
    "meta" : {
      "profile" : ["https://gematik.de/fhir/epa-medication/StructureDefinition/epa-medication-pzn-ingredient"]
    },
    "extension" : [{
      "url" : "https://gematik.de/fhir/epa-medication/StructureDefinition/epa-medication-type-extension",
      "valueCoding" : {
        "system" : "http://snomed.info/sct",
        "code" : "781405001",
        "display" : "Medicinal product package (product)"
      }
    }],
    "code" : {
      "coding" : [{
        "system" : "http://fhir.de/CodeSystem/ifa/pzn",
        "code" : "03424249",
        "display" : "Hydrocortison 1% Creme"
      }]
    },
    "batch" : {
      "lotNumber" : "56498416854"
    }
  },
  {
    "resourceType" : "Medication",
    "id" : "MedicationDexpanthenol",
    "meta" : {
      "profile" : ["https://gematik.de/fhir/epa-medication/StructureDefinition/epa-medication-pzn-ingredient"]
    },
    "extension" : [{
      "url" : "https://gematik.de/fhir/epa-medication/StructureDefinition/epa-medication-type-extension",
      "valueCoding" : {
        "system" : "http://snomed.info/sct",
        "code" : "781405001",
        "display" : "Medicinal product package (product)"
      }
    }],
    "code" : {
      "coding" : [{
        "system" : "http://fhir.de/CodeSystem/ifa/pzn",
        "code" : "16667195",
        "display" : "Dexpanthenol 5% Creme"
      }]
    },
    "batch" : {
      "lotNumber" : "0132456"
    }
  }],
  "extension" : [{
    "url" : "https://gematik.de/fhir/epa-medication/StructureDefinition/drug-category-extension",
    "valueCoding" : {
      "system" : "https://gematik.de/fhir/epa-medication/CodeSystem/epa-drug-category-cs",
      "code" : "00"
    }
  },
  {
    "url" : "https://gematik.de/fhir/epa-medication/StructureDefinition/epa-medication-type-extension",
    "valueCoding" : {
      "system" : "http://snomed.info/sct",
      "code" : "1208954007",
      "display" : "Extemporaneous preparation (product)"
    }
  },
  {
    "url" : "https://gematik.de/fhir/epa-medication/StructureDefinition/medication-id-vaccine-extension",
    "valueBoolean" : false
  }],
  "code" : {
    "text" : "Hydrocortison-Dexpanthenol-Salbe"
  },
  "form" : {
    "coding" : [{
      "system" : "https://fhir.kbv.de/CodeSystem/KBV_CS_SFHIR_KBV_DARREICHUNGSFORM",
      "code" : "SAL"
    }]
  },
  "amount" : {
    "numerator" : {
      "extension" : [{
        "url" : "https://gematik.de/fhir/epa-medication/StructureDefinition/medication-total-quantity-formulation-extension",
        "valueString" : "100"
      }],
      "value" : 20,
      "unit" : "ml"
    },
    "denominator" : {
      "value" : 1
    }
  },
  "ingredient" : [{
    "itemReference" : {
      "reference" : "#MedicationHydrocortison"
    },
    "isActive" : true,
    "strength" : {
      "numerator" : {
        "value" : 50,
        "system" : "http://unitsofmeasure.org",
        "code" : "g"
      },
      "denominator" : {
        "value" : 100,
        "system" : "http://unitsofmeasure.org",
        "code" : "g"
      }
    }
  },
  {
    "itemReference" : {
      "reference" : "#MedicationDexpanthenol"
    },
    "isActive" : true,
    "strength" : {
      "numerator" : {
        "value" : 50,
        "system" : "http://unitsofmeasure.org",
        "code" : "g"
      },
      "denominator" : {
        "value" : 100,
        "system" : "http://unitsofmeasure.org",
        "code" : "g"
      }
    }
  }]
}

```
