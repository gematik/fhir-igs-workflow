#  - E-Rezept für Arzneimittel v1.0.0-draft

E-Rezept für Arzneimittel

Version 1.0.0-draft - ci-build 

* [**Table of Contents**](toc.md)
* [**FHIR-Artefakte**](artifacts.md)
* ****

## Parameters: 



## Resource Content

```json
{
  "resourceType" : "Parameters",
  "id" : "Parameters-output-example-1",
  "parameter" : [
    {
      "name" : "rxPrescription",
      "part" : [
        {
          "name" : "authoredOn",
          "valueDateTime" : "2024-05-20"
        },
        {
          "name" : "medication",
          "resource" : {
            "resourceType" : "Medication",
            "meta" : {
              "profile" : [
                "https://gematik.de/fhir/epa-medication/StructureDefinition/epa-medication"
              ]
            },
            "extension" : [
              {
                "url" : "https://gematik.de/fhir/epa-medication/StructureDefinition/drug-category-extension",
                "valueCoding" : {
                  "code" : "00"
                }
              },
              {
                "url" : "https://gematik.de/fhir/epa-medication/StructureDefinition/medication-id-vaccine-extension",
                "valueBoolean" : false
              }
            ],
            "code" : {
              "coding" : [
                {
                  "system" : "http://fhir.de/CodeSystem/ifa/pzn",
                  "code" : "07765007"
                }
              ],
              "text" : "NEUPRO 8MG/24H PFT 7 ST"
            },
            "form" : {
              "coding" : [
                {
                  "system" : "https://fhir.kbv.de/CodeSystem/KBV_CS_SFHIR_KBV_DARREICHUNGSFORM",
                  "code" : "PFT"
                }
              ]
            }
          }
        },
        {
          "name" : "medicationRequest",
          "resource" : {
            "resourceType" : "MedicationRequest",
            "meta" : {
              "profile" : [
                "https://gematik.de/fhir/epa-medication/StructureDefinition/epa-medication-request"
              ]
            },
            "extension" : [
              {
                "url" : "https://gematik.de/fhir/epa-medication/StructureDefinition/indicator-ser-extension",
                "valueBoolean" : false
              },
              {
                "extension" : [
                  {
                    "url" : "indicator",
                    "valueBoolean" : false
                  }
                ],
                "url" : "https://gematik.de/fhir/epa-medication/StructureDefinition/multiple-prescription-extension"
              }
            ],
            "status" : "active",
            "intent" : "order",
            "medicationReference" : {
              "reference" : "Medication/5ff1bd22-ce14-484e-be56-d2ba4adeac31"
            },
            "authoredOn" : "2024-05-20",
            "requester" : {
              "reference" : "Practitioner/d6f3b55d-3095-4655-96dc-da3bec21271c"
            },
            "dispenseRequest" : {
              "quantity" : {
                "value" : 1,
                "unit" : "Packung"
              }
            },
            "substitution" : {
              "allowedBoolean" : true
            }
          }
        },
        {
          "name" : "organization",
          "resource" : {
            "resourceType" : "Organization",
            "meta" : {
              "profile" : [
                "https://gematik.de/fhir/directory/StructureDefinition/OrganizationDirectory"
              ]
            },
            "telecom" : [
              {
                "system" : "phone",
                "value" : "030321654987"
              },
              {
                "system" : "email",
                "value" : "hausarztpraxis@e-mail.de"
              }
            ],
            "address" : [
              {
                "type" : "both",
                "line" : ["Herbert-Lewin-Platz 2", "Erdgeschoss"],
                "_line" : [
                  {
                    "extension" : [
                      {
                        "url" : "http://hl7.org/fhir/StructureDefinition/iso21090-ADXP-houseNumber",
                        "valueString" : "2"
                      },
                      {
                        "url" : "http://hl7.org/fhir/StructureDefinition/iso21090-ADXP-streetName",
                        "valueString" : "Herbert-Lewin-Platz"
                      }
                    ]
                  },
                  {
                    "extension" : [
                      {
                        "url" : "http://hl7.org/fhir/StructureDefinition/iso21090-ADXP-additionalLocator",
                        "valueString" : "Erdgeschoss"
                      }
                    ]
                  }
                ],
                "city" : "Berlin",
                "postalCode" : "10623",
                "country" : "D"
              },
              {
                "type" : "both",
                "line" : ["Herbert-Lewin-Platz 2", "Erdgeschoss"],
                "_line" : [
                  {
                    "extension" : [
                      {
                        "url" : "http://hl7.org/fhir/StructureDefinition/iso21090-ADXP-houseNumber",
                        "valueString" : "2"
                      },
                      {
                        "url" : "http://hl7.org/fhir/StructureDefinition/iso21090-ADXP-streetName",
                        "valueString" : "Herbert-Lewin-Platz"
                      }
                    ]
                  },
                  {
                    "extension" : [
                      {
                        "url" : "http://hl7.org/fhir/StructureDefinition/iso21090-ADXP-additionalLocator",
                        "valueString" : "Erdgeschoss"
                      }
                    ]
                  }
                ],
                "city" : "Berlin",
                "postalCode" : "10623",
                "country" : "D"
              }
            ]
          }
        },
        {
          "name" : "practitioner",
          "resource" : {
            "resourceType" : "Practitioner",
            "meta" : {
              "profile" : [
                "https://gematik.de/fhir/directory/StructureDefinition/PractitionerDirectory"
              ]
            },
            "name" : [
              {
                "use" : "official",
                "family" : "Schulz",
                "_family" : {
                  "extension" : [
                    {
                      "url" : "http://hl7.org/fhir/StructureDefinition/humanname-own-name",
                      "valueString" : "Schulz"
                    }
                  ]
                },
                "given" : ["Ben"]
              }
            ]
          }
        },
        {
          "name" : "prescriptionId",
          "valueString" : "160.100.000.000.037.28"
        }
      ]
    }
  ]
}

```
