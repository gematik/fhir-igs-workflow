# Überblick zur Verordnung und Belieferung von Arzneimitteln - E-Rezept für Arzneimittel v1.0.0-draft

E-Rezept für Arzneimittel

Version 1.0.0-draft - ci-build 

* [**Table of Contents**](toc.md)
* **Überblick zur Verordnung und Belieferung von Arzneimitteln**

## Überblick zur Verordnung und Belieferung von Arzneimitteln

tbd

mögliche Inhalte:

* fachlicher Überblick über Verordnungsprozesse im E-Rezept-Fachdienst
* Einordnung des E-Rezept-Fachdienst im dgMP
* Aufgaben des E-Rezept-Fachdienst und Abgrenzung zur ePA
* Rolle der Task-ID im E-Rezept-Workflow
* Beschreibung der Flowtypes (z.B. 160, 161, 162)
* Rechtliche Grundlagen und Regelungen (SGB V, BMG-Vorgaben, BfArM-Richtlinien)

