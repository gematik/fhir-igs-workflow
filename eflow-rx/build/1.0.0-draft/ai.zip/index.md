# Implementation Guide E-Rezept-Fachdienst - E-Rezept für Arzneimittel v1.0.0-draft

E-Rezept für Arzneimittel

Version 1.0.0-draft - ci-build 

* [**Table of Contents**](toc.md)
* **Implementation Guide E-Rezept-Fachdienst**

## Implementation Guide E-Rezept-Fachdienst

| | |
| :--- | :--- |
| *Official URL*:https://gematik.de/fhir/erp/ImplementationGuide/de.gematik.eflow-rx | *Version*:1.0.0-draft |
| Draft as of 2026-02-12 | *Computable Name*:gemIG_eRp_Prescription |

# Implementation Guide E-Rezept-Workflow

Dieser Implementation Guide beschreibt die Datenmodelle und Basis-Workflows des E-Rezept-Fachdienstes. Er bildet das Fundament fuer die fachlichen Szenarien und die technischen Schnittstellen im E-Rezept-Workflow.

## Zweck und Geltungsbereich

* Grundlegende Workflows fuer E-Rezepte (Flowtypes 160/169/200/209)
* Basis-Profile, Operationen und Validierungsregeln
* Referenz fuer modulare IGs (z. B. PKV, EU, T-Rezept, DiGA)

## Nicht im Scope

* Modul-spezifische Sonderfaelle, die in eigenen IGs beschrieben sind
* Produkttyp-spezifische Implementierungsdetails ausserhalb des Fachdienstes

## Wie dieser IG zu lesen ist

Die Kapitel folgen der Struktur Fachlichkeit, Technische Umsetzung und Schnittstellen. Szenarien und Anwendungsfaelle verweisen auf die zugehoerigen technischen Kapitel und Profile.

## Abhaengigkeiten













## Kontakt und Feedback

Fuer Fragen und Feedback wenden Sie sich bitte an [erp-umsetzung@gematik.de](mailto:erp-umsetzung@gematik.de).

## Rechtliche Hinweise

Copyright ©2026+ gematik GmbH

HL7®, HEALTH LEVEL SEVEN®, FHIR® und das FHIR®-Logo sind Marken von Health Level Seven International.

