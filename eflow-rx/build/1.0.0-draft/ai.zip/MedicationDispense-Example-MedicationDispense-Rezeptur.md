# Example Rezeptur Medication Dispense - E-Rezept für Arzneimittel v1.0.0-draft

E-Rezept für Arzneimittel

Version 1.0.0-draft - ci-build 

* [**Table of Contents**](toc.md)
* [**FHIR-Artefakte**](artifacts.md)
* **Example Rezeptur Medication Dispense**

## Example MedicationDispense: Example Rezeptur Medication Dispense



## Resource Content

```json
{
  "resourceType" : "MedicationDispense",
  "id" : "Example-MedicationDispense-Rezeptur",
  "meta" : {
    "profile" : [
      "https://gematik.de/fhir/erp/StructureDefinition/eflow-rx-medicationdispense"
    ]
  },
  "identifier" : [
    {
      "system" : "https://gematik.de/fhir/erp/NamingSystem/GEM_ERP_NS_PrescriptionId",
      "value" : "160.000.033.491.280.78"
    }
  ],
  "status" : "completed",
  "medicationReference" : {
    "reference" : "Medication/Medication-Rezeptur"
  },
  "subject" : {
    "identifier" : {
      "system" : "http://fhir.de/sid/gkv/kvid-10",
      "value" : "X123456789"
    }
  },
  "performer" : [
    {
      "actor" : {
        "identifier" : {
          "system" : "https://gematik.de/fhir/sid/telematik-id",
          "value" : "3-SMC-B-Testkarte-883110000095957"
        }
      }
    }
  ],
  "whenHandedOver" : "2026-07-01"
}

```
