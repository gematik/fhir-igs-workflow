# de.gematik.tiflow.xborder#1.0.0-draft: TIFlow - Grenzüberschreitender Datenaustausch

## Pages

* [Einlösen von E-Rezepten im europäischen Ausland](index.md)
* [FD-Anforderungen: Zugriffsberechtigung einsehen](op-read-eu-access-permission-req-fd.md)
* [E-Rezept-FdV Anforderungen: Task](query-api-task-req-fdv.md)
* [Operation API: E-Rezepte zur Einlösung im EU-Ausland abrufen](op-get-eu-prescriptions.md)
* [Downloads](downloads.md)
* [Referenzen](referenced.md)
* [FdV-Anforderungen: Consent](query-api-consent-req-fdv.md)
* [FD-Anforderungen Anforderungen: Zugriffsberechtigung löschen](op-revoke-eu-access-permission-req-fd.md)
* [Fachlichkeit - Szenario EU](menu-fachlichkeit-szenario-eu.md)
* [Schnittstellen - Query API](menu-schnittstellen-query-api.md)
* [FdV-Anforderungen: Zugriffsberechtigung einsehen](op-read-eu-access-permission-req-fdv.md)
* [NCPeH-Anforderungen: Abgabe von E-Rezepten im EU-Ausland](op-eu-close-req-ncpeha.md)
* [Server Anforderungen: Zugriffsberechtigung erstellen](op-grant-eu-access-permission-req-fd.md)
* [NCPeH-Anforderungen: E-Rezepte zur Einlösung im EU-Ausland abrufen](op-get-eu-prescriptions-req-ncpeha.md)
* [Operation API: Abgabe von E-Rezepten im EU-Ausland](op-eu-close.md)
* [Schnittstellen - Datenschutz und Sicherheit](menu-technische-umsetzung-datenschutz-und-sicherheit.md)
* [Operation API: Zugriffsberechtigung erstellen](op-grant-eu-access-permission.md)
* [FHIR-Artefakte](artifacts.md)
* [Operation API: Zugriffsberechtigung einsehen](op-read-eu-access-permission.md)
* [Operation API: Zugriffsberechtigung löschen](op-revoke-eu-access-permission.md)
* [Query API: Task](query-api-task.md)
* [Technisches Konzept](menu-technische-umsetzung-konzept.md)
* [Schnittstellen - Operation API](menu-schnittstellen-operation-api.md)
* [Server Anforderungen: Task](query-api-task-req-fd.md)
* [Query API: Consent](query-api-consent.md)
* [FD-Anforderungen: Consent](query-api-consent-req-fd.md)
* [Technische Umsetzung - Technische Anwendungsfälle](menu-technische-umsetzung-anwendungsfaelle.md)
* [Release Notes](release-notes.md)
* [FdV-Anforderungen: Zugriffsberechtigung erstellen](op-grant-eu-access-permission-req-fdv.md)
* [FdV-Anforderungen Anforderungen: Zugriffsberechtigung löschen](op-revoke-eu-access-permission-req-fdv.md)
* [FD-Anforderungen: Abgabe von E-Rezepten im EU-Ausland](op-eu-close-req-fd.md)
* [FD-Anforderungen: E-Rezepte zur Einlösung im EU-Ausland abrufen](op-get-eu-prescriptions-req-fd.md)
* [Lizenz](license.md)

## Resources

### CodeSystems

* [CodeSystem of types for a consent](CodeSystem-GEM-ERPEU-CS-ConsentType.md)
* [CodeSystem of NCPeH Request Types](CodeSystem-GEM-ERPEU-CS-RequestType.md)
* [TIFLOW XBORDER Operation Outcome Details CS](CodeSystem-tiflow-xborder-operation-outcome-details-cs.md)

### ValueSets

* [ValueSet of Consent PolyRule Codes](ValueSet-GEM-ERPEU-VS-Consent-PolicyRule.md)
* [ValueSet of Consent Codes](ValueSet-GEM-ERPEU-VS-ConsentType.md)
* [ValueSet of NCPeH Request Types](ValueSet-GEM-ERPEU-VS-RequestType.md)
* [TIFLOW XBORDER Operation Outcome Details VS](ValueSet-tiflow-xborder-operation-outcome-details-vs.md)

### Logicals

* [Dispense Data from EU](StructureDefinition-logical-eu-dispense-data.md)

### Complex-type Profiles

* [Identifier Profile for EU AccessCode](StructureDefinition-GEM-ERPEU-PR-AccessCode.md)

### Resource Profiles

* [Consent for ePrescriptions](StructureDefinition-GEM-ERPEU-PR-Consent.md)
* [EU-Medication](StructureDefinition-GEM-ERPEU-PR-Medication.md)
* [Dispensation of the Prescription from the EU](StructureDefinition-GEM-ERPEU-PR-MedicationDispense.md)
* [Organization Information Received from the EU](StructureDefinition-GEM-ERPEU-PR-Organization.md)
* [GEM ERPEU PR PAR Access Authorization Request](StructureDefinition-GEM-ERPEU-PR-PAR-AccessAuthorization-Request.md)
* [GEM ERPEU PR PAR Access Authorization Response](StructureDefinition-GEM-ERPEU-PR-PAR-AccessAuthorization-Response.md)
* [GEM ERP PR EU CloseOperation Input](StructureDefinition-GEM-ERPEU-PR-PAR-Close-Operation-Input.md)
* [GEM ERPEU PR PAR GET Prescription Input](StructureDefinition-GEM-ERPEU-PR-PAR-EU-GET-Prescription-Input.md)
* [GEM ERPEU PR PAR PATCH Task Input](StructureDefinition-GEM-ERPEU-PR-PAR-PATCH-Task-Input.md)
* [Practitioner Information Received from the EU](StructureDefinition-GEM-ERPEU-PR-Practitioner.md)
* [PractitionerRole Information Received from the EU](StructureDefinition-GEM-ERPEU-PR-PractitionerRole.md)
* [GEM ERPEU PR PAR GET Prescription Output](StructureDefinition-gem-erpeu-pr-par-get-prescription-output.md)

### Extensions

* [GEM_ERPEU_EX_MedicinalPackageDescription](StructureDefinition-GEM-ERPEU-EX-MedicinalPackageDescription.md)
* [GEM_ERPEU_EX_MedicinalPackageIdentifier](StructureDefinition-GEM-ERPEU-EX-MedicinalPackageIdentifier.md)

### CapabilityStatements

* [ERPEU CapabilityStatement fuer den E-Rezept-Fachdienst](CapabilityStatement-erp-fachdienst-server-erpeu.md)

### ImplementationGuides

* [TIFlow - Grenzüberschreitender Datenaustausch](index.md)

### OperationDefinitions

* [EUClose](OperationDefinition-EUCloseOperation.md)
* [GET-Prescription-EU](OperationDefinition-GET-Prescription-EU.md)
* [Grant_Access_Permission](OperationDefinition-Grant-EU-Access-Permission.md)
* [Read_Access_Permission](OperationDefinition-Read-EU-Access-Permission.md)
* [Revoke_Access_Permission](OperationDefinition-Revoke-EU-Access-Permission.md)

### Examples

* [ExampleGetConsent (Bundle)](Bundle-ExampleGetConsent.md)
* [f97a0772-c99f-4159-90c6-2a41c7d96779 (Consent)](Consent-f97a0772-c99f-4159-90c6-2a41c7d96779.md)
* [Medication-Without-Strength-Code (Medication)](Medication-Medication-Without-Strength-Code.md)
* [Medication-Without-Strength-Numerator (Medication)](Medication-Medication-Without-Strength-Numerator.md)
* [SimpleMedication (Medication)](Medication-SimpleMedication.md)
* [SumatripanMedication (Medication)](Medication-SumatripanMedication.md)
* [Example-MedicationDispense-EU (MedicationDispense)](MedicationDispense-Example-MedicationDispense-EU.md)
* [ExampleERPEUOperationOutcomeError (OperationOutcome)](OperationOutcome-ExampleERPEUOperationOutcomeError.md)
* [Pharmacia de Santa Maria (Organization)](Organization-Example-EU-Organization.md)
* [Example-EU-PermissionRequest (Parameters)](Parameters-Example-EU-PermissionRequest.md)
* [Example-EU-PermissionResponse (Parameters)](Parameters-Example-EU-PermissionResponse.md)
* [Example-PATCH-Task-Single-Input-Request-False (Parameters)](Parameters-Example-PATCH-Task-Single-Input-Request-False.md)
* [Example-PATCH-Task-Single-Input-Request-True (Parameters)](Parameters-Example-PATCH-Task-Single-Input-Request-True.md)
* [ExampleEUCloseInputParameters (Parameters)](Parameters-ExampleEUCloseInputParameters.md)
* [ExampleEUGETPrescriptionDEMOGRAPHICS (Parameters)](Parameters-ExampleEUGETPrescriptionDEMOGRAPHICS.md)
* [ExampleEUGETPrescriptionE-PRESCRIPTIONS-LIST (Parameters)](Parameters-ExampleEUGETPrescriptionE-PRESCRIPTIONS-LIST.md)
* [ExampleEUGETPrescriptionE-PRESCRIPTIONS-RETRIEVAL (Parameters)](Parameters-ExampleEUGETPrescriptionE-PRESCRIPTIONS-RETRIEVAL.md)
* [Example-EU-Practitioner (Practitioner)](Practitioner-Example-EU-Practitioner.md)
* [Example-EU-PractitionerRole (PractitionerRole)](PractitionerRole-Example-EU-PractitionerRole.md)
