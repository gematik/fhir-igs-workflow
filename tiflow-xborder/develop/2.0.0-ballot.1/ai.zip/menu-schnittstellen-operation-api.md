# Schnittstellen - Operation API - TIFlow - Grenzüberschreitender Datenaustausch v2.0.0-ballot.1

TIFlow - Grenzüberschreitender Datenaustausch

Version 2.0.0-ballot.1 - ci-build 

* [**Table of Contents**](toc.md)
* **Schnittstellen - Operation API**

## Schnittstellen - Operation API

Die folgenden Operation APIs stellt der TI-Flow-Fachdienst dem **E-Rezept-FdV** sowie dem **NCPeH** zur Verfügung.

### Verwaltung der Zugriffsberechtigung durch den Versicherten

* E-Rezept-FdV: [Operation API: Zugriffsberechtigung erstellen](./op-grant-eu-access-permission.md)
* E-Rezept-FdV: [Operation API: Zugriffsberechtigung abfragen](./op-read-eu-access-permission.md)
* E-Rezept-FdV: [Operation API: Zugriffsberechtigung löschen](./op-revoke-eu-access-permission.md)

### Belieferung durch eine Apotheke im europäischen Ausland

* NCPeH: [Operation API: Interaktion NCPeH - Abrufen](./op-get-eu-prescriptions.md)
* NCPeH: [Operation API: Interaktion NCPeH - Abgeben](./op-eu-close.md)

