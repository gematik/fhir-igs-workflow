# ValueSet of NCPeH Request Types - TIFlow - Grenzüberschreitender Datenaustausch v2.0.0-ballot.1

TIFlow - Grenzüberschreitender Datenaustausch

Version 2.0.0-ballot.1 - ci-build 

* [**Table of Contents**](toc.md)
* [**FHIR-Artefakte**](artifacts.md)
* **ValueSet of NCPeH Request Types**

## ValueSet: ValueSet of NCPeH Request Types 

| | |
| :--- | :--- |
| *Official URL*:https://gematik.de/fhir/erp-eu/ValueSet/GEM_ERPEU_VS_RequestType | *Version*:2.0.0-ballot.1 |
| Draft as of 2026-05-26 | *Computable Name*:GEM_ERPEU_VS_RequestType |

 
Type of Request from NCPeH 

 **References** 

* [GEM ERPEU PR PAR GET Prescription Input](StructureDefinition-GEM-ERPEU-PR-PAR-EU-GET-Prescription-Input.md)

### Logical Definition (CLD)

 

### Expansion

-------

 Explanation of the columns that may appear on this page: 

| | |
| :--- | :--- |
| Level | A few code lists that FHIR defines are hierarchical - each code is assigned a level. In this scheme, some codes are under other codes, and imply that the code they are under also applies |
| System | The source of the definition of the code (when the value set draws in codes defined elsewhere) |
| Code | The code (used as the code in the resource instance) |
| Display | The display (used in the*display*element of a[Coding](http://hl7.org/fhir/R4/datatypes.html#Coding)). If there is no display, implementers should not simply display the code, but map the concept into their application |
| Definition | An explanation of the meaning of the concept |
| Comments | Additional notes about how to use the code |



## Resource Content

```json
{
  "resourceType" : "ValueSet",
  "id" : "GEM-ERPEU-VS-RequestType",
  "url" : "https://gematik.de/fhir/erp-eu/ValueSet/GEM_ERPEU_VS_RequestType",
  "version" : "2.0.0-ballot.1",
  "name" : "GEM_ERPEU_VS_RequestType",
  "title" : "ValueSet of NCPeH Request Types",
  "status" : "draft",
  "date" : "2026-05-26",
  "publisher" : "gematik GmbH",
  "contact" : [{
    "name" : "gematik GmbH",
    "telecom" : [{
      "system" : "url",
      "value" : "https://gematik.de"
    },
    {
      "system" : "email",
      "value" : "erp-umsetzung@gematik.de"
    }]
  }],
  "description" : "Type of Request from NCPeH",
  "jurisdiction" : [{
    "coding" : [{
      "system" : "urn:iso:std:iso:3166",
      "code" : "DE",
      "display" : "Germany"
    }]
  }],
  "compose" : {
    "include" : [{
      "system" : "https://gematik.de/fhir/erp-eu/CodeSystem/GEM_ERPEU_CS_RequestType"
    }]
  }
}

```
