# Grant-EU-Access-Permission - TIFlow - Grenzüberschreitender Datenaustausch v2.0.0-ballot.2

TIFlow - Grenzüberschreitender Datenaustausch

Version 2.0.0-ballot.2 - ci-build 

* [**Table of Contents**](toc.md)
* [**FHIR-Artefakte**](artifacts.md)
* **Grant-EU-Access-Permission**

## OperationDefinition: Grant-EU-Access-Permission 

| | |
| :--- | :--- |
| *Official URL*:https://gematik.de/fhir/tiflow-xborder/OperationDefinition/Grant-EU-Access-Permission | *Version*:2.0.0-ballot.2 |
| Draft as of 2026-05-26 | *Computable Name*:Grant-EU-Access-Permission |

 
This operation receives the access code and the country that the patient wants to grant access to. The operation validates the country and creates registeres the Access Code. 



## Resource Content

```json
{
  "resourceType" : "OperationDefinition",
  "id" : "Grant-EU-Access-Permission",
  "url" : "https://gematik.de/fhir/tiflow-xborder/OperationDefinition/Grant-EU-Access-Permission",
  "version" : "2.0.0-ballot.2",
  "name" : "Grant-EU-Access-Permission",
  "status" : "draft",
  "kind" : "operation",
  "date" : "2026-05-26",
  "publisher" : "gematik GmbH",
  "contact" : [{
    "name" : "gematik GmbH",
    "telecom" : [{
      "system" : "url",
      "value" : "https://gematik.de"
    },
    {
      "system" : "email",
      "value" : "erp-umsetzung@gematik.de"
    }]
  }],
  "description" : "This operation receives the access code and the country that the patient wants to grant access to. The operation validates the country and creates registeres the Access Code.",
  "jurisdiction" : [{
    "coding" : [{
      "system" : "urn:iso:std:iso:3166",
      "code" : "DE",
      "display" : "Germany"
    }]
  }],
  "affectsState" : true,
  "code" : "grant-eu-access-permission",
  "system" : true,
  "type" : false,
  "instance" : false,
  "inputProfile" : "https://gematik.de/fhir/tiflow-xborder/StructureDefinition/GEM-ERPEU-PR-PAR-AccessAuthorization-Request",
  "outputProfile" : "https://gematik.de/fhir/tiflow-xborder/StructureDefinition/GEM-ERPEU-PR-PAR-AccessAuthorization-Response",
  "parameter" : [{
    "name" : "countryCode",
    "use" : "in",
    "min" : 1,
    "max" : "1",
    "documentation" : "The country for which the patient wants to grant access.",
    "type" : "Coding"
  },
  {
    "name" : "accessCode",
    "use" : "in",
    "min" : 1,
    "max" : "1",
    "documentation" : "The access code for that country.",
    "type" : "Identifier"
  },
  {
    "name" : "countryCode",
    "use" : "out",
    "min" : 1,
    "max" : "1",
    "documentation" : "The country for which the patient wants to grant access.",
    "type" : "Coding"
  },
  {
    "name" : "accessCode",
    "use" : "out",
    "min" : 1,
    "max" : "1",
    "documentation" : "The access code for that country.",
    "type" : "Identifier"
  },
  {
    "name" : "validUntil",
    "use" : "out",
    "min" : 1,
    "max" : "1",
    "documentation" : "The instant until the access code is valid.",
    "type" : "instant"
  },
  {
    "name" : "createdAt",
    "use" : "out",
    "min" : 1,
    "max" : "1",
    "documentation" : "The instant when the record was created in the E-Rezept-Fachdienst.",
    "type" : "instant"
  }]
}

```
