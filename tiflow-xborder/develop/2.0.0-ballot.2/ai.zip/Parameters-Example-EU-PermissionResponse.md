# GEM_ERPEU_PR_PAR_Access_Authorization_Response - TIFlow - Grenzüberschreitender Datenaustausch v2.0.0-ballot.2

TIFlow - Grenzüberschreitender Datenaustausch

Version 2.0.0-ballot.2 - ci-build 

* [**Table of Contents**](toc.md)
* [**FHIR-Artefakte**](artifacts.md)
* **GEM_ERPEU_PR_PAR_Access_Authorization_Response**

## Example Parameters: GEM_ERPEU_PR_PAR_Access_Authorization_Response



## Resource Content

```json
{
  "resourceType" : "Parameters",
  "id" : "Example-EU-PermissionResponse",
  "meta" : {
    "profile" : ["https://gematik.de/fhir/tiflow-xborder/StructureDefinition/GEM-ERPEU-PR-PAR-AccessAuthorization-Response"]
  },
  "parameter" : [{
    "name" : "countryCode",
    "valueCoding" : {
      "system" : "urn:iso:std:iso:3166",
      "code" : "BE"
    }
  },
  {
    "name" : "accessCode",
    "valueIdentifier" : {
      "system" : "https://gematik.de/fhir/erp/NamingSystem/GEM_ERP_NS_EU_AccessCode",
      "value" : "ABC123"
    }
  },
  {
    "name" : "validUntil",
    "valueInstant" : "2025-10-01T13:12:32+02:00"
  },
  {
    "name" : "createdAt",
    "valueInstant" : "2025-10-01T12:12:32+02:00"
  }]
}

```
